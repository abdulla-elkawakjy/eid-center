import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { RequestStatusBadge } from './RequestStatusBadge';
import { toast } from 'sonner';
import { Plus, Trash2, Package, Loader2, AlertCircle } from 'lucide-react';
import { format, differenceInDays, addDays } from 'date-fns';
import { ar } from 'date-fns/locale';

interface StoreRequestsTabProps {
  programId: string;
  sessions: Array<{ id: string; session_date: string | null }>;
  isLeader: boolean;
}

interface StoreItem {
  id: string;
  name: string;
  name_en: string | null;
  available_quantity: number;
  item_type: 'disposable' | 'reusable';
}

interface RequestItem {
  id: string;
  item_id: string | null;
  custom_item_name: string | null;
  quantity_requested: number;
  quantity_approved: number | null;
  status: string;
  store_keeper_notes: string | null;
  item?: StoreItem;
}

interface StoreRequest {
  id: string;
  session_id: string;
  status: string;
  notes: string | null;
  created_at: string;
  session?: { session_date: string | null };
  items?: RequestItem[];
}

export function StoreRequestsTab({ programId, sessions, isLeader }: StoreRequestsTabProps) {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedSession, setSelectedSession] = useState('');
  const [requestNotes, setRequestNotes] = useState('');
  const [requestItems, setRequestItems] = useState<Array<{
    item_id: string;
    quantity: number;
    isCustom: boolean;
    custom_name: string;
  }>>([]);

  // Fetch store requests for this program
  const { data: requests, isLoading: requestsLoading } = useQuery({
    queryKey: ['store-requests', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_requests')
        .select(`
          *,
          session:sessions(session_date)
        `)
        .eq('program_id', programId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      // Fetch items for each request
      const requestIds = data?.map(r => r.id) || [];
      if (requestIds.length > 0) {
        const { data: items } = await supabase
          .from('store_request_items')
          .select(`
            *,
            item:store_items(id, name, name_en, available_quantity, item_type)
          `)
          .in('request_id', requestIds);
        
        return data?.map(req => ({
          ...req,
          items: items?.filter(i => i.request_id === req.id) || []
        })) as StoreRequest[];
      }
      
      return data as StoreRequest[];
    },
  });

  // Fetch available store items
  const { data: storeItems } = useQuery({
    queryKey: ['store-items-available'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_items')
        .select('*')
        .gt('available_quantity', 0)
        .order('name');
      if (error) throw error;
      return data as StoreItem[];
    },
  });

  // Check if a session is within the request window (10 to 4 days before)
  const canRequestForSession = (sessionDate: string | null): { canRequest: boolean; message: string } => {
    if (!sessionDate) return { canRequest: false, message: t('لم يتم تحديد التاريخ', 'Date not set') };
    
    const today = new Date();
    const session = new Date(sessionDate);
    const daysUntil = differenceInDays(session, today);
    
    if (daysUntil > 10) {
      const opensIn = daysUntil - 10;
      return { 
        canRequest: false, 
        message: t(`يفتح الطلب بعد ${opensIn} لقاءات`, `Request opens in ${opensIn} sessions`) 
      };
    }
    if (daysUntil < 4) {
      return { 
        canRequest: false, 
        message: t('انتهت فترة الطلب', 'Request window closed') 
      };
    }
    return { canRequest: true, message: '' };
  };

  // Get sessions that can have requests
  const availableSessions = sessions.filter(s => {
    const { canRequest } = canRequestForSession(s.session_date);
    // Also check if there's no existing request for this session
    const hasExistingRequest = requests?.some(r => r.session_id === s.id && r.status !== 'closed');
    return canRequest && !hasExistingRequest;
  });

  // Create request mutation
  const createRequestMutation = useMutation({
    mutationFn: async () => {
      // Create the request
      const { data: request, error: requestError } = await supabase
        .from('store_requests')
        .insert({
          program_id: programId,
          session_id: selectedSession,
          requester_id: user?.id,
          notes: requestNotes || null,
        })
        .select()
        .single();
      
      if (requestError) throw requestError;
      
      // Add items to the request
      if (requestItems.length > 0) {
        const itemsToInsert = requestItems.map(item => ({
          request_id: request.id,
          item_id: item.isCustom ? null : item.item_id,
          custom_item_name: item.isCustom ? item.custom_name : null,
          quantity_requested: item.quantity,
        }));
        
        const { error: itemsError } = await supabase
          .from('store_request_items')
          .insert(itemsToInsert);
        
        if (itemsError) throw itemsError;
      }
      
      return request;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-requests', programId] });
      toast.success(t('تم إرسال الطلب', 'Request submitted'));
      setIsCreateDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast.error(error.message || t('فشل في إرسال الطلب', 'Failed to submit request'));
    },
  });

  const resetForm = () => {
    setSelectedSession('');
    setRequestNotes('');
    setRequestItems([]);
  };

  const addItemToRequest = () => {
    setRequestItems([...requestItems, { item_id: '', quantity: 1, isCustom: false, custom_name: '' }]);
  };

  const removeItemFromRequest = (index: number) => {
    setRequestItems(requestItems.filter((_, i) => i !== index));
  };

  const updateRequestItem = (index: number, updates: Partial<typeof requestItems[0]>) => {
    const updated = [...requestItems];
    updated[index] = { ...updated[index], ...updates };
    setRequestItems(updated);
  };

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  if (requestsLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header with action button */}
      {isLeader && (
        <div className="flex justify-end">
          <Button onClick={() => setIsCreateDialogOpen(true)} disabled={availableSessions.length === 0}>
            <Plus className="h-4 w-4 me-2" />
            {t('طلب جديد', 'New Request')}
          </Button>
        </div>
      )}

      {/* Request window info */}
      {isLeader && availableSessions.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="py-4">
            <div className="flex items-center gap-2 text-muted-foreground rtl:flex-row-reverse">
              <AlertCircle className="h-5 w-5" />
              <span>
                {t(
                  'لا توجد لقاءات متاحة للطلب حالياً. يفتح الطلب قبل 10 أيام من اللقاء ويغلق قبل 4 أيام.',
                  'No sessions available for requests. Request window opens 10 days before and closes 4 days before a session.'
                )}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Requests list */}
      {requests?.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center text-muted-foreground">
            <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
            {t('لا توجد طلبات', 'No requests yet')}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {requests?.map((request) => (
            <Card key={request.id}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between rtl:flex-row-reverse">
                  <div className="text-start">
                    <CardTitle className="text-lg">
                      {t('طلب للقاء', 'Request for')} {formatDate(request.session?.session_date || null)}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {t('تاريخ الإنشاء:', 'Created:')} {formatDate(request.created_at)}
                    </p>
                  </div>
                  <RequestStatusBadge status={request.status as any} />
                </div>
              </CardHeader>
              <CardContent>
                {request.notes && (
                  <p className="text-sm text-muted-foreground mb-4">{request.notes}</p>
                )}
                
                {request.items && request.items.length > 0 && (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{t('المنتج', 'Item')}</TableHead>
                          <TableHead>{t('الكمية المطلوبة', 'Qty Requested')}</TableHead>
                          <TableHead>{t('الكمية الموافق عليها', 'Qty Approved')}</TableHead>
                          <TableHead>{t('الحالة', 'Status')}</TableHead>
                          <TableHead>{t('ملاحظات', 'Notes')}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {request.items.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">
                              {item.custom_item_name || (
                                language === 'ar' 
                                  ? item.item?.name 
                                  : item.item?.name_en || item.item?.name
                              )}
                              {item.custom_item_name && (
                                <Badge variant="outline" className="ms-2">
                                  {t('مخصص', 'Custom')}
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>{item.quantity_requested}</TableCell>
                            <TableCell>{item.quantity_approved ?? '-'}</TableCell>
                            <TableCell>
                              <RequestStatusBadge status={item.status as any} type="item" />
                            </TableCell>
                            <TableCell className="max-w-[200px] truncate">
                              {item.store_keeper_notes || '-'}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create Request Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t('طلب جديد من المخزن', 'New Store Request')}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>{t('اختر اللقاء', 'Select Session')} *</Label>
              <Select value={selectedSession} onValueChange={setSelectedSession}>
                <SelectTrigger>
                  <SelectValue placeholder={t('اختر اللقاء', 'Select Session')} />
                </SelectTrigger>
                <SelectContent>
                  {availableSessions.map((session) => (
                    <SelectItem key={session.id} value={session.id}>
                      {formatDate(session.session_date)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t('ملاحظات', 'Notes')}</Label>
              <Textarea
                value={requestNotes}
                onChange={(e) => setRequestNotes(e.target.value)}
                placeholder={t('أي ملاحظات إضافية...', 'Any additional notes...')}
                rows={2}
              />
            </div>

            {/* Items section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between rtl:flex-row-reverse">
                <Label>{t('المنتجات المطلوبة', 'Requested Items')}</Label>
                <Button type="button" variant="outline" size="sm" onClick={addItemToRequest}>
                  <Plus className="h-4 w-4 me-1" />
                  {t('إضافة منتج', 'Add Item')}
                </Button>
              </div>

              {requestItems.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  {t('لم تتم إضافة منتجات بعد', 'No items added yet')}
                </p>
              ) : (
                <div className="space-y-3">
                  {requestItems.map((item, index) => (
                    <Card key={index} className="p-3">
                      <div className="flex flex-col sm:flex-row gap-3">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              id={`custom-${index}`}
                              checked={item.isCustom}
                              onChange={(e) => updateRequestItem(index, { isCustom: e.target.checked, item_id: '' })}
                              className="rounded"
                            />
                            <Label htmlFor={`custom-${index}`} className="text-sm">
                              {t('منتج مخصص (للشراء)', 'Custom item (to purchase)')}
                            </Label>
                          </div>
                          
                          {item.isCustom ? (
                            <Input
                              placeholder={t('اسم المنتج', 'Item name')}
                              value={item.custom_name}
                              onChange={(e) => updateRequestItem(index, { custom_name: e.target.value })}
                            />
                          ) : (
                            <Select
                              value={item.item_id}
                              onValueChange={(value) => updateRequestItem(index, { item_id: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder={t('اختر المنتج', 'Select Item')} />
                              </SelectTrigger>
                              <SelectContent>
                                {storeItems?.map((storeItem) => (
                                  <SelectItem key={storeItem.id} value={storeItem.id}>
                                    {language === 'ar' ? storeItem.name : storeItem.name_en || storeItem.name}
                                    {' '}({t('متوفر:', 'Available:')} {storeItem.available_quantity})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}
                        </div>
                        
                        <div className="w-24 space-y-2">
                          <Label className="text-sm">{t('الكمية', 'Qty')}</Label>
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateRequestItem(index, { quantity: parseInt(e.target.value) || 1 })}
                          />
                        </div>
                        
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="text-destructive self-end"
                          onClick={() => removeItemFromRequest(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>

            <div className="flex gap-3 pt-4 rtl:flex-row-reverse">
              <Button
                onClick={() => createRequestMutation.mutate()}
                disabled={!selectedSession || requestItems.length === 0 || createRequestMutation.isPending}
                className="flex-1"
              >
                {createRequestMutation.isPending && <Loader2 className="h-4 w-4 me-2 animate-spin" />}
                {t('إرسال الطلب', 'Submit Request')}
              </Button>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                {t('إلغاء', 'Cancel')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
