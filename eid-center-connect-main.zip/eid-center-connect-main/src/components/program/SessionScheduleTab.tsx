import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Plus, Trash2, Clock, Pencil, CalendarDays, MapPin, BookOpen, CheckCircle2, Circle } from 'lucide-react';
import { format } from 'date-fns';
import { UserPermissions } from '@/hooks/useUserPermissions';

interface SessionScheduleTabProps {
  sessionId: string;
  programId: string;
  permissions: UserPermissions;
}

interface Activity {
  id: string;
  name: string;
  name_en: string | null;
  start_time: string | null;
  end_time: string | null;
  order_index: number;
}

interface SessionDetails {
  session_number: number | null;
  session_date: string | null;
  location: string | null;
  notes: string | null;
  assembly_time: string | null;
  dismissal_time: string | null;
}

// Compact view-only component for course portions
function CompactCoursePortions({ sessionId, programId }: { sessionId: string; programId: string }) {
  const { language } = useLanguage();

  const { data: portions } = useQuery({
    queryKey: ['session-course-portions-compact', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('session_course_portions')
        .select(`
          id, portion_from, portion_to, is_completed,
          course:program_courses(id, name, name_en)
        `)
        .eq('session_id', sessionId);
      if (error) throw error;
      return data;
    },
    enabled: !!sessionId,
  });

  if (!portions || portions.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2 rtl:flex-row-reverse">
          <BookOpen className="h-4 w-4" />
          {language === 'ar' ? 'حصص المقررات' : 'Course Portions'}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2">
          {portions.map((portion) => (
            <div 
              key={portion.id} 
              className="flex items-center justify-between text-sm py-1.5 border-b last:border-0 rtl:flex-row-reverse"
            >
              <div className="flex items-center gap-2 rtl:flex-row-reverse">
                {portion.is_completed ? (
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                ) : (
                  <Circle className="h-4 w-4 text-muted-foreground" />
                )}
                <span className="font-medium">
                  {language === 'ar' 
                    ? portion.course?.name 
                    : portion.course?.name_en || portion.course?.name}
                </span>
              </div>
              {(portion.portion_from || portion.portion_to) && (
                <span className="text-muted-foreground text-xs">
                  {portion.portion_from && portion.portion_to 
                    ? `${portion.portion_from} → ${portion.portion_to}`
                    : portion.portion_from || portion.portion_to}
                </span>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function SessionScheduleTab({ sessionId, programId, permissions }: SessionScheduleTabProps) {
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  const [isActivityDialogOpen, setIsActivityDialogOpen] = useState(false);
  const [isEditTimesDialogOpen, setIsEditTimesDialogOpen] = useState(false);
  const [activityForm, setActivityForm] = useState({
    name: '',
    name_en: '',
    start_time: '',
    end_time: '',
  });
  const [timesForm, setTimesForm] = useState({
    assembly_time: '',
    dismissal_time: '',
  });

  const canEdit = permissions.isAdmin || permissions.canEditSessionInfo;

  // Fetch session details
  const { data: sessionDetails } = useQuery({
    queryKey: ['session-details', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sessions')
        .select('session_number, session_date, location, notes, assembly_time, dismissal_time')
        .eq('id', sessionId)
        .single();
      if (error) throw error;
      return data as SessionDetails;
    },
    enabled: !!sessionId,
  });

  // Fetch activities
  const { data: activities } = useQuery({
    queryKey: ['session-activities', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('session_activities')
        .select('*')
        .eq('session_id', sessionId)
        .order('order_index', { ascending: true });
      if (error) throw error;
      return data as Activity[];
    },
    enabled: !!sessionId,
  });

  // Update session times
  const updateTimesMutation = useMutation({
    mutationFn: async (data: typeof timesForm) => {
      const { error } = await supabase
        .from('sessions')
        .update({
          assembly_time: data.assembly_time || null,
          dismissal_time: data.dismissal_time || null,
        })
        .eq('id', sessionId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['session-details', sessionId] });
      toast.success(language === 'ar' ? 'تم تحديث الأوقات' : 'Times updated');
      setIsEditTimesDialogOpen(false);
    },
  });

  // Create activity
  const createActivityMutation = useMutation({
    mutationFn: async (data: typeof activityForm) => {
      const maxOrder = activities?.reduce((max, a) => Math.max(max, a.order_index), 0) ?? 0;
      const { error } = await supabase.from('session_activities').insert({
        session_id: sessionId,
        name: data.name,
        name_en: data.name_en || null,
        start_time: data.start_time || null,
        end_time: data.end_time || null,
        order_index: maxOrder + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['session-activities', sessionId] });
      toast.success(language === 'ar' ? 'تم إضافة النشاط' : 'Activity added');
      setIsActivityDialogOpen(false);
      setActivityForm({ name: '', name_en: '', start_time: '', end_time: '' });
    },
  });

  // Delete activity
  const deleteActivityMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('session_activities').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['session-activities', sessionId] });
      toast.success(language === 'ar' ? 'تم حذف النشاط' : 'Activity deleted');
    },
  });

  const handleOpenEditTimes = () => {
    setTimesForm({
      assembly_time: sessionDetails?.assembly_time || '',
      dismissal_time: sessionDetails?.dismissal_time || '',
    });
    setIsEditTimesDialogOpen(true);
  };

  const formatTime = (time: string | null) => {
    if (!time) return '-';
    return time.slice(0, 5); // HH:MM
  };

  return (
    <div className="space-y-6">
      {/* Compact Session Info Header */}
      <Card className="bg-muted/50">
        <CardContent className="py-3">
          <div className="flex flex-wrap items-center gap-3 rtl:flex-row-reverse">
            <Badge variant="secondary" className="text-sm">
              #{sessionDetails?.session_number || '-'}
            </Badge>
            <div className="flex items-center gap-1 text-sm">
              <CalendarDays className="h-4 w-4" />
              {sessionDetails?.session_date 
                ? format(new Date(sessionDetails.session_date), 'EEEE, MMM d, yyyy')
                : '-'}
            </div>
            {sessionDetails?.location && (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />
                {sessionDetails.location}
              </div>
            )}
          </div>
          {sessionDetails?.notes && (
            <p className="text-sm text-muted-foreground mt-2">
              {sessionDetails.notes}
            </p>
          )}
        </CardContent>
      </Card>

      {/* Compact Course Portions Section (View Only) */}
      <CompactCoursePortions sessionId={sessionId} programId={programId} />

      {/* Assembly/Dismissal Times Card */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center rtl:flex-row-reverse">
            <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
              <Clock className="h-5 w-5" />
              {language === 'ar' ? 'أوقات اللقاء' : 'Session Times'}
            </CardTitle>
            {canEdit && (
              <Button variant="outline" size="sm" onClick={handleOpenEditTimes}>
                <Pencil className="h-4 w-4 me-2" />
                {language === 'ar' ? 'تعديل' : 'Edit'}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">
                {language === 'ar' ? 'وقت التجمع' : 'Assembly Time'}
              </p>
              <p className="text-lg font-medium">{formatTime(sessionDetails?.assembly_time ?? null)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">
                {language === 'ar' ? 'وقت الانصراف' : 'Dismissal Time'}
              </p>
              <p className="text-lg font-medium">{formatTime(sessionDetails?.dismissal_time ?? null)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Activities Section */}
      <div className="space-y-4">
        <div className="flex justify-between items-center rtl:flex-row-reverse">
          <h3 className="text-lg font-semibold">
            {language === 'ar' ? 'جدول الأنشطة' : 'Activities Schedule'}
          </h3>
          {canEdit && (
            <Dialog open={isActivityDialogOpen} onOpenChange={setIsActivityDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 me-2" />
                  {language === 'ar' ? 'إضافة نشاط' : 'Add Activity'}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{language === 'ar' ? 'إضافة نشاط جديد' : 'Add New Activity'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={(e) => { e.preventDefault(); createActivityMutation.mutate(activityForm); }} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                      <Input
                        value={activityForm.name}
                        onChange={(e) => setActivityForm({ ...activityForm, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                      <Input
                        value={activityForm.name_en}
                        onChange={(e) => setActivityForm({ ...activityForm, name_en: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'وقت البدء' : 'Start Time'}</Label>
                      <Input
                        type="time"
                        value={activityForm.start_time}
                        onChange={(e) => setActivityForm({ ...activityForm, start_time: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'وقت الانتهاء' : 'End Time'}</Label>
                      <Input
                        type="time"
                        value={activityForm.end_time}
                        onChange={(e) => setActivityForm({ ...activityForm, end_time: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                    <Button type="button" variant="outline" onClick={() => setIsActivityDialogOpen(false)}>
                      {language === 'ar' ? 'إلغاء' : 'Cancel'}
                    </Button>
                    <Button type="submit">{language === 'ar' ? 'إضافة' : 'Add'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {activities?.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-8 text-center text-muted-foreground">
              {language === 'ar' ? 'لا توجد أنشطة' : 'No activities yet'}
            </CardContent>
          </Card>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[50px]">#</TableHead>
                <TableHead>{language === 'ar' ? 'النشاط' : 'Activity'}</TableHead>
                <TableHead>{language === 'ar' ? 'البدء' : 'Start'}</TableHead>
                <TableHead>{language === 'ar' ? 'الانتهاء' : 'End'}</TableHead>
                {canEdit && <TableHead className="w-[80px]">{language === 'ar' ? 'إجراءات' : 'Actions'}</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {activities?.map((activity, index) => (
                <TableRow key={activity.id}>
                  <TableCell>{index + 1}</TableCell>
                  <TableCell className="font-medium">
                    {language === 'ar' ? activity.name : activity.name_en || activity.name}
                  </TableCell>
                  <TableCell>{formatTime(activity.start_time)}</TableCell>
                  <TableCell>{formatTime(activity.end_time)}</TableCell>
                  {canEdit && (
                    <TableCell>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive"
                        onClick={() => deleteActivityMutation.mutate(activity.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Edit Times Dialog */}
      <Dialog open={isEditTimesDialogOpen} onOpenChange={setIsEditTimesDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{language === 'ar' ? 'تعديل أوقات اللقاء' : 'Edit Session Times'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); updateTimesMutation.mutate(timesForm); }} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{language === 'ar' ? 'وقت التجمع' : 'Assembly Time'}</Label>
                <Input
                  type="time"
                  value={timesForm.assembly_time}
                  onChange={(e) => setTimesForm({ ...timesForm, assembly_time: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>{language === 'ar' ? 'وقت الانصراف' : 'Dismissal Time'}</Label>
                <Input
                  type="time"
                  value={timesForm.dismissal_time}
                  onChange={(e) => setTimesForm({ ...timesForm, dismissal_time: e.target.value })}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 rtl:flex-row-reverse">
              <Button type="button" variant="outline" onClick={() => setIsEditTimesDialogOpen(false)}>
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </Button>
              <Button type="submit">{language === 'ar' ? 'حفظ' : 'Save'}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
