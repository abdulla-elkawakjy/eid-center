-- Add 'student' to the app_role enum
-- This must be done in a separate migration before using the new value
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'student';