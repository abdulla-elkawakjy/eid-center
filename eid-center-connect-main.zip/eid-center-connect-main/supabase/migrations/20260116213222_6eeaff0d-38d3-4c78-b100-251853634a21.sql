-- Assign admin role to admin@school.com
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role 
FROM auth.users 
WHERE email = 'admin@school.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Assign staff role to staff@school.com  
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'staff'::app_role 
FROM auth.users 
WHERE email = 'staff@school.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Assign parent role to parent@school.com
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'parent'::app_role 
FROM auth.users 
WHERE email = 'parent@school.com'
ON CONFLICT (user_id, role) DO NOTHING;