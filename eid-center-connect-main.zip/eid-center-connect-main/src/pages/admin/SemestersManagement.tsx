import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';

interface Semester {
  id: string;
  name: string;
  name_en: string | null;
  start_date: string;
  end_date: string;
  is_active: boolean | null;
  created_at: string;
}

export default function SemestersManagement() {
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [isSemesterDialogOpen, setIsSemesterDialogOpen] = useState(false);
  const [editingSemester, setEditingSemester] = useState<Semester | null>(null);

  const [semesterForm, setSemesterForm] = useState({
    name: '',
    name_en: '',
    start_date: '',
    end_date: '',
    is_active: false
  });

  const { data: semesters, isLoading: loadingSemesters } = useQuery({
    queryKey: ['semesters'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('semesters')
        .select('*')
        .order('start_date', { ascending: false });
      if (error) throw error;
      return data as Semester[];
    }
  });

  const createSemesterMutation = useMutation({
    mutationFn: async (data: typeof semesterForm) => {
      const { error } = await supabase.from('semesters').insert({
        name: data.name,
        name_en: data.name_en || null,
        start_date: data.start_date,
        end_date: data.end_date,
        is_active: data.is_active
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['semesters'] });
      toast.success(language === 'ar' ? 'تم إضافة الفصل بنجاح' : 'Semester added successfully');
      resetSemesterForm();
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الإضافة' : 'Error adding semester');
    }
  });

  const updateSemesterMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof semesterForm }) => {
      const { error } = await supabase.from('semesters').update({
        name: data.name,
        name_en: data.name_en || null,
        start_date: data.start_date,
        end_date: data.end_date,
        is_active: data.is_active
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['semesters'] });
      toast.success(language === 'ar' ? 'تم تحديث الفصل بنجاح' : 'Semester updated successfully');
      resetSemesterForm();
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء التحديث' : 'Error updating semester');
    }
  });

  const deleteSemesterMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('semesters').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['semesters'] });
      toast.success(language === 'ar' ? 'تم حذف الفصل بنجاح' : 'Semester deleted successfully');
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الحذف' : 'Error deleting semester');
    }
  });

  const resetSemesterForm = () => {
    setSemesterForm({ name: '', name_en: '', start_date: '', end_date: '', is_active: false });
    setEditingSemester(null);
    setIsSemesterDialogOpen(false);
  };

  const handleEditSemester = (semester: Semester, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSemester(semester);
    setSemesterForm({
      name: semester.name,
      name_en: semester.name_en || '',
      start_date: semester.start_date,
      end_date: semester.end_date,
      is_active: semester.is_active || false
    });
    setIsSemesterDialogOpen(true);
  };

  const handleSemesterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSemester) {
      updateSemesterMutation.mutate({ id: editingSemester.id, data: semesterForm });
    } else {
      createSemesterMutation.mutate(semesterForm);
    }
  };

  const formatDate = (date: string) => {
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  const handleSemesterClick = (semester: Semester) => {
    navigate(`/dashboard/programs/semester/${semester.id}`);
  };

  const DirectionChevron = language === 'ar' ? ChevronLeft : ChevronRight;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <Calendar className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">
              {language === 'ar' ? 'الفصول الدراسية' : 'Semesters'}
            </h1>
          </div>
          <Dialog open={isSemesterDialogOpen} onOpenChange={setIsSemesterDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetSemesterForm()}>
                <Plus className="h-4 w-4 me-2" />
                {language === 'ar' ? 'إضافة فصل' : 'Add Semester'}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingSemester
                    ? (language === 'ar' ? 'تعديل الفصل' : 'Edit Semester')
                    : (language === 'ar' ? 'إضافة فصل جديد' : 'Add New Semester')}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSemesterSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                    <Input
                      value={semesterForm.name}
                      onChange={(e) => setSemesterForm({ ...semesterForm, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                    <Input
                      value={semesterForm.name_en}
                      onChange={(e) => setSemesterForm({ ...semesterForm, name_en: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'تاريخ البداية' : 'Start Date'}</Label>
                    <Input
                      type="date"
                      value={semesterForm.start_date}
                      onChange={(e) => setSemesterForm({ ...semesterForm, start_date: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'تاريخ النهاية' : 'End Date'}</Label>
                    <Input
                      type="date"
                      value={semesterForm.end_date}
                      onChange={(e) => setSemesterForm({ ...semesterForm, end_date: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={semesterForm.is_active}
                    onCheckedChange={(checked) => setSemesterForm({ ...semesterForm, is_active: checked })}
                  />
                  <Label>{language === 'ar' ? 'فصل نشط' : 'Active Semester'}</Label>
                </div>
                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={resetSemesterForm}>
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </Button>
                  <Button type="submit">
                    {editingSemester
                      ? (language === 'ar' ? 'حفظ التغييرات' : 'Save Changes')
                      : (language === 'ar' ? 'إضافة' : 'Add')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {loadingSemesters ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : semesters?.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'لا يوجد فصول دراسية' : 'No semesters found'}
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {semesters?.map((semester) => (
              <Card
                key={semester.id}
                className="cursor-pointer transition-all hover:border-primary hover:shadow-md"
                onClick={() => handleSemesterClick(semester)}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg truncate">
                        {language === 'ar' ? semester.name : semester.name_en || semester.name}
                      </CardTitle>
                      <CardDescription>
                        {formatDate(semester.start_date)} - {formatDate(semester.end_date)}
                      </CardDescription>
                    </div>
                    {semester.is_active && (
                      <Badge variant="default" className="bg-green-500 shrink-0">
                        {language === 'ar' ? 'نشط' : 'Active'}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => handleEditSemester(semester, e)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteSemesterMutation.mutate(semester.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <DirectionChevron className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
