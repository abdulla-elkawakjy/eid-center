import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Logo } from '@/components/Logo';
import { LanguageToggle } from '@/components/LanguageToggle';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { ArrowRight, Loader2, Users } from 'lucide-react';
import { z } from 'zod';
import { NationalitySelect } from '@/components/shared/NationalitySelect';
import { supabase } from '@/integrations/supabase/client';

const loginSchema = z.object({
  email: z.string().email('البريد الإلكتروني غير صالح'),
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
});

const signupSchema = z.object({
  fullName: z.string().min(2, 'الاسم يجب أن يكون حرفين على الأقل'),
  qidNumber: z.string().min(11, 'رقم البطاقة الشخصية يجب أن يكون 11 رقماً').max(11, 'رقم البطاقة الشخصية يجب أن يكون 11 رقماً'),
  phone: z.string().min(8, 'رقم الجوال غير صالح'),
  nationality: z.string().min(1, 'الجنسية مطلوبة'),
  email: z.string().email('البريد الإلكتروني غير صالح'),
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
  confirmPassword: z.string(),
  motherPhone: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'كلمة المرور غير متطابقة',
  path: ['confirmPassword'],
});

export default function ParentAuth() {
  const { t } = useLanguage();
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState('login');
  const [loading, setLoading] = useState(false);
  
  // Login form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginErrors, setLoginErrors] = useState<{ email?: string; password?: string }>({});

  // Signup form
  const [signupData, setSignupData] = useState({
    fullName: '',
    qidNumber: '',
    phone: '',
    motherPhone: '',
    nationality: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [signupErrors, setSignupErrors] = useState<Record<string, string>>({});

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginErrors({});

    const result = loginSchema.safeParse({ email: loginEmail, password: loginPassword });
    if (!result.success) {
      const fieldErrors: { email?: string; password?: string } = {};
      result.error.errors.forEach((err) => {
        if (err.path[0] === 'email') fieldErrors.email = err.message;
        if (err.path[0] === 'password') fieldErrors.password = err.message;
      });
      setLoginErrors(fieldErrors);
      return;
    }

    setLoading(true);
    try {
      const { error } = await signIn(loginEmail, loginPassword);
      
      if (error) {
        toast({
          title: t('خطأ في تسجيل الدخول', 'Login Error'),
          description: t(
            'البريد الإلكتروني أو كلمة المرور غير صحيحة',
            'Invalid email or password'
          ),
          variant: 'destructive',
        });
        return;
      }

      toast({
        title: t('تم تسجيل الدخول بنجاح', 'Login Successful'),
        description: t('جاري تحويلك...', 'Redirecting...'),
      });

      navigate('/parent-dashboard');
    } catch (err) {
      toast({
        title: t('خطأ', 'Error'),
        description: t('حدث خطأ أثناء تسجيل الدخول', 'An error occurred during login'),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupErrors({});

    const result = signupSchema.safeParse(signupData);

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        const field = err.path[0] as string;
        fieldErrors[field] = err.message;
      });
      setSignupErrors(fieldErrors);
      return;
    }

    setLoading(true);
    try {
      // Sign up the user
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email: signupData.email,
        password: signupData.password,
        options: {
          data: {
            full_name: signupData.fullName,
          }
        }
      });

      if (signUpError) {
        let errorMessage = t('حدث خطأ أثناء إنشاء الحساب', 'An error occurred during registration');
        
        if (signUpError.message?.includes('already registered')) {
          errorMessage = t('البريد الإلكتروني مسجل مسبقاً', 'Email is already registered');
        }

        toast({
          title: t('خطأ في التسجيل', 'Registration Error'),
          description: errorMessage,
          variant: 'destructive',
        });
        return;
      }

      if (authData.user) {
        // Update profile with additional info
        await supabase
          .from('profiles')
          .update({
            qid_number: signupData.qidNumber,
            phone: signupData.phone,
            mother_phone: signupData.motherPhone || null,
            nationality: signupData.nationality,
          })
          .eq('user_id', authData.user.id);

        // Assign parent role
        await supabase
          .from('user_roles')
          .insert({ user_id: authData.user.id, role: 'parent' });
      }

      toast({
        title: t('تم إنشاء الحساب بنجاح', 'Account Created Successfully'),
        description: t('مرحباً بك في مركز عيد الثقافي', 'Welcome to Eid Cultural Center'),
      });

      navigate('/parent-dashboard');
    } catch (err) {
      toast({
        title: t('خطأ', 'Error'),
        description: t('حدث خطأ أثناء إنشاء الحساب', 'An error occurred during registration'),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="hero-gradient">
        <div className="container py-6">
          <nav className="flex items-center justify-between">
            <button onClick={() => navigate('/')} className="flex items-center gap-2 group">
              <ArrowRight className="h-5 w-5 text-primary-foreground/70 group-hover:text-primary-foreground transition-colors rotate-180 rtl:rotate-0" />
              <Logo size="sm" />
            </button>
            <LanguageToggle />
          </nav>
        </div>
      </header>

      {/* Auth Form */}
      <main className="container py-16 flex items-center justify-center">
        <Card className="w-full max-w-lg animate-scale-in">
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-secondary/20 flex items-center justify-center">
              <Users className="h-8 w-8 text-secondary" />
            </div>
            <CardTitle className="text-2xl">
              {t('بوابة أولياء الأمور', 'Parent Portal')}
            </CardTitle>
            <CardDescription>
              {t(
                'سجل دخولك أو أنشئ حساباً جديداً',
                'Sign in or create a new account'
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">{t('تسجيل الدخول', 'Login')}</TabsTrigger>
                <TabsTrigger value="signup">{t('حساب جديد', 'Sign Up')}</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">{t('البريد الإلكتروني', 'Email')}</Label>
                    <Input
                      id="login-email"
                      type="email"
                      placeholder={t('أدخل بريدك الإلكتروني', 'Enter your email')}
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className={loginErrors.email ? 'border-destructive' : ''}
                    />
                    {loginErrors.email && (
                      <p className="text-sm text-destructive">{loginErrors.email}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-password">{t('كلمة المرور', 'Password')}</Label>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder={t('أدخل كلمة المرور', 'Enter your password')}
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className={loginErrors.password ? 'border-destructive' : ''}
                    />
                    {loginErrors.password && (
                      <p className="text-sm text-destructive">{loginErrors.password}</p>
                    )}
                  </div>

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 me-2 animate-spin" />
                        {t('جاري تسجيل الدخول...', 'Logging in...')}
                      </>
                    ) : (
                      t('تسجيل الدخول', 'Login')
                    )}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label>{t('اسم الأب الكامل', 'Father Full Name')} *</Label>
                    <Input
                      placeholder={t('أدخل اسم الأب الكامل', 'Enter father full name')}
                      value={signupData.fullName}
                      onChange={(e) => setSignupData({ ...signupData, fullName: e.target.value })}
                      className={signupErrors.fullName ? 'border-destructive' : ''}
                    />
                    {signupErrors.fullName && (
                      <p className="text-sm text-destructive">{signupErrors.fullName}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>{t('رقم البطاقة الشخصية للأب', 'Father QID Number')} *</Label>
                    <Input
                      placeholder="XXXXXXXXXXX"
                      maxLength={11}
                      value={signupData.qidNumber}
                      onChange={(e) => setSignupData({ ...signupData, qidNumber: e.target.value })}
                      className={signupErrors.qidNumber ? 'border-destructive' : ''}
                    />
                    {signupErrors.qidNumber && (
                      <p className="text-sm text-destructive">{signupErrors.qidNumber}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>{t('رقم جوال الأب', 'Father Mobile Number')} *</Label>
                    <Input
                      placeholder="+974 XXXXXXXX"
                      value={signupData.phone}
                      onChange={(e) => setSignupData({ ...signupData, phone: e.target.value })}
                      className={signupErrors.phone ? 'border-destructive' : ''}
                    />
                    {signupErrors.phone && (
                      <p className="text-sm text-destructive">{signupErrors.phone}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>{t('رقم جوال الأم', 'Mother Mobile Number')} ({t('اختياري', 'Optional')})</Label>
                    <Input
                      placeholder="+974 XXXXXXXX"
                      value={signupData.motherPhone}
                      onChange={(e) => setSignupData({ ...signupData, motherPhone: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>{t('جنسية الأب', 'Father Nationality')} *</Label>
                    <NationalitySelect
                      value={signupData.nationality}
                      onValueChange={(value) => setSignupData({ ...signupData, nationality: value })}
                      required
                    />
                    {signupErrors.nationality && (
                      <p className="text-sm text-destructive">{signupErrors.nationality}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>{t('البريد الإلكتروني', 'Email')} *</Label>
                    <Input
                      type="email"
                      placeholder={t('أدخل بريدك الإلكتروني', 'Enter your email')}
                      value={signupData.email}
                      onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                      className={signupErrors.email ? 'border-destructive' : ''}
                    />
                    {signupErrors.email && (
                      <p className="text-sm text-destructive">{signupErrors.email}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>{t('كلمة المرور', 'Password')} *</Label>
                    <Input
                      type="password"
                      placeholder={t('أدخل كلمة مرور قوية', 'Enter a strong password')}
                      value={signupData.password}
                      onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                      className={signupErrors.password ? 'border-destructive' : ''}
                    />
                    {signupErrors.password && (
                      <p className="text-sm text-destructive">{signupErrors.password}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>{t('تأكيد كلمة المرور', 'Confirm Password')} *</Label>
                    <Input
                      type="password"
                      placeholder={t('أعد إدخال كلمة المرور', 'Re-enter your password')}
                      value={signupData.confirmPassword}
                      onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
                      className={signupErrors.confirmPassword ? 'border-destructive' : ''}
                    />
                    {signupErrors.confirmPassword && (
                      <p className="text-sm text-destructive">{signupErrors.confirmPassword}</p>
                    )}
                  </div>

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 me-2 animate-spin" />
                        {t('جاري إنشاء الحساب...', 'Creating account...')}
                      </>
                    ) : (
                      t('إنشاء حساب', 'Create Account')
                    )}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
