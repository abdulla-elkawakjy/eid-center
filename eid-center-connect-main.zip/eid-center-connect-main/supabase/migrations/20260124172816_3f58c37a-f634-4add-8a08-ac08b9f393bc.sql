-- Create item_type enum
CREATE TYPE public.item_type AS ENUM ('disposable', 'reusable');

-- Create store_request_status enum
CREATE TYPE public.store_request_status AS ENUM (
  'pending', 'processing', 'approved', 'delivered', 'returned', 'closed'
);

-- Create request_item_status enum
CREATE TYPE public.request_item_status AS ENUM (
  'pending', 'approved', 'partially_approved', 'unavailable', 
  'delivered', 'returned', 'missing', 'damaged'
);

-- Create store_categories table
CREATE TABLE public.store_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  name_en TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create store_items table
CREATE TABLE public.store_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID REFERENCES public.store_categories(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  name_en TEXT,
  description TEXT,
  item_type public.item_type NOT NULL DEFAULT 'reusable',
  quantity INTEGER NOT NULL DEFAULT 0,
  available_quantity INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create store_requests table
CREATE TABLE public.store_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  program_id UUID REFERENCES public.programs(id) ON DELETE CASCADE NOT NULL,
  session_id UUID REFERENCES public.sessions(id) ON DELETE CASCADE NOT NULL,
  requester_id UUID NOT NULL,
  status public.store_request_status NOT NULL DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  delivered_at TIMESTAMP WITH TIME ZONE,
  closed_at TIMESTAMP WITH TIME ZONE
);

-- Create store_request_items table
CREATE TABLE public.store_request_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  request_id UUID REFERENCES public.store_requests(id) ON DELETE CASCADE NOT NULL,
  item_id UUID REFERENCES public.store_items(id) ON DELETE SET NULL,
  custom_item_name TEXT,
  quantity_requested INTEGER NOT NULL DEFAULT 1,
  quantity_approved INTEGER,
  quantity_returned INTEGER DEFAULT 0,
  status public.request_item_status NOT NULL DEFAULT 'pending',
  store_keeper_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.store_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.store_request_items ENABLE ROW LEVEL SECURITY;

-- RLS Policies for store_categories
CREATE POLICY "Admins can manage categories"
ON public.store_categories FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Store keepers can manage categories"
ON public.store_categories FOR ALL
USING (has_role(auth.uid(), 'store_keeper'::app_role));

CREATE POLICY "Anyone can view categories"
ON public.store_categories FOR SELECT
USING (true);

-- RLS Policies for store_items
CREATE POLICY "Admins can manage items"
ON public.store_items FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Store keepers can manage items"
ON public.store_items FOR ALL
USING (has_role(auth.uid(), 'store_keeper'::app_role));

CREATE POLICY "Staff can view items"
ON public.store_items FOR SELECT
USING (has_role(auth.uid(), 'staff'::app_role));

CREATE POLICY "Anyone can view items"
ON public.store_items FOR SELECT
USING (true);

-- RLS Policies for store_requests
CREATE POLICY "Admins can manage all requests"
ON public.store_requests FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Store keepers can manage all requests"
ON public.store_requests FOR ALL
USING (has_role(auth.uid(), 'store_keeper'::app_role));

CREATE POLICY "Staff can create requests"
ON public.store_requests FOR INSERT
WITH CHECK (has_role(auth.uid(), 'staff'::app_role) AND auth.uid() = requester_id);

CREATE POLICY "Staff can view own requests"
ON public.store_requests FOR SELECT
USING (has_role(auth.uid(), 'staff'::app_role) AND auth.uid() = requester_id);

CREATE POLICY "Staff can update own pending requests"
ON public.store_requests FOR UPDATE
USING (has_role(auth.uid(), 'staff'::app_role) AND auth.uid() = requester_id AND status = 'pending');

-- RLS Policies for store_request_items
CREATE POLICY "Admins can manage all request items"
ON public.store_request_items FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Store keepers can manage all request items"
ON public.store_request_items FOR ALL
USING (has_role(auth.uid(), 'store_keeper'::app_role));

CREATE POLICY "Staff can view request items for own requests"
ON public.store_request_items FOR SELECT
USING (
  has_role(auth.uid(), 'staff'::app_role) AND
  EXISTS (
    SELECT 1 FROM public.store_requests sr
    WHERE sr.id = request_id AND sr.requester_id = auth.uid()
  )
);

CREATE POLICY "Staff can insert request items for own requests"
ON public.store_request_items FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'staff'::app_role) AND
  EXISTS (
    SELECT 1 FROM public.store_requests sr
    WHERE sr.id = request_id AND sr.requester_id = auth.uid() AND sr.status = 'pending'
  )
);

CREATE POLICY "Staff can delete request items for own pending requests"
ON public.store_request_items FOR DELETE
USING (
  has_role(auth.uid(), 'staff'::app_role) AND
  EXISTS (
    SELECT 1 FROM public.store_requests sr
    WHERE sr.id = request_id AND sr.requester_id = auth.uid() AND sr.status = 'pending'
  )
);

-- Create updated_at trigger function if not exists
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Add triggers for updated_at
CREATE TRIGGER update_store_categories_updated_at
  BEFORE UPDATE ON public.store_categories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_store_items_updated_at
  BEFORE UPDATE ON public.store_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_store_requests_updated_at
  BEFORE UPDATE ON public.store_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_store_request_items_updated_at
  BEFORE UPDATE ON public.store_request_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_store_items_category ON public.store_items(category_id);
CREATE INDEX idx_store_requests_program ON public.store_requests(program_id);
CREATE INDEX idx_store_requests_session ON public.store_requests(session_id);
CREATE INDEX idx_store_requests_requester ON public.store_requests(requester_id);
CREATE INDEX idx_store_requests_status ON public.store_requests(status);
CREATE INDEX idx_store_request_items_request ON public.store_request_items(request_id);
CREATE INDEX idx_store_request_items_item ON public.store_request_items(item_id);