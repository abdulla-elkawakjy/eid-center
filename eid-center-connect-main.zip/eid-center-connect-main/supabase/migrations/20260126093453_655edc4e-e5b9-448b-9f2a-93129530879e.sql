-- Program Courses table
CREATE TABLE public.program_courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id uuid NOT NULL REFERENCES programs(id) ON DELETE CASCADE,
  name text NOT NULL,
  name_en text,
  description text,
  description_en text,
  order_index integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Course Files table
CREATE TABLE public.course_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES program_courses(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL,
  file_size bigint NOT NULL,
  uploaded_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Session Course Portions table
CREATE TABLE public.session_course_portions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES program_courses(id) ON DELETE CASCADE,
  portion_from text,
  portion_to text,
  is_completed boolean DEFAULT false,
  completion_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(session_id, course_id)
);

-- Enable RLS
ALTER TABLE public.program_courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_course_portions ENABLE ROW LEVEL SECURITY;

-- program_courses policies
CREATE POLICY "Admins can manage courses" ON public.program_courses
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Staff can view courses" ON public.program_courses
  FOR SELECT USING (has_role(auth.uid(), 'staff'::app_role));

CREATE POLICY "Anyone can view courses" ON public.program_courses
  FOR SELECT USING (true);

-- course_files policies
CREATE POLICY "Admins can manage course files" ON public.course_files
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Staff can manage course files" ON public.course_files
  FOR ALL USING (has_role(auth.uid(), 'staff'::app_role));

CREATE POLICY "Anyone can view course files" ON public.course_files
  FOR SELECT USING (true);

-- session_course_portions policies
CREATE POLICY "Admins can manage portions" ON public.session_course_portions
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Staff can manage portions" ON public.session_course_portions
  FOR ALL USING (has_role(auth.uid(), 'staff'::app_role));

CREATE POLICY "Anyone can view portions" ON public.session_course_portions
  FOR SELECT USING (true);

-- Update triggers for updated_at
CREATE TRIGGER update_program_courses_updated_at
  BEFORE UPDATE ON public.program_courses
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_session_course_portions_updated_at
  BEFORE UPDATE ON public.session_course_portions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();