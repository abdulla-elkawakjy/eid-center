import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { CategoryForm } from '@/components/store/CategoryForm';
import { ItemForm } from '@/components/store/ItemForm';
import { RequestStatusBadge } from '@/components/store/RequestStatusBadge';
import { toast } from 'sonner';
import { 
  Plus, Pencil, Trash2, Package, FolderOpen, Search, Loader2, FileDown, 
  Check, ClipboardList, Undo
} from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

type ItemType = 'disposable' | 'reusable';
type StoreRequestStatus = 'pending' | 'processing' | 'approved' | 'delivered' | 'returned' | 'closed';
type RequestItemStatus = 'pending' | 'approved' | 'partially_approved' | 'unavailable' | 'delivered' | 'returned' | 'missing' | 'damaged';

interface Category {
  id: string;
  name: string;
  name_en: string | null;
  description?: string | null;
}

interface StoreItem {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
  category_id: string | null;
  item_type: ItemType;
  quantity: number;
  available_quantity: number;
  category?: Category;
}

interface RequestItem {
  id: string;
  request_id: string;
  item_id: string | null;
  custom_item_name: string | null;
  quantity_requested: number;
  quantity_approved: number | null;
  quantity_returned: number;
  status: RequestItemStatus;
  store_keeper_notes: string | null;
  item?: {
    id: string;
    name: string;
    name_en: string | null;
    item_type: ItemType;
    available_quantity: number;
  };
}

interface StoreRequest {
  id: string;
  program_id: string;
  session_id: string;
  requester_id: string;
  status: StoreRequestStatus;
  notes: string | null;
  created_at: string;
  delivered_at: string | null;
  closed_at: string | null;
  session?: { session_date: string | null };
  program?: { name: string; name_en: string | null };
  requester?: { full_name: string };
  items?: RequestItem[];
}

export default function StoreManagement() {
  const { t, language } = useLanguage();
  const { role, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get('tab') || 'inventory';

  // Inventory state
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState<'all' | ItemType>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'in-stock' | 'low' | 'out'>('all');
  const [isCategoryFormOpen, setIsCategoryFormOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [isItemFormOpen, setIsItemFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<StoreItem | null>(null);

  // Requests state
  const [requestSearchQuery, setRequestSearchQuery] = useState('');
  const [requestStatusFilter, setRequestStatusFilter] = useState<'all' | StoreRequestStatus>('all');
  const [selectedRequest, setSelectedRequest] = useState<StoreRequest | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [itemUpdates, setItemUpdates] = useState<Record<string, { quantity_approved: number; notes: string; status: RequestItemStatus }>>({});

  // Auth check
  if (!authLoading && role !== 'admin' && role !== 'store_keeper') {
    navigate('/dashboard');
    return null;
  }

  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ['store-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_categories')
        .select('*')
        .order('name');
      if (error) throw error;
      return data as Category[];
    },
  });

  // Fetch items
  const { data: items, isLoading: itemsLoading } = useQuery({
    queryKey: ['store-items'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_items')
        .select(`
          *,
          category:store_categories(id, name, name_en)
        `)
        .order('name');
      if (error) throw error;
      return data as unknown as StoreItem[];
    },
  });

  // Fetch all requests
  const { data: requests, isLoading: requestsLoading } = useQuery({
    queryKey: ['all-store-requests'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('store_requests')
        .select(`
          *,
          session:sessions(session_date),
          program:programs(name, name_en)
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;

      const requesterIds = [...new Set(data?.map(r => r.requester_id) || [])];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name')
        .in('user_id', requesterIds);
      
      const profilesMap = new Map(profiles?.map(p => [p.user_id, p]) || []);
      
      const requestIds = data?.map(r => r.id) || [];
      let allItems: RequestItem[] = [];
      
      if (requestIds.length > 0) {
        const { data: itemsData } = await supabase
          .from('store_request_items')
          .select(`
            *,
            item:store_items(id, name, name_en, item_type, available_quantity)
          `)
          .in('request_id', requestIds);
        allItems = itemsData as RequestItem[] || [];
      }
      
      return data?.map(req => ({
        ...req,
        requester: profilesMap.get(req.requester_id),
        items: allItems.filter(i => i.request_id === req.id)
      })) as StoreRequest[];
    },
  });

  // Category mutations
  const createCategoryMutation = useMutation({
    mutationFn: async (data: { name: string; name_en: string; description: string }) => {
      const { error } = await supabase.from('store_categories').insert({
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-categories'] });
      toast.success(t('تم إضافة الفئة', 'Category added'));
      setIsCategoryFormOpen(false);
    },
  });

  const updateCategoryMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: { name: string; name_en: string; description: string } }) => {
      const { error } = await supabase.from('store_categories').update({
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-categories'] });
      toast.success(t('تم تحديث الفئة', 'Category updated'));
      setIsCategoryFormOpen(false);
      setEditingCategory(null);
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('store_categories').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-categories'] });
      toast.success(t('تم حذف الفئة', 'Category deleted'));
    },
  });

  // Item mutations
  const createItemMutation = useMutation({
    mutationFn: async (data: {
      name: string;
      name_en: string;
      description: string;
      category_id: string;
      item_type: ItemType;
      quantity: number;
    }) => {
      const { error } = await supabase.from('store_items').insert({
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
        category_id: data.category_id || null,
        item_type: data.item_type,
        quantity: data.quantity,
        available_quantity: data.quantity,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-items'] });
      toast.success(t('تم إضافة المنتج', 'Item added'));
      setIsItemFormOpen(false);
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: {
      name: string;
      name_en: string;
      description: string;
      category_id: string;
      item_type: ItemType;
      quantity: number;
    }}) => {
      const currentItem = items?.find(i => i.id === id);
      const quantityDiff = data.quantity - (currentItem?.quantity || 0);
      
      const { error } = await supabase.from('store_items').update({
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
        category_id: data.category_id || null,
        item_type: data.item_type,
        quantity: data.quantity,
        available_quantity: (currentItem?.available_quantity || 0) + quantityDiff,
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-items'] });
      toast.success(t('تم تحديث المنتج', 'Item updated'));
      setIsItemFormOpen(false);
      setEditingItem(null);
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('store_items').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['store-items'] });
      toast.success(t('تم حذف المنتج', 'Item deleted'));
    },
  });

  // Request mutations
  const updateRequestStatusMutation = useMutation({
    mutationFn: async ({ requestId, status, delivered_at, closed_at }: { requestId: string; status: StoreRequestStatus; delivered_at?: string; closed_at?: string }) => {
      const updates: any = { status };
      if (delivered_at) updates.delivered_at = delivered_at;
      if (closed_at) updates.closed_at = closed_at;
      
      const { error } = await supabase
        .from('store_requests')
        .update(updates)
        .eq('id', requestId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-store-requests'] });
      toast.success(t('تم تحديث الحالة', 'Status updated'));
    },
  });

  const updateRequestItemsMutation = useMutation({
    mutationFn: async ({ requestId, updates }: { requestId: string; updates: Record<string, { quantity_approved: number; notes: string; status: RequestItemStatus }> }) => {
      for (const [itemId, data] of Object.entries(updates)) {
        const { error } = await supabase
          .from('store_request_items')
          .update({
            quantity_approved: data.quantity_approved,
            store_keeper_notes: data.notes || null,
            status: data.status,
          })
          .eq('id', itemId);
        if (error) throw error;
      }
      
      const { error } = await supabase
        .from('store_requests')
        .update({ status: 'processing' })
        .eq('id', requestId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-store-requests'] });
      toast.success(t('تم حفظ التغييرات', 'Changes saved'));
      setIsDetailDialogOpen(false);
    },
  });

  const markAsDeliveredMutation = useMutation({
    mutationFn: async (request: StoreRequest) => {
      for (const item of request.items || []) {
        if (item.item_id && item.quantity_approved) {
          const { error: itemError } = await supabase
            .from('store_items')
            .update({
              available_quantity: (item.item?.available_quantity || 0) - item.quantity_approved
            })
            .eq('id', item.item_id);
          if (itemError) throw itemError;
        }
        
        const { error: statusError } = await supabase
          .from('store_request_items')
          .update({ status: 'delivered' })
          .eq('id', item.id);
        if (statusError) throw statusError;
      }
      
      const { error } = await supabase
        .from('store_requests')
        .update({ status: 'delivered', delivered_at: new Date().toISOString() })
        .eq('id', request.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-store-requests'] });
      queryClient.invalidateQueries({ queryKey: ['store-items'] });
      toast.success(t('تم تسجيل التسليم', 'Delivery recorded'));
      setIsDetailDialogOpen(false);
    },
  });

  const markItemReturnedMutation = useMutation({
    mutationFn: async ({ itemId, quantityReturned, itemOriginalId }: { itemId: string; quantityReturned: number; itemOriginalId: string }) => {
      const { error: itemError } = await supabase
        .from('store_request_items')
        .update({ quantity_returned: quantityReturned, status: 'returned' })
        .eq('id', itemId);
      if (itemError) throw itemError;
      
      const { data: storeItem } = await supabase
        .from('store_items')
        .select('available_quantity')
        .eq('id', itemOriginalId)
        .single();
      
      const { error: updateError } = await supabase
        .from('store_items')
        .update({ available_quantity: (storeItem?.available_quantity || 0) + quantityReturned })
        .eq('id', itemOriginalId);
      if (updateError) throw updateError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-store-requests'] });
      queryClient.invalidateQueries({ queryKey: ['store-items'] });
      toast.success(t('تم تسجيل الإرجاع', 'Return recorded'));
    },
  });

  const closeRequestMutation = useMutation({
    mutationFn: async (requestId: string) => {
      const { error } = await supabase
        .from('store_requests')
        .update({ status: 'closed', closed_at: new Date().toISOString() })
        .eq('id', requestId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-store-requests'] });
      toast.success(t('تم إغلاق الطلب', 'Request closed'));
      setIsDetailDialogOpen(false);
    },
  });

  // Filter items
  const filteredItems = items?.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.name_en?.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = categoryFilter === 'all' || item.category_id === categoryFilter;
    const matchesType = typeFilter === 'all' || item.item_type === typeFilter;
    
    let matchesStatus = true;
    if (statusFilter === 'out') {
      matchesStatus = item.available_quantity === 0;
    } else if (statusFilter === 'low') {
      matchesStatus = item.available_quantity > 0 && item.available_quantity <= 5;
    } else if (statusFilter === 'in-stock') {
      matchesStatus = item.available_quantity > 5;
    }
    
    return matchesSearch && matchesCategory && matchesType && matchesStatus;
  });

  // Filter requests
  const filteredRequests = requests?.filter(req => {
    const matchesSearch = 
      req.program?.name?.toLowerCase().includes(requestSearchQuery.toLowerCase()) ||
      req.program?.name_en?.toLowerCase().includes(requestSearchQuery.toLowerCase()) ||
      req.requester?.full_name?.toLowerCase().includes(requestSearchQuery.toLowerCase());
    const matchesStatus = requestStatusFilter === 'all' || req.status === requestStatusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (item: StoreItem) => {
    if (item.available_quantity === 0) {
      return <Badge variant="destructive">{t('نفذ', 'Out')}</Badge>;
    } else if (item.available_quantity <= 5) {
      return <Badge variant="secondary">{t('منخفض', 'Low')}</Badge>;
    }
    return <Badge variant="default">{t('متوفر', 'In Stock')}</Badge>;
  };

  const getTypeBadge = (type: ItemType) => {
    if (type === 'disposable') {
      return <Badge variant="outline">{t('مستهلك', 'Disposable')}</Badge>;
    }
    return <Badge variant="outline">{t('قابل للإرجاع', 'Reusable')}</Badge>;
  };

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  // Generate PDF reports
  const generateInventoryPdfReport = () => {
    const doc = new jsPDF();
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('Store Inventory Report', 14, 22);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 30);

    const tableData = (filteredItems || []).map(item => [
      language === 'ar' ? item.name : item.name_en || item.name,
      language === 'ar' 
        ? (item.category as any)?.name || '-' 
        : (item.category as any)?.name_en || (item.category as any)?.name || '-',
      item.item_type === 'disposable' ? 'Disposable' : 'Reusable',
      item.quantity.toString(),
      item.available_quantity.toString(),
      item.available_quantity === 0 ? 'Out' : item.available_quantity <= 5 ? 'Low' : 'In Stock',
    ]);

    autoTable(doc, {
      head: [['Item', 'Category', 'Type', 'Total', 'Available', 'Status']],
      body: tableData,
      startY: 40,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [59, 130, 246] },
    });

    doc.save('inventory-report.pdf');
    toast.success(t('تم تحميل التقرير', 'Report downloaded'));
  };

  const generateRequestsPdfReport = () => {
    const doc = new jsPDF();
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('Store Requests Report', 14, 22);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 30);

    const tableData = (filteredRequests || []).map(req => [
      language === 'ar' ? req.program?.name || '-' : req.program?.name_en || req.program?.name || '-',
      formatDate(req.session?.session_date || null),
      req.requester?.full_name || '-',
      req.status,
      formatDate(req.created_at),
      req.items?.length.toString() || '0',
    ]);

    autoTable(doc, {
      head: [['Program', 'Session Date', 'Requester', 'Status', 'Created', 'Items']],
      body: tableData,
      startY: 40,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [59, 130, 246] },
    });

    doc.save('requests-report.pdf');
    toast.success(t('تم تحميل التقرير', 'Report downloaded'));
  };

  const handleCategorySubmit = (data: { name: string; name_en: string; description: string }) => {
    if (editingCategory) {
      updateCategoryMutation.mutate({ id: editingCategory.id, data });
    } else {
      createCategoryMutation.mutate(data);
    }
  };

  const handleItemSubmit = (data: {
    name: string;
    name_en: string;
    description: string;
    category_id: string;
    item_type: ItemType;
    quantity: number;
  }) => {
    if (editingItem) {
      updateItemMutation.mutate({ id: editingItem.id, data });
    } else {
      createItemMutation.mutate(data);
    }
  };

  const openDetailDialog = (request: StoreRequest) => {
    setSelectedRequest(request);
    const updates: Record<string, { quantity_approved: number; notes: string; status: RequestItemStatus }> = {};
    request.items?.forEach(item => {
      updates[item.id] = {
        quantity_approved: item.quantity_approved ?? item.quantity_requested,
        notes: item.store_keeper_notes || '',
        status: item.status,
      };
    });
    setItemUpdates(updates);
    setIsDetailDialogOpen(true);
  };

  const handleSaveItemUpdates = () => {
    if (selectedRequest) {
      updateRequestItemsMutation.mutate({ requestId: selectedRequest.id, updates: itemUpdates });
    }
  };

  const handleApproveRequest = () => {
    if (selectedRequest) {
      updateRequestItemsMutation.mutate({ requestId: selectedRequest.id, updates: itemUpdates }, {
        onSuccess: () => {
          updateRequestStatusMutation.mutate({ requestId: selectedRequest.id, status: 'approved' });
        }
      });
    }
  };

  const handleTabChange = (value: string) => {
    setSearchParams({ tab: value });
  };

  if (authLoading || categoriesLoading || itemsLoading || requestsLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3 rtl:flex-row-reverse">
              <Package className="h-8 w-8 text-primary" />
              {t('إدارة المخزن', 'Store Management')}
            </h1>
            <p className="text-muted-foreground mt-1 text-start">
              {t('إدارة المنتجات والطلبات', 'Manage items and requests')}
            </p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="flex-wrap h-auto gap-2 p-2">
            <TabsTrigger value="inventory" className="flex items-center gap-2 rtl:flex-row-reverse">
              <Package className="h-4 w-4" />
              {t('المخزون', 'Inventory')}
            </TabsTrigger>
            <TabsTrigger value="requests" className="flex items-center gap-2 rtl:flex-row-reverse">
              <ClipboardList className="h-4 w-4" />
              {t('الطلبات', 'Requests')}
            </TabsTrigger>
          </TabsList>

          {/* INVENTORY TAB */}
          <TabsContent value="inventory" className="space-y-6">
            {/* Inventory Actions */}
            <div className="flex gap-2 rtl:flex-row-reverse flex-wrap">
              <Button variant="outline" onClick={generateInventoryPdfReport}>
                <FileDown className="h-4 w-4 me-2" />
                {t('تقرير PDF', 'PDF Report')}
              </Button>
              <Button onClick={() => { setEditingCategory(null); setIsCategoryFormOpen(true); }}>
                <Plus className="h-4 w-4 me-2" />
                {t('فئة جديدة', 'New Category')}
              </Button>
              <Button onClick={() => { setEditingItem(null); setIsItemFormOpen(true); }}>
                <Plus className="h-4 w-4 me-2" />
                {t('منتج جديد', 'New Item')}
              </Button>
            </div>

            {/* Inventory Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('إجمالي المنتجات', 'Total Items')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start">{items?.length || 0}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('الفئات', 'Categories')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start">{categories?.length || 0}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('مخزون منخفض', 'Low Stock')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start text-yellow-600">
                    {items?.filter(i => i.available_quantity > 0 && i.available_quantity <= 5).length || 0}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('نفذ من المخزن', 'Out of Stock')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start text-destructive">
                    {items?.filter(i => i.available_quantity === 0).length || 0}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="items" className="w-full">
              <TabsList className="flex-wrap h-auto gap-2 p-2">
                <TabsTrigger value="items" className="flex items-center gap-2 rtl:flex-row-reverse">
                  <Package className="h-4 w-4" />
                  {t('المنتجات', 'Items')}
                </TabsTrigger>
                <TabsTrigger value="categories" className="flex items-center gap-2 rtl:flex-row-reverse">
                  <FolderOpen className="h-4 w-4" />
                  {t('الفئات', 'Categories')}
                </TabsTrigger>
              </TabsList>

              {/* Items Sub-Tab */}
              <TabsContent value="items" className="space-y-4">
                <Card>
                  <CardContent className="pt-4">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="flex-1 relative">
                        <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder={t('بحث...', 'Search...')}
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="ps-10"
                        />
                      </div>
                      <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                        <SelectTrigger className="w-full sm:w-[180px]">
                          <SelectValue placeholder={t('الفئة', 'Category')} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('كل الفئات', 'All Categories')}</SelectItem>
                          {categories?.map((cat) => (
                            <SelectItem key={cat.id} value={cat.id}>
                              {language === 'ar' ? cat.name : cat.name_en || cat.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Select value={typeFilter} onValueChange={(v: any) => setTypeFilter(v)}>
                        <SelectTrigger className="w-full sm:w-[150px]">
                          <SelectValue placeholder={t('النوع', 'Type')} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('كل الأنواع', 'All Types')}</SelectItem>
                          <SelectItem value="reusable">{t('قابل للإرجاع', 'Reusable')}</SelectItem>
                          <SelectItem value="disposable">{t('مستهلك', 'Disposable')}</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select value={statusFilter} onValueChange={(v: any) => setStatusFilter(v)}>
                        <SelectTrigger className="w-full sm:w-[150px]">
                          <SelectValue placeholder={t('الحالة', 'Status')} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">{t('كل الحالات', 'All Status')}</SelectItem>
                          <SelectItem value="in-stock">{t('متوفر', 'In Stock')}</SelectItem>
                          <SelectItem value="low">{t('منخفض', 'Low')}</SelectItem>
                          <SelectItem value="out">{t('نفذ', 'Out')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-4">
                    {filteredItems?.length === 0 ? (
                      <div className="text-center py-12 text-muted-foreground">
                        {t('لا توجد منتجات', 'No items found')}
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>{t('المنتج', 'Item')}</TableHead>
                              <TableHead>{t('الفئة', 'Category')}</TableHead>
                              <TableHead>{t('النوع', 'Type')}</TableHead>
                              <TableHead>{t('الكمية الكلية', 'Total Qty')}</TableHead>
                              <TableHead>{t('المتوفر', 'Available')}</TableHead>
                              <TableHead>{t('الحالة', 'Status')}</TableHead>
                              <TableHead className="w-[100px]">{t('إجراءات', 'Actions')}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredItems?.map((item) => (
                              <TableRow key={item.id}>
                                <TableCell className="font-medium">
                                  <div>
                                    {language === 'ar' ? item.name : item.name_en || item.name}
                                  </div>
                                  {item.description && (
                                    <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                                      {item.description}
                                    </p>
                                  )}
                                </TableCell>
                                <TableCell>
                                  {item.category 
                                    ? (language === 'ar' ? item.category.name : item.category.name_en || item.category.name)
                                    : '-'}
                                </TableCell>
                                <TableCell>{getTypeBadge(item.item_type)}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>{item.available_quantity}</TableCell>
                                <TableCell>{getStatusBadge(item)}</TableCell>
                                <TableCell>
                                  <div className="flex gap-1 rtl:flex-row-reverse">
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => {
                                        setEditingItem(item);
                                        setIsItemFormOpen(true);
                                      }}
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="text-destructive"
                                      onClick={() => {
                                        if (confirm(t('هل أنت متأكد من الحذف؟', 'Are you sure you want to delete?'))) {
                                          deleteItemMutation.mutate(item.id);
                                        }
                                      }}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Categories Sub-Tab */}
              <TabsContent value="categories" className="space-y-4">
                <Card>
                  <CardContent className="pt-4">
                    {categories?.length === 0 ? (
                      <div className="text-center py-12 text-muted-foreground">
                        {t('لا توجد فئات', 'No categories yet')}
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>{t('الاسم', 'Name')}</TableHead>
                              <TableHead>{t('الوصف', 'Description')}</TableHead>
                              <TableHead>{t('عدد المنتجات', 'Items Count')}</TableHead>
                              <TableHead className="w-[100px]">{t('إجراءات', 'Actions')}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {categories?.map((category) => (
                              <TableRow key={category.id}>
                                <TableCell className="font-medium">
                                  {language === 'ar' ? category.name : category.name_en || category.name}
                                </TableCell>
                                <TableCell className="max-w-[300px] truncate">
                                  {category.description || '-'}
                                </TableCell>
                                <TableCell>
                                  {items?.filter(i => i.category_id === category.id).length || 0}
                                </TableCell>
                                <TableCell>
                                  <div className="flex gap-1 rtl:flex-row-reverse">
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => {
                                        setEditingCategory(category);
                                        setIsCategoryFormOpen(true);
                                      }}
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="text-destructive"
                                      onClick={() => {
                                        if (confirm(t('هل أنت متأكد من الحذف؟', 'Are you sure you want to delete?'))) {
                                          deleteCategoryMutation.mutate(category.id);
                                        }
                                      }}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </TabsContent>

          {/* REQUESTS TAB */}
          <TabsContent value="requests" className="space-y-6">
            {/* Requests Actions */}
            <div className="flex gap-2 rtl:flex-row-reverse">
              <Button variant="outline" onClick={generateRequestsPdfReport}>
                <FileDown className="h-4 w-4 me-2" />
                {t('تقرير PDF', 'PDF Report')}
              </Button>
            </div>

            {/* Requests Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('قيد الانتظار', 'Pending')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start">
                    {requests?.filter(r => r.status === 'pending').length || 0}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('قيد المراجعة', 'Processing')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start">
                    {requests?.filter(r => r.status === 'processing' || r.status === 'approved').length || 0}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('تم التسليم', 'Delivered')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start">
                    {requests?.filter(r => r.status === 'delivered').length || 0}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                    {t('مغلقة', 'Closed')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-start">
                    {requests?.filter(r => r.status === 'closed').length || 0}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Requests Filters */}
            <Card>
              <CardContent className="pt-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={t('بحث بالبرنامج أو الطالب...', 'Search by program or requester...')}
                      value={requestSearchQuery}
                      onChange={(e) => setRequestSearchQuery(e.target.value)}
                      className="ps-10"
                    />
                  </div>
                  <Select value={requestStatusFilter} onValueChange={(v: any) => setRequestStatusFilter(v)}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder={t('الحالة', 'Status')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('كل الحالات', 'All Status')}</SelectItem>
                      <SelectItem value="pending">{t('قيد الانتظار', 'Pending')}</SelectItem>
                      <SelectItem value="processing">{t('قيد المراجعة', 'Processing')}</SelectItem>
                      <SelectItem value="approved">{t('تمت الموافقة', 'Approved')}</SelectItem>
                      <SelectItem value="delivered">{t('تم التسليم', 'Delivered')}</SelectItem>
                      <SelectItem value="returned">{t('تم الإرجاع', 'Returned')}</SelectItem>
                      <SelectItem value="closed">{t('مغلق', 'Closed')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Requests Table */}
            <Card>
              <CardContent className="pt-4">
                {filteredRequests?.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    {t('لا توجد طلبات', 'No requests found')}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{t('البرنامج', 'Program')}</TableHead>
                          <TableHead>{t('تاريخ اللقاء', 'Session Date')}</TableHead>
                          <TableHead>{t('مقدم الطلب', 'Requester')}</TableHead>
                          <TableHead>{t('الحالة', 'Status')}</TableHead>
                          <TableHead>{t('تاريخ الإنشاء', 'Created')}</TableHead>
                          <TableHead>{t('المنتجات', 'Items')}</TableHead>
                          <TableHead className="w-[100px]">{t('إجراءات', 'Actions')}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredRequests?.map((request) => (
                          <TableRow key={request.id}>
                            <TableCell className="font-medium">
                              {language === 'ar' ? request.program?.name : request.program?.name_en || request.program?.name}
                            </TableCell>
                            <TableCell>{formatDate(request.session?.session_date || null)}</TableCell>
                            <TableCell>{request.requester?.full_name || '-'}</TableCell>
                            <TableCell>
                              <RequestStatusBadge status={request.status} />
                            </TableCell>
                            <TableCell>{formatDate(request.created_at)}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{request.items?.length || 0}</Badge>
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openDetailDialog(request)}
                              >
                                {t('عرض', 'View')}
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Category Form Dialog */}
      <CategoryForm
        open={isCategoryFormOpen}
        onOpenChange={(open) => {
          setIsCategoryFormOpen(open);
          if (!open) setEditingCategory(null);
        }}
        category={editingCategory}
        onSubmit={handleCategorySubmit}
        isLoading={createCategoryMutation.isPending || updateCategoryMutation.isPending}
      />

      {/* Item Form Dialog */}
      <ItemForm
        open={isItemFormOpen}
        onOpenChange={(open) => {
          setIsItemFormOpen(open);
          if (!open) setEditingItem(null);
        }}
        item={editingItem}
        categories={categories || []}
        onSubmit={handleItemSubmit}
        isLoading={createItemMutation.isPending || updateItemMutation.isPending}
      />

      {/* Request Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between rtl:flex-row-reverse">
              <span>{t('تفاصيل الطلب', 'Request Details')}</span>
              <RequestStatusBadge status={selectedRequest?.status || 'pending'} />
            </DialogTitle>
          </DialogHeader>

          {selectedRequest && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <Label className="text-muted-foreground">{t('البرنامج', 'Program')}</Label>
                  <p className="font-medium">
                    {language === 'ar' ? selectedRequest.program?.name : selectedRequest.program?.name_en || selectedRequest.program?.name}
                  </p>
                </div>
                <div>
                  <Label className="text-muted-foreground">{t('تاريخ اللقاء', 'Session Date')}</Label>
                  <p className="font-medium">{formatDate(selectedRequest.session?.session_date || null)}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">{t('مقدم الطلب', 'Requester')}</Label>
                  <p className="font-medium">{selectedRequest.requester?.full_name}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground">{t('تاريخ الإنشاء', 'Created')}</Label>
                  <p className="font-medium">{formatDate(selectedRequest.created_at)}</p>
                </div>
              </div>

              {selectedRequest.notes && (
                <div>
                  <Label className="text-muted-foreground">{t('ملاحظات', 'Notes')}</Label>
                  <p className="text-sm">{selectedRequest.notes}</p>
                </div>
              )}

              <div className="space-y-3">
                <Label>{t('المنتجات', 'Items')}</Label>
                <Accordion type="single" collapsible className="w-full">
                  {selectedRequest.items?.map((item) => (
                    <AccordionItem key={item.id} value={item.id}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center gap-3 rtl:flex-row-reverse text-start">
                          <span className="font-medium">
                            {item.custom_item_name || (
                              language === 'ar' ? item.item?.name : item.item?.name_en || item.item?.name
                            )}
                          </span>
                          <Badge variant="outline">x{item.quantity_requested}</Badge>
                          <RequestStatusBadge status={item.status} type="item" />
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-3 pt-2">
                          {(selectedRequest.status === 'pending' || selectedRequest.status === 'processing') && (
                            <>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <Label>{t('الكمية الموافق عليها', 'Approved Quantity')}</Label>
                                  <Input
                                    type="number"
                                    min="0"
                                    max={item.quantity_requested}
                                    value={itemUpdates[item.id]?.quantity_approved ?? item.quantity_requested}
                                    onChange={(e) => setItemUpdates({
                                      ...itemUpdates,
                                      [item.id]: {
                                        ...itemUpdates[item.id],
                                        quantity_approved: parseInt(e.target.value) || 0,
                                      }
                                    })}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label>{t('الحالة', 'Status')}</Label>
                                  <Select
                                    value={itemUpdates[item.id]?.status || item.status}
                                    onValueChange={(v: RequestItemStatus) => setItemUpdates({
                                      ...itemUpdates,
                                      [item.id]: {
                                        ...itemUpdates[item.id],
                                        status: v,
                                      }
                                    })}
                                  >
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="pending">{t('قيد الانتظار', 'Pending')}</SelectItem>
                                      <SelectItem value="approved">{t('موافق', 'Approved')}</SelectItem>
                                      <SelectItem value="partially_approved">{t('موافقة جزئية', 'Partially Approved')}</SelectItem>
                                      <SelectItem value="unavailable">{t('غير متوفر', 'Unavailable')}</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                              <div className="space-y-2">
                                <Label>{t('ملاحظات', 'Notes')}</Label>
                                <Textarea
                                  value={itemUpdates[item.id]?.notes || ''}
                                  onChange={(e) => setItemUpdates({
                                    ...itemUpdates,
                                    [item.id]: {
                                      ...itemUpdates[item.id],
                                      notes: e.target.value,
                                    }
                                  })}
                                  rows={2}
                                />
                              </div>
                            </>
                          )}

                          {selectedRequest.status === 'delivered' && item.item?.item_type === 'reusable' && item.status === 'delivered' && (
                            <div className="flex gap-2 rtl:flex-row-reverse">
                              <Button
                                size="sm"
                                onClick={() => markItemReturnedMutation.mutate({
                                  itemId: item.id,
                                  quantityReturned: item.quantity_approved || item.quantity_requested,
                                  itemOriginalId: item.item_id!
                                })}
                              >
                                <Undo className="h-4 w-4 me-1" />
                                {t('تسجيل إرجاع', 'Mark Returned')}
                              </Button>
                            </div>
                          )}

                          {item.status === 'returned' && (
                            <p className="text-sm text-green-600">
                              {t('تم إرجاع', 'Returned')}: {item.quantity_returned}
                            </p>
                          )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>

              <div className="flex gap-3 pt-4 rtl:flex-row-reverse flex-wrap">
                {(selectedRequest.status === 'pending' || selectedRequest.status === 'processing') && (
                  <>
                    <Button onClick={handleSaveItemUpdates} disabled={updateRequestItemsMutation.isPending}>
                      {updateRequestItemsMutation.isPending && <Loader2 className="h-4 w-4 me-2 animate-spin" />}
                      {t('حفظ التغييرات', 'Save Changes')}
                    </Button>
                    <Button variant="default" onClick={handleApproveRequest}>
                      <Check className="h-4 w-4 me-1" />
                      {t('الموافقة على الطلب', 'Approve Request')}
                    </Button>
                  </>
                )}

                {selectedRequest.status === 'approved' && (
                  <Button onClick={() => markAsDeliveredMutation.mutate(selectedRequest)}>
                    <Package className="h-4 w-4 me-1" />
                    {t('تسجيل التسليم', 'Mark as Delivered')}
                  </Button>
                )}

                {(selectedRequest.status === 'delivered' || selectedRequest.status === 'returned') && (
                  <Button onClick={() => closeRequestMutation.mutate(selectedRequest.id)}>
                    {t('إغلاق الطلب', 'Close Request')}
                  </Button>
                )}

                <Button variant="outline" onClick={() => setIsDetailDialogOpen(false)}>
                  {t('إغلاق', 'Close')}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
