import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, Calendar, MapPin, FileText, BookOpen, Clock, Loader2 } from 'lucide-react';
import { format, parseISO, isAfter } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';

interface Announcement {
  id: string;
  title: string;
  title_en: string | null;
  content: string;
  content_en: string | null;
  is_global: boolean;
  created_at: string;
  expires_at: string | null;
  program_id: string | null;
  program?: {
    name: string;
    name_en: string | null;
  };
}

interface UpcomingSession {
  id: string;
  session_date: string;
  location: string | null;
  notes: string | null;
  program: {
    id: string;
    name: string;
    name_en: string | null;
  };
}

export default function StudentDashboard() {
  const { language, t } = useLanguage();
  const { user } = useAuth();

  // Fetch student record
  const { data: student, isLoading: loadingStudent } = useQuery({
    queryKey: ['student-record', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('students')
        .select('id, full_name')
        .eq('user_id', user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user
  });

  // Fetch announcements
  const { data: announcements, isLoading: loadingAnnouncements } = useQuery({
    queryKey: ['student-announcements', student?.id],
    queryFn: async () => {
      if (!student) return [];
      const { data, error } = await supabase
        .from('announcements')
        .select('*, program:programs(name, name_en)')
        .order('created_at', { ascending: false });
      if (error) throw error;
      
      // Filter out expired announcements
      const now = new Date();
      return (data as unknown as Announcement[]).filter(a => 
        !a.expires_at || isAfter(parseISO(a.expires_at), now)
      );
    },
    enabled: !!student
  });

  // Fetch enrolled programs
  const { data: enrolledPrograms } = useQuery({
    queryKey: ['student-enrolled-programs', student?.id],
    queryFn: async () => {
      if (!student) return [];
      const { data, error } = await supabase
        .from('registration_requests')
        .select('program:programs(id, name, name_en)')
        .eq('student_id', student.id)
        .eq('status', 'approved');
      if (error) throw error;
      return data;
    },
    enabled: !!student
  });

  // Fetch upcoming sessions
  const { data: upcomingSessions, isLoading: loadingSessions } = useQuery({
    queryKey: ['student-upcoming-sessions', student?.id],
    queryFn: async () => {
      if (!student) return [];
      
      // Get program IDs from enrolled programs
      const { data: registrations, error: regError } = await supabase
        .from('registration_requests')
        .select('program_id')
        .eq('student_id', student.id)
        .eq('status', 'approved');
      
      if (regError || !registrations || registrations.length === 0) return [];
      
      const programIds = registrations.map(r => r.program_id);
      const today = new Date().toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('sessions')
        .select('id, session_date, location, notes, program:programs(id, name, name_en)')
        .in('program_id', programIds)
        .gte('session_date', today)
        .order('session_date', { ascending: true })
        .limit(10);
      
      if (error) throw error;
      return data as unknown as UpcomingSession[];
    },
    enabled: !!student
  });

  const isLoading = loadingStudent || loadingAnnouncements || loadingSessions;
  const enrolledCount = enrolledPrograms?.length || 0;
  const nextSession = upcomingSessions?.[0];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3 rtl:flex-row-reverse">
          <Bell className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              {t('لوحة التحكم', 'Dashboard')}
            </h1>
            <p className="text-muted-foreground">
              {student 
                ? t(`مرحباً ${student.full_name}`, `Welcome ${student.full_name}`)
                : t('مرحباً بك في بوابة الطلاب', 'Welcome to the Student Portal')}
            </p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center min-h-[40vh]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Quick Stats */}
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 rtl:flex-row-reverse">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <BookOpen className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">
                        {t('البرامج المسجلة', 'Enrolled Programs')}
                      </p>
                      <p className="text-2xl font-bold">{enrolledCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 rtl:flex-row-reverse">
                    <div className="p-3 rounded-lg bg-accent/10">
                      <Clock className="h-6 w-6 text-accent-foreground" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">
                        {t('اللقاء القادم', 'Next Session')}
                      </p>
                      <p className="text-lg font-bold">
                        {nextSession
                          ? format(parseISO(nextSession.session_date), 'dd MMM yyyy', {
                              locale: language === 'ar' ? ar : enUS
                            })
                          : t('لا يوجد', 'None')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              {/* Next Session Details */}
              {nextSession && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
                      <Calendar className="h-5 w-5 text-primary" />
                      {t('اللقاء القادم', 'Next Session')}
                    </CardTitle>
                    <CardDescription>
                      {t('تفاصيل الجلسة القادمة', 'Details of your next session')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="p-4 rounded-lg border bg-card">
                      <div className="flex items-start justify-between gap-2 rtl:flex-row-reverse">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-lg">
                            {language === 'ar'
                              ? nextSession.program.name
                              : nextSession.program.name_en || nextSession.program.name}
                          </h4>
                          <Badge variant="outline" className="mt-2">
                            {format(parseISO(nextSession.session_date), 'EEEE, dd MMMM yyyy', {
                              locale: language === 'ar' ? ar : enUS
                            })}
                          </Badge>
                        </div>
                      </div>
                      
                      {(nextSession.location || nextSession.notes) && (
                        <div className="mt-4 pt-4 border-t space-y-3">
                          {nextSession.location && (
                            <div className="flex items-center gap-2 text-sm rtl:flex-row-reverse">
                              <MapPin className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                              <span>{nextSession.location}</span>
                            </div>
                          )}
                          {nextSession.notes && (
                            <div className="flex items-start gap-2 text-sm rtl:flex-row-reverse">
                              <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">{nextSession.notes}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Announcements Section */}
              <Card className={nextSession ? '' : 'lg:col-span-2'}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
                    <Bell className="h-5 w-5 text-primary" />
                    {t('الإعلانات والإشعارات', 'Announcements & Notifications')}
                    {announcements && announcements.length > 0 && (
                      <Badge variant="secondary" className="ms-2">
                        {announcements.length}
                      </Badge>
                    )}
                  </CardTitle>
                  <CardDescription>
                    {t('آخر الإعلانات والأخبار المهمة', 'Latest announcements and important news')}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!announcements || announcements.length === 0 ? (
                    <div className="text-center py-8">
                      <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">
                        {t('لا توجد إعلانات حالياً', 'No announcements at the moment')}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4 max-h-[400px] overflow-y-auto">
                      {announcements.map((announcement) => (
                        <div
                          key={announcement.id}
                          className="p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-2 rtl:flex-row-reverse">
                            <div className="flex-1">
                              <h4 className="font-medium">
                                {language === 'ar'
                                  ? announcement.title
                                  : announcement.title_en || announcement.title}
                              </h4>
                              <p className="text-sm text-muted-foreground mt-1">
                                {language === 'ar'
                                  ? announcement.content
                                  : announcement.content_en || announcement.content}
                              </p>
                              <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground rtl:flex-row-reverse">
                                <span>
                                  {format(parseISO(announcement.created_at), 'dd MMM yyyy', {
                                    locale: language === 'ar' ? ar : enUS
                                  })}
                                </span>
                                {announcement.program && (
                                  <Badge variant="outline" className="text-xs">
                                    {language === 'ar'
                                      ? announcement.program.name
                                      : announcement.program.name_en || announcement.program.name}
                                  </Badge>
                                )}
                              </div>
                            </div>
                            {announcement.is_global && (
                              <Badge className="flex-shrink-0">
                                {t('عام', 'Global')}
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Upcoming Sessions List */}
            {upcomingSessions && upcomingSessions.length > 1 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
                    <Calendar className="h-5 w-5 text-primary" />
                    {t('اللقاءات القادمة', 'Upcoming Sessions')}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {upcomingSessions.slice(1).map((session) => (
                      <div
                        key={session.id}
                        className="p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2 rtl:flex-row-reverse">
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium truncate">
                              {language === 'ar'
                                ? session.program.name
                                : session.program.name_en || session.program.name}
                            </h4>
                            {session.location && (
                              <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1 rtl:flex-row-reverse">
                                <MapPin className="h-3 w-3" />
                                {session.location}
                              </p>
                            )}
                          </div>
                          <Badge variant="outline" className="flex-shrink-0">
                            {format(parseISO(session.session_date), 'dd MMM', {
                              locale: language === 'ar' ? ar : enUS
                            })}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
