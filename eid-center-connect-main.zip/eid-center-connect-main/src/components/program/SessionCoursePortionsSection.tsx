import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { BookOpen } from 'lucide-react';

interface SessionCoursePortionsSectionProps {
  sessionId: string;
  programId: string;
  canEdit: boolean;
  onPortionsChange?: (portions: CoursePortion[]) => void;
}

interface ProgramCourse {
  id: string;
  name: string;
  name_en: string | null;
}

interface CoursePortion {
  id?: string;
  session_id: string;
  course_id: string;
  portion_from: string;
  portion_to: string;
  is_completed: boolean;
  completion_notes: string;
}

export function SessionCoursePortionsSection({ 
  sessionId, 
  programId, 
  canEdit,
  onPortionsChange 
}: SessionCoursePortionsSectionProps) {
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  
  const [localPortions, setLocalPortions] = useState<CoursePortion[]>([]);

  // Fetch program courses
  const { data: courses } = useQuery({
    queryKey: ['program-courses', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('program_courses')
        .select('id, name, name_en')
        .eq('program_id', programId)
        .order('order_index', { ascending: true });
      if (error) throw error;
      return data as ProgramCourse[];
    },
    enabled: !!programId
  });

  // Fetch existing course portions for this session
  const { data: existingPortions } = useQuery({
    queryKey: ['session-course-portions', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('session_course_portions')
        .select('*')
        .eq('session_id', sessionId);
      if (error) throw error;
      return data as CoursePortion[];
    },
    enabled: !!sessionId
  });

  // Initialize local portions from existing data
  useEffect(() => {
    if (existingPortions) {
      setLocalPortions(existingPortions.map(p => ({
        id: p.id,
        session_id: p.session_id,
        course_id: p.course_id,
        portion_from: p.portion_from || '',
        portion_to: p.portion_to || '',
        is_completed: p.is_completed || false,
        completion_notes: p.completion_notes || ''
      })));
    }
  }, [existingPortions]);

  // Notify parent of changes
  useEffect(() => {
    onPortionsChange?.(localPortions);
  }, [localPortions, onPortionsChange]);

  const updatePortion = (courseId: string, field: keyof CoursePortion, value: string | boolean) => {
    setLocalPortions(prev => {
      const existingIndex = prev.findIndex(p => p.course_id === courseId);
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex] = { ...updated[existingIndex], [field]: value };
        return updated;
      } else {
        return [...prev, {
          session_id: sessionId,
          course_id: courseId,
          portion_from: '',
          portion_to: '',
          is_completed: false,
          completion_notes: '',
          [field]: value
        }];
      }
    });
  };

  const getPortionForCourse = (courseId: string) => {
    return localPortions.find(p => p.course_id === courseId) || {
      session_id: sessionId,
      course_id: courseId,
      portion_from: '',
      portion_to: '',
      is_completed: false,
      completion_notes: ''
    };
  };

  if (!courses || courses.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-6 text-center text-muted-foreground">
          {language === 'ar' ? 'لا توجد مقررات للبرنامج' : 'No courses in program'}
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 rtl:flex-row-reverse">
        <BookOpen className="h-5 w-5" />
        <h4 className="font-medium">
          {language === 'ar' ? 'حصص المقررات' : 'Course Portions'}
        </h4>
      </div>

      <div className="space-y-3">
        {courses.map(course => {
          const portion = getPortionForCourse(course.id);
          return (
            <Card key={course.id} className={portion.is_completed ? 'border-green-500/50 bg-green-50/30 dark:bg-green-950/10' : ''}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between rtl:flex-row-reverse">
                  <CardTitle className="text-sm font-medium">
                    {language === 'ar' ? course.name : course.name_en || course.name}
                  </CardTitle>
                  <div className="flex items-center gap-2 rtl:flex-row-reverse">
                    <Checkbox
                      id={`completed-${course.id}`}
                      checked={portion.is_completed}
                      onCheckedChange={(checked) => updatePortion(course.id, 'is_completed', !!checked)}
                      disabled={!canEdit}
                    />
                    <Label htmlFor={`completed-${course.id}`} className="text-sm">
                      {language === 'ar' ? 'تم' : 'Done'}
                    </Label>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">
                      {language === 'ar' ? 'من' : 'From'}
                    </Label>
                    <Input
                      value={portion.portion_from}
                      onChange={(e) => updatePortion(course.id, 'portion_from', e.target.value)}
                      placeholder={language === 'ar' ? 'مثال: صفحة 1' : 'e.g., Page 1'}
                      disabled={!canEdit}
                      className="h-8 text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">
                      {language === 'ar' ? 'إلى' : 'To'}
                    </Label>
                    <Input
                      value={portion.portion_to}
                      onChange={(e) => updatePortion(course.id, 'portion_to', e.target.value)}
                      placeholder={language === 'ar' ? 'مثال: صفحة 10' : 'e.g., Page 10'}
                      disabled={!canEdit}
                      className="h-8 text-sm"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">
                    {language === 'ar' ? 'ملاحظات' : 'Notes'}
                  </Label>
                  <Textarea
                    value={portion.completion_notes}
                    onChange={(e) => updatePortion(course.id, 'completion_notes', e.target.value)}
                    placeholder={language === 'ar' ? 'ملاحظات...' : 'Notes...'}
                    disabled={!canEdit}
                    rows={2}
                    className="text-sm"
                  />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// Utility function to save course portions (to be used by parent components)
export async function saveSessionCoursePortions(
  sessionId: string, 
  portions: CoursePortion[]
): Promise<void> {
  // Filter only portions that have some data
  const portionsToSave = portions.filter(p => 
    p.portion_from || p.portion_to || p.is_completed || p.completion_notes
  );

  for (const portion of portionsToSave) {
    const { id, ...data } = portion;
    
    if (id) {
      // Update existing
      await supabase.from('session_course_portions').update({
        portion_from: data.portion_from || null,
        portion_to: data.portion_to || null,
        is_completed: data.is_completed,
        completion_notes: data.completion_notes || null
      }).eq('id', id);
    } else {
      // Check if exists then insert
      const { data: existing } = await supabase
        .from('session_course_portions')
        .select('id')
        .eq('session_id', sessionId)
        .eq('course_id', data.course_id)
        .maybeSingle();
      
      if (existing) {
        await supabase.from('session_course_portions').update({
          portion_from: data.portion_from || null,
          portion_to: data.portion_to || null,
          is_completed: data.is_completed,
          completion_notes: data.completion_notes || null
        }).eq('id', existing.id);
      } else {
        await supabase.from('session_course_portions').insert({
          session_id: sessionId,
          course_id: data.course_id,
          portion_from: data.portion_from || null,
          portion_to: data.portion_to || null,
          is_completed: data.is_completed,
          completion_notes: data.completion_notes || null
        });
      }
    }
  }
}
