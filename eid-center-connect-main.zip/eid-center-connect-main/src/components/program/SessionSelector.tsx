import { useLanguage } from '@/contexts/LanguageContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

interface Session {
  id: string;
  session_date: string | null;
  session_number: number | null;
  location: string | null;
}

interface SessionSelectorProps {
  sessions: Session[];
  selectedSessionId: string | null;
  onSessionChange: (sessionId: string) => void;
  placeholder?: string;
}

export function SessionSelector({ 
  sessions, 
  selectedSessionId, 
  onSessionChange,
  placeholder 
}: SessionSelectorProps) {
  const { language } = useLanguage();

  const formatSessionLabel = (session: Session) => {
    const number = session.session_number ? `#${session.session_number}` : '';
    const date = session.session_date 
      ? format(new Date(session.session_date), 'PPP', { locale: language === 'ar' ? ar : undefined })
      : '';
    const location = session.location || '';
    
    const parts = [number, date, location].filter(Boolean);
    return parts.join(' - ') || (language === 'ar' ? 'لقاء' : 'Session');
  };

  return (
    <Select value={selectedSessionId || ''} onValueChange={onSessionChange}>
      <SelectTrigger className="w-full md:w-[300px]">
        <SelectValue placeholder={placeholder || (language === 'ar' ? 'اختر لقاء' : 'Select a session')} />
      </SelectTrigger>
      <SelectContent>
        {sessions.map((session) => (
          <SelectItem key={session.id} value={session.id}>
            {formatSessionLabel(session)}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
