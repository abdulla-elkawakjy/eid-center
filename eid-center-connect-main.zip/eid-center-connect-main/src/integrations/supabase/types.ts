export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      announcements: {
        Row: {
          content: string
          content_en: string | null
          created_at: string | null
          created_by: string | null
          expires_at: string | null
          id: string
          is_global: boolean | null
          program_id: string | null
          title: string
          title_en: string | null
        }
        Insert: {
          content: string
          content_en?: string | null
          created_at?: string | null
          created_by?: string | null
          expires_at?: string | null
          id?: string
          is_global?: boolean | null
          program_id?: string | null
          title: string
          title_en?: string | null
        }
        Update: {
          content?: string
          content_en?: string | null
          created_at?: string | null
          created_by?: string | null
          expires_at?: string | null
          id?: string
          is_global?: boolean | null
          program_id?: string | null
          title?: string
          title_en?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "announcements_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
        ]
      }
      assessment_criteria: {
        Row: {
          created_at: string
          criterion_scope: Database["public"]["Enums"]["criterion_scope"]
          criterion_type: Database["public"]["Enums"]["criterion_type"]
          id: string
          max_score: number
          name: string
          name_en: string | null
          program_id: string
          updated_at: string
          weight: number
        }
        Insert: {
          created_at?: string
          criterion_scope: Database["public"]["Enums"]["criterion_scope"]
          criterion_type: Database["public"]["Enums"]["criterion_type"]
          id?: string
          max_score?: number
          name: string
          name_en?: string | null
          program_id: string
          updated_at?: string
          weight?: number
        }
        Update: {
          created_at?: string
          criterion_scope?: Database["public"]["Enums"]["criterion_scope"]
          criterion_type?: Database["public"]["Enums"]["criterion_type"]
          id?: string
          max_score?: number
          name?: string
          name_en?: string | null
          program_id?: string
          updated_at?: string
          weight?: number
        }
        Relationships: [
          {
            foreignKeyName: "assessment_criteria_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
        ]
      }
      course_files: {
        Row: {
          course_id: string
          created_at: string
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id: string
          uploaded_by: string
        }
        Insert: {
          course_id: string
          created_at?: string
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id?: string
          uploaded_by: string
        }
        Update: {
          course_id?: string
          created_at?: string
          file_name?: string
          file_path?: string
          file_size?: number
          file_type?: string
          id?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_files_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "program_courses"
            referencedColumns: ["id"]
          },
        ]
      }
      group_scores: {
        Row: {
          created_at: string
          criterion_id: string
          group_id: string
          id: string
          notes: string | null
          score: number
          scored_by: string | null
          session_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          criterion_id: string
          group_id: string
          id?: string
          notes?: string | null
          score: number
          scored_by?: string | null
          session_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          criterion_id?: string
          group_id?: string
          id?: string
          notes?: string | null
          score?: number
          scored_by?: string | null
          session_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_scores_criterion_id_fkey"
            columns: ["criterion_id"]
            isOneToOne: false
            referencedRelation: "assessment_criteria"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_scores_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "student_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_scores_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          full_name: string
          id: string
          mother_phone: string | null
          nationality: string | null
          phone: string | null
          preferred_language: string | null
          qid_number: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email: string
          full_name: string
          id?: string
          mother_phone?: string | null
          nationality?: string | null
          phone?: string | null
          preferred_language?: string | null
          qid_number?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          mother_phone?: string | null
          nationality?: string | null
          phone?: string | null
          preferred_language?: string | null
          qid_number?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      program_courses: {
        Row: {
          created_at: string
          description: string | null
          description_en: string | null
          id: string
          name: string
          name_en: string | null
          order_index: number | null
          program_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          description_en?: string | null
          id?: string
          name: string
          name_en?: string | null
          order_index?: number | null
          program_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          description_en?: string | null
          id?: string
          name?: string
          name_en?: string | null
          order_index?: number | null
          program_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "program_courses_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
        ]
      }
      program_files: {
        Row: {
          created_at: string
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id: string
          program_id: string
          uploaded_by: string
          visibility: Database["public"]["Enums"]["file_visibility"]
        }
        Insert: {
          created_at?: string
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id?: string
          program_id: string
          uploaded_by: string
          visibility?: Database["public"]["Enums"]["file_visibility"]
        }
        Update: {
          created_at?: string
          file_name?: string
          file_path?: string
          file_size?: number
          file_type?: string
          id?: string
          program_id?: string
          uploaded_by?: string
          visibility?: Database["public"]["Enums"]["file_visibility"]
        }
        Relationships: [
          {
            foreignKeyName: "program_files_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
        ]
      }
      program_roles: {
        Row: {
          created_at: string
          id: string
          is_default: boolean | null
          name: string
          name_en: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_default?: boolean | null
          name: string
          name_en?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          is_default?: boolean | null
          name?: string
          name_en?: string | null
        }
        Relationships: []
      }
      programs: {
        Row: {
          age_range: string | null
          capacity: number | null
          created_at: string
          description: string | null
          description_en: string | null
          id: string
          name: string
          name_en: string | null
          registration_open: boolean | null
          semester_id: string
          updated_at: string
        }
        Insert: {
          age_range?: string | null
          capacity?: number | null
          created_at?: string
          description?: string | null
          description_en?: string | null
          id?: string
          name: string
          name_en?: string | null
          registration_open?: boolean | null
          semester_id: string
          updated_at?: string
        }
        Update: {
          age_range?: string | null
          capacity?: number | null
          created_at?: string
          description?: string | null
          description_en?: string | null
          id?: string
          name?: string
          name_en?: string | null
          registration_open?: boolean | null
          semester_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "programs_semester_id_fkey"
            columns: ["semester_id"]
            isOneToOne: false
            referencedRelation: "semesters"
            referencedColumns: ["id"]
          },
        ]
      }
      registration_requests: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          parent_id: string
          program_id: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["registration_status"]
          student_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          parent_id: string
          program_id: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["registration_status"]
          student_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          parent_id?: string
          program_id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["registration_status"]
          student_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "registration_requests_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "registration_requests_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      semesters: {
        Row: {
          created_at: string
          end_date: string
          id: string
          is_active: boolean | null
          name: string
          name_en: string | null
          start_date: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          end_date: string
          id?: string
          is_active?: boolean | null
          name: string
          name_en?: string | null
          start_date: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          end_date?: string
          id?: string
          is_active?: boolean | null
          name?: string
          name_en?: string | null
          start_date?: string
          updated_at?: string
        }
        Relationships: []
      }
      session_activities: {
        Row: {
          created_at: string
          end_time: string | null
          id: string
          name: string
          name_en: string | null
          order_index: number | null
          session_id: string
          start_time: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          end_time?: string | null
          id?: string
          name: string
          name_en?: string | null
          order_index?: number | null
          session_id: string
          start_time?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          end_time?: string | null
          id?: string
          name?: string
          name_en?: string | null
          order_index?: number | null
          session_id?: string
          start_time?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_activities_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      session_course_portions: {
        Row: {
          completion_notes: string | null
          course_id: string
          created_at: string
          id: string
          is_completed: boolean | null
          portion_from: string | null
          portion_to: string | null
          session_id: string
          updated_at: string
        }
        Insert: {
          completion_notes?: string | null
          course_id: string
          created_at?: string
          id?: string
          is_completed?: boolean | null
          portion_from?: string | null
          portion_to?: string | null
          session_id: string
          updated_at?: string
        }
        Update: {
          completion_notes?: string | null
          course_id?: string
          created_at?: string
          id?: string
          is_completed?: boolean | null
          portion_from?: string | null
          portion_to?: string | null
          session_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_course_portions_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "program_courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "session_course_portions_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      session_files: {
        Row: {
          created_at: string
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id: string
          session_id: string
          uploaded_by: string
          visibility: Database["public"]["Enums"]["file_visibility"]
        }
        Insert: {
          created_at?: string
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id?: string
          session_id: string
          uploaded_by: string
          visibility?: Database["public"]["Enums"]["file_visibility"]
        }
        Update: {
          created_at?: string
          file_name?: string
          file_path?: string
          file_size?: number
          file_type?: string
          id?: string
          session_id?: string
          uploaded_by?: string
          visibility?: Database["public"]["Enums"]["file_visibility"]
        }
        Relationships: [
          {
            foreignKeyName: "session_files_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      session_reports: {
        Row: {
          courses_delivered: string | null
          created_at: string
          id: string
          notes: string | null
          session_id: string
          special_activities: string | null
          submitted_at: string | null
          submitted_by: string | null
          supervisor_attendance: Json | null
          updated_at: string
        }
        Insert: {
          courses_delivered?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          session_id: string
          special_activities?: string | null
          submitted_at?: string | null
          submitted_by?: string | null
          supervisor_attendance?: Json | null
          updated_at?: string
        }
        Update: {
          courses_delivered?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          session_id?: string
          special_activities?: string | null
          submitted_at?: string | null
          submitted_by?: string | null
          supervisor_attendance?: Json | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "session_reports_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: true
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      sessions: {
        Row: {
          assembly_time: string | null
          created_at: string
          dismissal_time: string | null
          id: string
          location: string | null
          notes: string | null
          planned_courses: string | null
          program_id: string
          session_date: string | null
          session_number: number | null
          updated_at: string
        }
        Insert: {
          assembly_time?: string | null
          created_at?: string
          dismissal_time?: string | null
          id?: string
          location?: string | null
          notes?: string | null
          planned_courses?: string | null
          program_id: string
          session_date?: string | null
          session_number?: number | null
          updated_at?: string
        }
        Update: {
          assembly_time?: string | null
          created_at?: string
          dismissal_time?: string | null
          id?: string
          location?: string | null
          notes?: string | null
          planned_courses?: string | null
          program_id?: string
          session_date?: string | null
          session_number?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sessions_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_assignments: {
        Row: {
          created_at: string
          id: string
          is_leader: boolean
          program_id: string
          role_id: string | null
          role_name: string | null
          role_name_en: string | null
          staff_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_leader?: boolean
          program_id: string
          role_id?: string | null
          role_name?: string | null
          role_name_en?: string | null
          staff_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_leader?: boolean
          program_id?: string
          role_id?: string | null
          role_name?: string | null
          role_name_en?: string | null
          staff_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_assignments_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "staff_assignments_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "program_roles"
            referencedColumns: ["id"]
          },
        ]
      }
      store_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          name_en: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          name_en?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          name_en?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      store_items: {
        Row: {
          available_quantity: number
          category_id: string | null
          created_at: string
          description: string | null
          id: string
          item_type: Database["public"]["Enums"]["item_type"]
          name: string
          name_en: string | null
          quantity: number
          updated_at: string
        }
        Insert: {
          available_quantity?: number
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          item_type?: Database["public"]["Enums"]["item_type"]
          name: string
          name_en?: string | null
          quantity?: number
          updated_at?: string
        }
        Update: {
          available_quantity?: number
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          item_type?: Database["public"]["Enums"]["item_type"]
          name?: string
          name_en?: string | null
          quantity?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "store_items_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "store_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      store_request_items: {
        Row: {
          created_at: string
          custom_item_name: string | null
          id: string
          item_id: string | null
          quantity_approved: number | null
          quantity_requested: number
          quantity_returned: number | null
          request_id: string
          status: Database["public"]["Enums"]["request_item_status"]
          store_keeper_notes: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          custom_item_name?: string | null
          id?: string
          item_id?: string | null
          quantity_approved?: number | null
          quantity_requested?: number
          quantity_returned?: number | null
          request_id: string
          status?: Database["public"]["Enums"]["request_item_status"]
          store_keeper_notes?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          custom_item_name?: string | null
          id?: string
          item_id?: string | null
          quantity_approved?: number | null
          quantity_requested?: number
          quantity_returned?: number | null
          request_id?: string
          status?: Database["public"]["Enums"]["request_item_status"]
          store_keeper_notes?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "store_request_items_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "store_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "store_request_items_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "store_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      store_requests: {
        Row: {
          closed_at: string | null
          created_at: string
          delivered_at: string | null
          id: string
          notes: string | null
          program_id: string
          requester_id: string
          session_id: string
          status: Database["public"]["Enums"]["store_request_status"]
          updated_at: string
        }
        Insert: {
          closed_at?: string | null
          created_at?: string
          delivered_at?: string | null
          id?: string
          notes?: string | null
          program_id: string
          requester_id: string
          session_id: string
          status?: Database["public"]["Enums"]["store_request_status"]
          updated_at?: string
        }
        Update: {
          closed_at?: string | null
          created_at?: string
          delivered_at?: string | null
          id?: string
          notes?: string | null
          program_id?: string
          requester_id?: string
          session_id?: string
          status?: Database["public"]["Enums"]["store_request_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "store_requests_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "store_requests_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      student_attendance: {
        Row: {
          created_at: string
          id: string
          is_present: boolean | null
          marked_by: string | null
          notes: string | null
          session_id: string
          student_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_present?: boolean | null
          marked_by?: string | null
          notes?: string | null
          session_id: string
          student_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_present?: boolean | null
          marked_by?: string | null
          notes?: string | null
          session_id?: string
          student_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_attendance_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_attendance_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_group_assignments: {
        Row: {
          created_at: string
          group_id: string
          id: string
          student_id: string
        }
        Insert: {
          created_at?: string
          group_id: string
          id?: string
          student_id: string
        }
        Update: {
          created_at?: string
          group_id?: string
          id?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_group_assignments_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "student_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_group_assignments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_groups: {
        Row: {
          created_at: string
          id: string
          name: string
          program_id: string
          supervisor_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          program_id: string
          supervisor_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          program_id?: string
          supervisor_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_groups_program_id_fkey"
            columns: ["program_id"]
            isOneToOne: false
            referencedRelation: "programs"
            referencedColumns: ["id"]
          },
        ]
      }
      student_scores: {
        Row: {
          created_at: string
          criterion_id: string
          id: string
          notes: string | null
          score: number
          scored_by: string | null
          session_id: string | null
          student_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          criterion_id: string
          id?: string
          notes?: string | null
          score: number
          scored_by?: string | null
          session_id?: string | null
          student_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          criterion_id?: string
          id?: string
          notes?: string | null
          score?: number
          scored_by?: string | null
          session_id?: string | null
          student_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_scores_criterion_id_fkey"
            columns: ["criterion_id"]
            isOneToOne: false
            referencedRelation: "assessment_criteria"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_scores_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_scores_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      students: {
        Row: {
          created_at: string
          date_of_birth: string | null
          full_name: string
          gender: string | null
          has_health_conditions: boolean | null
          health_conditions_details: string | null
          id: string
          mobile_number: string | null
          nationality: string | null
          notes: string | null
          parent_id: string
          qid_number: string | null
          school_grade: number | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          date_of_birth?: string | null
          full_name: string
          gender?: string | null
          has_health_conditions?: boolean | null
          health_conditions_details?: string | null
          id?: string
          mobile_number?: string | null
          nationality?: string | null
          notes?: string | null
          parent_id: string
          qid_number?: string | null
          school_grade?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          date_of_birth?: string | null
          full_name?: string
          gender?: string | null
          has_health_conditions?: boolean | null
          health_conditions_details?: string | null
          id?: string
          mobile_number?: string | null
          nationality?: string | null
          notes?: string | null
          parent_id?: string
          qid_number?: string | null
          school_grade?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      supervisor_permissions: {
        Row: {
          assignment_id: string
          can_coordinate_catering: boolean | null
          can_edit_session_info: boolean | null
          can_enter_group_evaluation: boolean | null
          can_enter_individual_evaluation: boolean | null
          can_manage_criteria: boolean | null
          can_submit_session_report: boolean | null
          can_submit_store_request: boolean | null
          created_at: string
          id: string
          updated_at: string
        }
        Insert: {
          assignment_id: string
          can_coordinate_catering?: boolean | null
          can_edit_session_info?: boolean | null
          can_enter_group_evaluation?: boolean | null
          can_enter_individual_evaluation?: boolean | null
          can_manage_criteria?: boolean | null
          can_submit_session_report?: boolean | null
          can_submit_store_request?: boolean | null
          created_at?: string
          id?: string
          updated_at?: string
        }
        Update: {
          assignment_id?: string
          can_coordinate_catering?: boolean | null
          can_edit_session_info?: boolean | null
          can_enter_group_evaluation?: boolean | null
          can_enter_individual_evaluation?: boolean | null
          can_manage_criteria?: boolean | null
          can_submit_session_report?: boolean | null
          can_submit_store_request?: boolean | null
          created_at?: string
          id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "supervisor_permissions_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: true
            referencedRelation: "staff_assignments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff_assigned_to_program: {
        Args: { _program_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "staff" | "parent" | "student" | "store_keeper"
      criterion_scope: "individual" | "group"
      criterion_type: "daily" | "overall"
      file_visibility: "staff_only" | "staff_and_parents"
      item_type: "disposable" | "reusable"
      registration_status: "pending" | "approved" | "denied"
      request_item_status:
        | "pending"
        | "approved"
        | "partially_approved"
        | "unavailable"
        | "delivered"
        | "returned"
        | "missing"
        | "damaged"
      store_request_status:
        | "pending"
        | "processing"
        | "approved"
        | "delivered"
        | "returned"
        | "closed"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "staff", "parent", "student", "store_keeper"],
      criterion_scope: ["individual", "group"],
      criterion_type: ["daily", "overall"],
      file_visibility: ["staff_only", "staff_and_parents"],
      item_type: ["disposable", "reusable"],
      registration_status: ["pending", "approved", "denied"],
      request_item_status: [
        "pending",
        "approved",
        "partially_approved",
        "unavailable",
        "delivered",
        "returned",
        "missing",
        "damaged",
      ],
      store_request_status: [
        "pending",
        "processing",
        "approved",
        "delivered",
        "returned",
        "closed",
      ],
    },
  },
} as const
