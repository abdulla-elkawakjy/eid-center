import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import StaffLogin from "./pages/StaffLogin";
import StudentLogin from "./pages/StudentLogin";
import ParentAuth from "./pages/ParentAuth";
import Dashboard from "./pages/Dashboard";
import StaffManagement from "./pages/admin/StaffManagement";
import ParentsManagement from "./pages/admin/ParentsManagement";
import StudentsManagement from "./pages/admin/StudentsManagement";
import SemestersManagement from "./pages/admin/SemestersManagement";
import SemesterPrograms from "./pages/admin/SemesterPrograms";
import RegistrationRequests from "./pages/admin/RegistrationRequests";
import StaffAssignments from "./pages/staff/StaffAssignments";
import ProgramDetail from "./pages/staff/ProgramDetail";
import MyChildren from "./pages/parent/MyChildren";
import AvailablePrograms from "./pages/parent/AvailablePrograms";
import ChildProgress from "./pages/parent/ChildProgress";
import ParentDashboard from "./pages/parent/ParentDashboard";
import MyPrograms from "./pages/parent/MyPrograms";
import StudentDashboard from "./pages/student/StudentDashboard";
import StudentPrograms from "./pages/student/StudentPrograms";
import StoreManagement from "./pages/store/StoreManagement";
import ReportsManagement from "./pages/admin/ReportsManagement";
import AdminSetup from "./pages/AdminSetup";
import NotFound from "./pages/NotFound";
const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <LanguageProvider>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/admin-setup" element={<AdminSetup />} />
                <Route path="/staff-login" element={<StaffLogin />} />
                <Route path="/student-login" element={<StudentLogin />} />
                <Route path="/parent-auth" element={<ParentAuth />} />
                <Route path="/dashboard" element={<Dashboard />} />
                {/* Admin Routes */}
                <Route path="/dashboard/staff" element={<StaffManagement />} />
                <Route path="/dashboard/parents" element={<ParentsManagement />} />
                <Route path="/dashboard/students" element={<StudentsManagement />} />
                <Route path="/dashboard/programs" element={<SemestersManagement />} />
                <Route path="/dashboard/programs/semester/:semesterId" element={<SemesterPrograms />} />
                <Route path="/dashboard/registrations" element={<RegistrationRequests />} />
                {/* Staff Routes */}
                <Route path="/dashboard/assignments" element={<StaffAssignments />} />
                <Route path="/dashboard/program/:programId" element={<ProgramDetail />} />
                {/* Parent Routes */}
                <Route path="/parent/dashboard" element={<ParentDashboard />} />
                <Route path="/parent-dashboard" element={<ParentDashboard />} />
                <Route path="/parent/children" element={<MyChildren />} />
                <Route path="/parent/my-programs" element={<MyPrograms />} />
                <Route path="/parent/available-programs" element={<AvailablePrograms />} />
                <Route path="/parent/programs" element={<AvailablePrograms />} />
                <Route path="/parent/progress" element={<ChildProgress />} />
                {/* Student Routes */}
                <Route path="/student/dashboard" element={<StudentDashboard />} />
                <Route path="/student/programs" element={<StudentPrograms />} />
                {/* Admin Reports Route */}
                <Route path="/dashboard/reports" element={<ReportsManagement />} />
                {/* Store Routes */}
                <Route path="/store" element={<StoreManagement />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
