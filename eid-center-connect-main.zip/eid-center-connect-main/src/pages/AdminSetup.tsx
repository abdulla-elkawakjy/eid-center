import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CheckCircle2, AlertCircle, Shield, Users, UserCheck } from 'lucide-react';

interface SetupResult {
  email: string;
  password: string;
  role: string;
  status: 'pending' | 'success' | 'error';
  error?: string;
}

const TEST_ACCOUNTS = [
  { email: 'admin@school.com', password: 'Admin123!', role: 'admin' as const, fullName: 'System Administrator' },
  { email: 'staff@school.com', password: 'Staff123!', role: 'staff' as const, fullName: 'Test Staff Member' },
  { email: 'parent@school.com', password: 'Parent123!', role: 'parent' as const, fullName: 'Test Parent' },
];

export default function AdminSetup() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [setupComplete, setSetupComplete] = useState(false);
  const [results, setResults] = useState<SetupResult[]>([]);
  const [existingUsers, setExistingUsers] = useState<string[]>([]);

  useEffect(() => {
    checkExistingUsers();
  }, []);

  const checkExistingUsers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('email');
    
    if (data) {
      setExistingUsers(data.map(p => p.email));
    }
  };

  const createAccount = async (account: typeof TEST_ACCOUNTS[0]): Promise<SetupResult> => {
    const result: SetupResult = {
      email: account.email,
      password: account.password,
      role: account.role,
      status: 'pending'
    };

    try {
      // Check if user already exists
      if (existingUsers.includes(account.email)) {
        return { ...result, status: 'success', error: 'Already exists' };
      }

      // Create user via Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: account.email,
        password: account.password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            full_name: account.fullName,
          }
        }
      });

      if (authError) {
        return { ...result, status: 'error', error: authError.message };
      }

      if (!authData.user) {
        return { ...result, status: 'error', error: 'No user returned' };
      }

      // Create profile
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          user_id: authData.user.id,
          full_name: account.fullName,
          email: account.email,
        });

      if (profileError) {
        console.error('Profile error:', profileError);
      }

      // Assign role
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: authData.user.id,
          role: account.role,
        });

      if (roleError) {
        return { ...result, status: 'error', error: roleError.message };
      }

      return { ...result, status: 'success' };
    } catch (err: any) {
      return { ...result, status: 'error', error: err.message };
    }
  };

  const handleSetup = async () => {
    setLoading(true);
    const newResults: SetupResult[] = [];

    for (const account of TEST_ACCOUNTS) {
      const result = await createAccount(account);
      newResults.push(result);
      setResults([...newResults]);
    }

    // Create test children for the parent account
    const parentProfile = await supabase
      .from('profiles')
      .select('user_id')
      .eq('email', 'parent@school.com')
      .maybeSingle();

    if (parentProfile.data?.user_id) {
      const { error: childrenError } = await supabase
        .from('students')
        .insert([
          {
            parent_id: parentProfile.data.user_id,
            full_name: 'أحمد محمد',
            date_of_birth: '2015-03-15',
            gender: 'male',
          },
          {
            parent_id: parentProfile.data.user_id,
            full_name: 'فاطمة محمد',
            date_of_birth: '2017-07-22',
            gender: 'female',
          },
        ]);

      if (childrenError) {
        console.error('Children error:', childrenError);
      }
    }

    // Sign out after setup (we were signed in as the last created user)
    await supabase.auth.signOut();

    setSetupComplete(true);
    setLoading(false);

    toast({
      title: t('تم إعداد الحسابات بنجاح', 'Accounts Setup Complete'),
      description: t('يمكنك الآن تسجيل الدخول', 'You can now login'),
    });
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin':
        return <Shield className="h-5 w-5 text-red-500" />;
      case 'staff':
        return <UserCheck className="h-5 w-5 text-blue-500" />;
      case 'parent':
        return <Users className="h-5 w-5 text-green-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-lg animate-scale-in">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <Logo size="lg" />
          </div>
          <CardTitle className="text-2xl">
            {t('إعداد الحسابات التجريبية', 'Test Accounts Setup')}
          </CardTitle>
          <CardDescription>
            {t(
              'سيتم إنشاء حسابات تجريبية للمدير والموظفين وأولياء الأمور',
              'This will create test accounts for admin, staff, and parents'
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!setupComplete ? (
            <>
              <div className="space-y-3">
                {TEST_ACCOUNTS.map((account) => {
                  const result = results.find(r => r.email === account.email);
                  return (
                    <div
                      key={account.email}
                      className="flex items-center justify-between p-3 rounded-lg border bg-muted/30"
                    >
                      <div className="flex items-center gap-3">
                        {getRoleIcon(account.role)}
                        <div>
                          <p className="font-medium text-sm">{account.email}</p>
                          <p className="text-xs text-muted-foreground capitalize">{account.role}</p>
                        </div>
                      </div>
                      {result && (
                        result.status === 'success' ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                        ) : result.status === 'error' ? (
                          <AlertCircle className="h-5 w-5 text-red-500" />
                        ) : null
                      )}
                    </div>
                  );
                })}
              </div>

              <Button
                onClick={handleSetup}
                className="w-full"
                disabled={loading}
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 me-2 animate-spin" />
                    {t('جاري إنشاء الحسابات...', 'Creating accounts...')}
                  </>
                ) : (
                  t('إنشاء الحسابات التجريبية', 'Create Test Accounts')
                )}
              </Button>
            </>
          ) : (
            <>
              <div className="space-y-3">
                <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                  <h3 className="font-semibold text-green-700 dark:text-green-400 mb-3 flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5" />
                    {t('تم إنشاء الحسابات', 'Accounts Created')}
                  </h3>
                  <div className="space-y-2 text-sm">
                    {TEST_ACCOUNTS.map((account) => (
                      <div key={account.email} className="flex justify-between items-center py-1 border-b border-green-500/10 last:border-0">
                        <div className="flex items-center gap-2">
                          {getRoleIcon(account.role)}
                          <span className="capitalize font-medium">{account.role}</span>
                        </div>
                        <div className="text-end">
                          <p className="font-mono text-xs">{account.email}</p>
                          <p className="font-mono text-xs text-muted-foreground">{account.password}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <h4 className="font-semibold text-blue-700 dark:text-blue-400 mb-2">
                    {t('أبناء الحساب التجريبي', 'Test Parent Children')}
                  </h4>
                  <ul className="text-sm space-y-1">
                    <li>• أحمد محمد (2015)</li>
                    <li>• فاطمة محمد (2017)</li>
                  </ul>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => navigate('/staff-login')}
                >
                  {t('دخول الموظفين', 'Staff Login')}
                </Button>
                <Button
                  className="flex-1"
                  onClick={() => navigate('/parent-auth')}
                >
                  {t('دخول أولياء الأمور', 'Parent Login')}
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
