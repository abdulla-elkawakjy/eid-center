-- Add is_leader column to staff_assignments table
ALTER TABLE public.staff_assignments 
ADD COLUMN is_leader boolean NOT NULL DEFAULT false;

-- Add comment for documentation
COMMENT ON COLUMN public.staff_assignments.is_leader IS 'Designates the supervisor as the Program Leader who can manage other supervisors';