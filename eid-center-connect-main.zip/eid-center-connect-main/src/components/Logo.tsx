import eidLogoLtr from '@/assets/eid-logo-ltr.png';
import eidLogoRtl from '@/assets/eid-logo-rtl.png';
import eidLogoPortrait from '@/assets/eid-logo-portrait.png';
import { useLanguage } from '@/contexts/LanguageContext';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'landscape' | 'portrait';
  className?: string;
}

export function Logo({ size = 'md', variant = 'landscape', className = '' }: LogoProps) {
  const { dir } = useLanguage();
  
  const sizeClasses = {
    sm: variant === 'portrait' ? 'h-16' : 'h-10',
    md: variant === 'portrait' ? 'h-24' : 'h-16',
    lg: variant === 'portrait' ? 'h-32' : 'h-24',
  };

  // Use portrait logo or landscape based on variant
  // For landscape, use RTL logo for Arabic, LTR logo for English
  const logoSrc = variant === 'portrait' 
    ? eidLogoPortrait 
    : dir === 'rtl' ? eidLogoRtl : eidLogoLtr;

  return (
    <img 
      src={logoSrc} 
      alt="Eid Cultural Center - مركز عيد الثقافي" 
      className={`${sizeClasses[size]} w-auto object-contain ${className}`}
    />
  );
}
