-- Add RLS policy to allow staff/supervisors to view registration requests for programs they are assigned to
CREATE POLICY "Staff can view registration requests for assigned programs"
  ON public.registration_requests
  FOR SELECT
  USING (
    has_role(auth.uid(), 'staff'::app_role) 
    AND EXISTS (
      SELECT 1 FROM staff_assignments sa
      WHERE sa.program_id = registration_requests.program_id
      AND sa.staff_id = auth.uid()
    )
  );