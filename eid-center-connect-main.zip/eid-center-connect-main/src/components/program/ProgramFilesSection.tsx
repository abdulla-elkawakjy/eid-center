import { useState, useRef, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  Download, 
  Trash2, 
  Eye,
  X,
  File
} from 'lucide-react';
import type { Database } from '@/integrations/supabase/types';

type FileVisibility = Database['public']['Enums']['file_visibility'];

interface ProgramFile {
  id: string;
  program_id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  visibility: FileVisibility;
  uploaded_by: string;
  created_at: string;
  uploader?: {
    full_name: string;
  };
}

interface ProgramFilesSectionProps {
  programId: string;
  isStaff?: boolean;
  isReadOnly?: boolean;
}

export function ProgramFilesSection({ programId, isStaff = false, isReadOnly = false }: ProgramFilesSectionProps) {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<ProgramFile | null>(null);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [visibility, setVisibility] = useState<FileVisibility>('staff_only');
  const [isUploading, setIsUploading] = useState(false);
  const [signedUrls, setSignedUrls] = useState<Record<string, string>>({});
  const [selectedFileUrl, setSelectedFileUrl] = useState<string | null>(null);

  // Fetch program files
  const { data: files, isLoading } = useQuery({
    queryKey: ['program-files', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('program_files')
        .select('*')
        .eq('program_id', programId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      
      // Fetch uploader names
      const uploaderIds = [...new Set(data.map(f => f.uploaded_by))];
      if (uploaderIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('user_id, full_name')
          .in('user_id', uploaderIds);
        
        const profilesMap = new Map(profiles?.map(p => [p.user_id, p]) || []);
        
        return data.map(f => ({
          ...f,
          uploader: profilesMap.get(f.uploaded_by)
        })) as ProgramFile[];
      }
      
      return data as ProgramFile[];
    },
    enabled: !!programId
  });

  const ACCEPTED_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp', 'application/pdf'];
  const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error(language === 'ar' 
        ? 'نوع الملف غير مدعوم. الأنواع المدعومة: PDF, PNG, JPG, GIF, WEBP' 
        : 'Unsupported file type. Supported: PDF, PNG, JPG, GIF, WEBP');
      return;
    }
    
    if (file.size > MAX_FILE_SIZE) {
      toast.error(language === 'ar' 
        ? 'حجم الملف يجب أن يكون أقل من 10 ميجابايت' 
        : 'File size must be less than 10MB');
      return;
    }
    
    setUploadFile(file);
  };

  const uploadFileMutation = useMutation({
    mutationFn: async () => {
      if (!uploadFile || !user) throw new Error('No file or user');
      
      setIsUploading(true);
      
      // Generate unique file path
      const fileExt = uploadFile.name.split('.').pop();
      const fileName = `${crypto.randomUUID()}.${fileExt}`;
      const filePath = `${programId}/${fileName}`;
      
      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('program-files')
        .upload(filePath, uploadFile, {
          cacheControl: '3600',
          upsert: false
        });
      
      if (uploadError) throw uploadError;
      
      // Insert file record
      const { error: insertError } = await supabase
        .from('program_files')
        .insert({
          program_id: programId,
          file_name: uploadFile.name,
          file_path: filePath,
          file_type: uploadFile.type,
          file_size: uploadFile.size,
          visibility: visibility,
          uploaded_by: user.id
        });
      
      if (insertError) {
        // Cleanup uploaded file if insert fails
        await supabase.storage.from('program-files').remove([filePath]);
        throw insertError;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['program-files', programId] });
      toast.success(language === 'ar' ? 'تم رفع الملف بنجاح' : 'File uploaded successfully');
      setIsUploadDialogOpen(false);
      setUploadFile(null);
      setVisibility('staff_only');
      if (fileInputRef.current) fileInputRef.current.value = '';
    },
    onError: (error) => {
      console.error('Upload error:', error);
      toast.error(language === 'ar' ? 'حدث خطأ أثناء رفع الملف' : 'Error uploading file');
    },
    onSettled: () => {
      setIsUploading(false);
    }
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (file: ProgramFile) => {
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('program-files')
        .remove([file.file_path]);
      
      if (storageError) throw storageError;
      
      // Delete record
      const { error: deleteError } = await supabase
        .from('program_files')
        .delete()
        .eq('id', file.id);
      
      if (deleteError) throw deleteError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['program-files', programId] });
      toast.success(language === 'ar' ? 'تم حذف الملف' : 'File deleted');
    },
    onError: (error) => {
      console.error('Delete error:', error);
      toast.error(language === 'ar' ? 'حدث خطأ أثناء حذف الملف' : 'Error deleting file');
    }
  });

  const updateVisibilityMutation = useMutation({
    mutationFn: async ({ fileId, newVisibility }: { fileId: string; newVisibility: FileVisibility }) => {
      const { error } = await supabase
        .from('program_files')
        .update({ visibility: newVisibility })
        .eq('id', fileId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['program-files', programId] });
      toast.success(language === 'ar' ? 'تم تحديث إعدادات المشاهدة' : 'Visibility updated');
    }
  });

  // Generate signed URLs for all files
  const generateSignedUrls = useCallback(async (files: ProgramFile[]) => {
    const urls: Record<string, string> = {};
    for (const file of files) {
      const { data, error } = await supabase.storage
        .from('program-files')
        .createSignedUrl(file.file_path, 3600); // 1 hour expiry
      if (!error && data) {
        urls[file.file_path] = data.signedUrl;
      }
    }
    setSignedUrls(urls);
  }, []);

  // Refresh signed URLs when files change
  useEffect(() => {
    if (files && files.length > 0) {
      generateSignedUrls(files);
    }
  }, [files, generateSignedUrls]);

  const getFileUrl = (filePath: string) => {
    return signedUrls[filePath] || '';
  };

  const handleDownload = async (file: ProgramFile) => {
    // Get a fresh signed URL for download
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 60); // 1 minute expiry for download
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في تحميل الملف' : 'Error downloading file');
      return;
    }
    
    const link = document.createElement('a');
    link.href = data.signedUrl;
    link.download = file.file_name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleView = async (file: ProgramFile) => {
    // Get a fresh signed URL for viewing
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 3600); // 1 hour expiry
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في عرض الملف' : 'Error viewing file');
      return;
    }
    
    setSelectedFileUrl(data.signedUrl);
    setSelectedFile(file);
    setIsViewerOpen(true);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const isImageFile = (fileType: string) => fileType.startsWith('image/');
  const isPdfFile = (fileType: string) => fileType === 'application/pdf';

  const getFileIcon = (fileType: string) => {
    if (isImageFile(fileType)) return <ImageIcon className="h-8 w-8 text-blue-500" />;
    if (isPdfFile(fileType)) return <FileText className="h-8 w-8 text-red-500" />;
    return <File className="h-8 w-8 text-muted-foreground" />;
  };

  const getVisibilityLabel = (vis: FileVisibility) => {
    if (vis === 'staff_only') return language === 'ar' ? 'الموظفين فقط' : 'Staff only';
    return language === 'ar' ? 'الموظفين وأولياء الأمور' : 'Staff & parents';
  };

  return (
    <div className="space-y-4">
      {/* Upload Button - Only for staff */}
      {!isReadOnly && (
        <div className="flex justify-end">
          <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Upload className="h-4 w-4 me-2" />
                {language === 'ar' ? 'رفع ملف' : 'Upload File'}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{language === 'ar' ? 'رفع ملف جديد' : 'Upload New File'}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'اختر الملف' : 'Select File'}</Label>
                  <Input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg,.gif,.webp"
                    onChange={handleFileChange}
                  />
                  {uploadFile && (
                    <p className="text-sm text-muted-foreground">
                      {uploadFile.name} ({formatFileSize(uploadFile.size)})
                    </p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'من يمكنه المشاهدة' : 'Who can view'}</Label>
                  <Select value={visibility} onValueChange={(v) => setVisibility(v as FileVisibility)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="staff_only">
                        {language === 'ar' ? 'الموظفين فقط' : 'Staff only'}
                      </SelectItem>
                      <SelectItem value="staff_and_parents">
                        {language === 'ar' ? 'الموظفين وأولياء الأمور' : 'Staff and parents'}
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setIsUploadDialogOpen(false);
                    setUploadFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                >
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </Button>
                <Button 
                  onClick={() => uploadFileMutation.mutate()}
                  disabled={!uploadFile || isUploading}
                >
                  {isUploading 
                    ? (language === 'ar' ? 'جاري الرفع...' : 'Uploading...') 
                    : (language === 'ar' ? 'رفع' : 'Upload')}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      )}

      {/* Files Grid */}
      {isLoading ? (
        <div className="text-center py-8 text-muted-foreground">
          {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
        </div>
      ) : files?.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-12 text-center text-muted-foreground">
            <File className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>{language === 'ar' ? 'لا توجد ملفات' : 'No files yet'}</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {files?.map((file) => (
            <Card key={file.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3 min-w-0">
                    {isImageFile(file.file_type) ? (
                      <div className="w-12 h-12 rounded overflow-hidden flex-shrink-0 bg-muted">
                        <img 
                          src={getFileUrl(file.file_path)} 
                          alt={file.file_name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="flex-shrink-0">
                        {getFileIcon(file.file_type)}
                      </div>
                    )}
                    <div className="min-w-0">
                      <CardTitle className="text-sm font-medium truncate" title={file.file_name}>
                        {file.file_name}
                      </CardTitle>
                      <p className="text-xs text-muted-foreground">
                        {formatFileSize(file.file_size)}
                      </p>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                <div className="flex items-center justify-between">
                  {isStaff && !isReadOnly ? (
                    <Select 
                      value={file.visibility} 
                      onValueChange={(v) => updateVisibilityMutation.mutate({ 
                        fileId: file.id, 
                        newVisibility: v as FileVisibility 
                      })}
                    >
                      <SelectTrigger className="h-7 text-xs w-auto">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="staff_only">
                          {language === 'ar' ? 'الموظفين فقط' : 'Staff only'}
                        </SelectItem>
                        <SelectItem value="staff_and_parents">
                          {language === 'ar' ? 'الموظفين وأولياء الأمور' : 'Staff & parents'}
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Badge variant="secondary" className="text-xs">
                      {getVisibilityLabel(file.visibility)}
                    </Badge>
                  )}
                  
                  {file.uploader && (
                    <span className="text-xs text-muted-foreground truncate max-w-[100px]" title={file.uploader.full_name}>
                      {file.uploader.full_name}
                    </span>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => handleView(file)}
                  >
                    <Eye className="h-4 w-4 me-1" />
                    {language === 'ar' ? 'عرض' : 'View'}
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => handleDownload(file)}
                  >
                    <Download className="h-4 w-4 me-1" />
                    {language === 'ar' ? 'تنزيل' : 'Download'}
                  </Button>
                  {!isReadOnly && (
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="text-destructive hover:text-destructive"
                      onClick={() => deleteFileMutation.mutate(file)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* File Viewer Modal */}
      <Dialog open={isViewerOpen} onOpenChange={setIsViewerOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span className="truncate pe-4">{selectedFile?.file_name}</span>
              <Button 
                size="sm" 
                variant="ghost" 
                onClick={() => setIsViewerOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </DialogTitle>
          </DialogHeader>
          <div className="flex items-center justify-center min-h-[400px]">
            {selectedFile && selectedFileUrl && isImageFile(selectedFile.file_type) && (
              <img 
                src={selectedFileUrl} 
                alt={selectedFile.file_name}
                className="max-w-full max-h-[70vh] object-contain rounded"
              />
            )}
            {selectedFile && selectedFileUrl && isPdfFile(selectedFile.file_type) && (
              <iframe
                src={selectedFileUrl}
                className="w-full h-[70vh] rounded border"
                title={selectedFile.file_name}
              />
            )}
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button onClick={() => selectedFile && handleDownload(selectedFile)}>
              <Download className="h-4 w-4 me-2" />
              {language === 'ar' ? 'تنزيل' : 'Download'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
