import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';

type StoreRequestStatus = 'pending' | 'processing' | 'approved' | 'delivered' | 'returned' | 'closed';
type RequestItemStatus = 'pending' | 'approved' | 'partially_approved' | 'unavailable' | 'delivered' | 'returned' | 'missing' | 'damaged';

interface RequestStatusBadgeProps {
  status: StoreRequestStatus | RequestItemStatus;
  type?: 'request' | 'item';
}

export function RequestStatusBadge({ status, type = 'request' }: RequestStatusBadgeProps) {
  const { t } = useLanguage();

  const statusConfig: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
    pending: { label: t('قيد الانتظار', 'Pending'), variant: 'secondary' },
    processing: { label: t('قيد المراجعة', 'Processing'), variant: 'outline' },
    approved: { label: t('تمت الموافقة', 'Approved'), variant: 'default' },
    partially_approved: { label: t('موافقة جزئية', 'Partially Approved'), variant: 'outline' },
    unavailable: { label: t('غير متوفر', 'Unavailable'), variant: 'destructive' },
    delivered: { label: t('تم التسليم', 'Delivered'), variant: 'default' },
    returned: { label: t('تم الإرجاع', 'Returned'), variant: 'default' },
    closed: { label: t('مغلق', 'Closed'), variant: 'secondary' },
    missing: { label: t('مفقود', 'Missing'), variant: 'destructive' },
    damaged: { label: t('تالف', 'Damaged'), variant: 'destructive' },
  };

  const config = statusConfig[status] || { label: status, variant: 'secondary' as const };

  return (
    <Badge variant={config.variant}>
      {config.label}
    </Badge>
  );
}
