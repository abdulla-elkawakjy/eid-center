import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Logo } from '@/components/Logo';
import { LanguageToggle } from '@/components/LanguageToggle';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Users, GraduationCap, BookOpen, Shield } from 'lucide-react';

const Index = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const features = [
    {
      icon: GraduationCap,
      title: t('برامج تعليمية متميزة', 'Outstanding Educational Programs'),
      description: t('نقدم برامج تعليمية شاملة تناسب جميع الأعمار', 'We offer comprehensive educational programs for all ages'),
    },
    {
      icon: Users,
      title: t('كادر تعليمي متخصص', 'Specialized Teaching Staff'),
      description: t('فريق من المعلمين والمشرفين ذوي الخبرة', 'A team of experienced teachers and supervisors'),
    },
    {
      icon: BookOpen,
      title: t('متابعة مستمرة', 'Continuous Follow-up'),
      description: t('تقارير دورية عن تقدم الطلاب وأدائهم', 'Regular reports on student progress and performance'),
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="hero-gradient relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute top-20 right-10 w-32 h-32 rounded-full bg-primary-foreground/10 blur-3xl animate-float" />
          <div
            className="absolute bottom-20 left-20 w-48 h-48 rounded-full bg-primary-foreground/10 blur-3xl animate-float"
            style={{ animationDelay: '2s' }}
          />
        </div>

        <div className="container relative z-10 py-6">
          {/* Top Navigation */}
          <nav className="flex items-center justify-between mb-16">
            <Logo size="md" />
            <div className="flex items-center gap-2">
              <LanguageToggle />
              <ThemeToggle />
            </div>
          </nav>

          {/* Hero Content */}
          <div className="text-center py-16 max-w-4xl mx-auto animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight text-primary-foreground">
              {t('مرحباً بكم في مركز عيد الثقافي', 'Welcome to Eid Cultural Center')}
            </h1>
            <p className="text-xl text-primary-foreground/80 mb-10 max-w-2xl mx-auto">
              {t(
                'نسعى لتقديم تجربة تعليمية متميزة تجمع بين الأصالة والمعاصرة',
                'We strive to provide an outstanding educational experience that combines authenticity and modernity'
              )}
            </p>

            {/* Login Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center flex-wrap">
              <Button
                size="lg"
                className="w-full sm:w-auto px-8 py-6 text-lg bg-secondary text-secondary-foreground hover:bg-secondary/90 transition-all duration-300 hover:scale-105"
                onClick={() => navigate('/staff-login')}
              >
                <Shield className="h-5 w-5 me-2" />
                {t('دخول المشرفين', 'Supervisor Login')}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto px-8 py-6 text-lg border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 transition-all duration-300 hover:scale-105"
                onClick={() => navigate('/parent-auth')}
              >
                <Users className="h-5 w-5 me-2" />
                {t('دخول أولياء الأمور', 'Parent Login')}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto px-8 py-6 text-lg border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 transition-all duration-300 hover:scale-105"
                onClick={() => navigate('/student-login')}
              >
                <GraduationCap className="h-5 w-5 me-2" />
                {t('دخول الطلاب', 'Student Login')}
              </Button>
            </div>
          </div>
        </div>

        {/* Wave divider */}
        <div className="absolute bottom-0 left-0 w-full">
          <svg viewBox="0 0 1440 120" fill="none" className="w-full h-auto">
            <path
              d="M0 120L48 105C96 90 192 60 288 50C384 40 480 50 576 55C672 60 768 60 864 65C960 70 1056 80 1152 80C1248 80 1344 70 1392 65L1440 60V120H1392C1344 120 1248 120 1152 120C1056 120 960 120 864 120C768 120 672 120 576 120C480 120 384 120 288 120C192 120 96 120 48 120H0Z"
              fill="hsl(var(--background))"
            />
          </svg>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 container">
        <div className="text-center mb-12 animate-slide-up">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            {t('لماذا مركز عيد الثقافي؟', 'Why Eid Cultural Center?')}
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            {t(
              'نقدم بيئة تعليمية متكاملة تهدف إلى تنمية مهارات الطلاب وبناء شخصياتهم',
              'We provide a comprehensive educational environment aimed at developing students skills and building their characters'
            )}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="card-hover border-none shadow-md bg-card animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <feature.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <Logo size="sm" />
            <p className="text-primary-foreground/70 text-sm">
              {t('© 2025 مركز عيد الثقافي. جميع الحقوق محفوظة', '© 2025 Eid Cultural Center. All rights reserved')}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
