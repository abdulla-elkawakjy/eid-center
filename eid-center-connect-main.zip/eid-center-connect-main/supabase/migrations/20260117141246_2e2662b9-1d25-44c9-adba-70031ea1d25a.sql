-- Create announcements table for parent notifications
CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  title_en text,
  content text NOT NULL,
  content_en text,
  program_id uuid REFERENCES public.programs(id) ON DELETE CASCADE,
  is_global boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  created_by uuid,
  expires_at timestamp with time zone
);

-- Enable RLS
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

-- Admins and staff can manage announcements
CREATE POLICY "Admins and staff can manage announcements"
  ON public.announcements FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'staff'));

-- Parents can view relevant announcements (global or for enrolled programs)
CREATE POLICY "Parents can view relevant announcements"
  ON public.announcements FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'parent') AND (
      is_global = true OR
      EXISTS (
        SELECT 1 FROM public.registration_requests rr
        JOIN public.students s ON s.id = rr.student_id
        WHERE rr.program_id = announcements.program_id
        AND s.parent_id = auth.uid()
        AND rr.status = 'approved'
      )
    )
  );

-- Add RLS policy for parents to view staff profiles for enrolled programs
CREATE POLICY "Parents can view staff profiles for enrolled programs"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'parent') AND
    EXISTS (
      SELECT 1 FROM public.staff_assignments sa
      JOIN public.registration_requests rr ON rr.program_id = sa.program_id
      JOIN public.students s ON s.id = rr.student_id
      WHERE sa.staff_id = profiles.user_id
      AND s.parent_id = auth.uid()
      AND rr.status = 'approved'
    )
  );