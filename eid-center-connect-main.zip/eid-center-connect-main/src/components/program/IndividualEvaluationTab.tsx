import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Save, Loader2, User } from 'lucide-react';
import type { UserPermissions } from '@/hooks/useUserPermissions';

interface IndividualEvaluationTabProps {
  sessionId: string | null;
  programId: string;
  permissions: UserPermissions;
}

interface AssessmentCriterion {
  id: string;
  name: string;
  name_en: string | null;
  max_score: number;
  weight: number;
  criterion_type: string;
}

interface RegisteredStudent {
  id: string;
  student: {
    id: string;
    full_name: string;
  };
}

interface StudentScore {
  id: string;
  student_id: string;
  criterion_id: string;
  score: number;
  notes: string | null;
  session_id: string | null;
}

type ScoreData = Record<string, Record<string, { score: number; notes: string; existingId?: string }>>;

export function IndividualEvaluationTab({ sessionId, programId, permissions }: IndividualEvaluationTabProps) {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [scoreData, setScoreData] = useState<ScoreData>({});
  const [isSaving, setIsSaving] = useState(false);

  const canEdit = permissions.isAdmin || permissions.canEnterIndividualEvaluation;

  // Fetch individual-scope criteria for this program
  const { data: criteria, isLoading: criteriaLoading } = useQuery({
    queryKey: ['individual-criteria', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('assessment_criteria')
        .select('id, name, name_en, max_score, weight, criterion_type')
        .eq('program_id', programId)
        .eq('criterion_scope', 'individual')
        .order('name');
      if (error) throw error;
      return data as AssessmentCriterion[];
    },
    enabled: !!programId
  });

  // Fetch registered students for this program
  const { data: registeredStudents, isLoading: studentsLoading } = useQuery({
    queryKey: ['registered-students-eval', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('registration_requests')
        .select('id, student:students(id, full_name)')
        .eq('program_id', programId)
        .eq('status', 'approved');
      if (error) throw error;
      return data as unknown as RegisteredStudent[];
    },
    enabled: !!programId
  });

  // Fetch existing scores for this session
  const { data: existingScores, isLoading: scoresLoading } = useQuery({
    queryKey: ['session-individual-scores', sessionId, programId],
    queryFn: async () => {
      if (!sessionId) return [];
      
      const studentIds = registeredStudents?.map(r => r.student?.id).filter(Boolean) || [];
      const criteriaIds = criteria?.map(c => c.id) || [];
      
      if (studentIds.length === 0 || criteriaIds.length === 0) return [];

      const { data, error } = await supabase
        .from('student_scores')
        .select('id, student_id, criterion_id, score, notes, session_id')
        .eq('session_id', sessionId)
        .in('student_id', studentIds as string[])
        .in('criterion_id', criteriaIds);
      if (error) throw error;
      return data as StudentScore[];
    },
    enabled: !!sessionId && !!registeredStudents?.length && !!criteria?.length
  });

  // Initialize score data when existing scores are loaded
  useEffect(() => {
    if (!registeredStudents || !criteria) return;

    const initialData: ScoreData = {};
    
    registeredStudents.forEach(reg => {
      if (!reg.student?.id) return;
      initialData[reg.student.id] = {};
      
      criteria.forEach(criterion => {
        const existingScore = existingScores?.find(
          s => s.student_id === reg.student.id && s.criterion_id === criterion.id
        );
        
        initialData[reg.student.id][criterion.id] = {
          score: existingScore?.score ?? 0,
          notes: existingScore?.notes ?? '',
          existingId: existingScore?.id
        };
      });
    });
    
    setScoreData(initialData);
  }, [registeredStudents, criteria, existingScores]);

  const handleScoreChange = (studentId: string, criterionId: string, value: number, maxScore: number) => {
    const clampedValue = Math.min(Math.max(0, value), maxScore);
    setScoreData(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [criterionId]: {
          ...prev[studentId]?.[criterionId],
          score: clampedValue
        }
      }
    }));
  };

  const handleNotesChange = (studentId: string, criterionId: string, notes: string) => {
    setScoreData(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [criterionId]: {
          ...prev[studentId]?.[criterionId],
          notes
        }
      }
    }));
  };

  const handleSave = async () => {
    if (!sessionId || !user?.id) {
      toast.error(language === 'ar' ? 'يرجى تحديد اللقاء' : 'Please select a session');
      return;
    }

    setIsSaving(true);
    
    try {
      const upserts: Array<{
        id?: string;
        student_id: string;
        criterion_id: string;
        session_id: string;
        score: number;
        notes: string | null;
        scored_by: string;
      }> = [];

      Object.entries(scoreData).forEach(([studentId, criteria]) => {
        Object.entries(criteria).forEach(([criterionId, data]) => {
          upserts.push({
            ...(data.existingId ? { id: data.existingId } : {}),
            student_id: studentId,
            criterion_id: criterionId,
            session_id: sessionId,
            score: data.score,
            notes: data.notes || null,
            scored_by: user.id
          });
        });
      });

      if (upserts.length > 0) {
        const { error } = await supabase
          .from('student_scores')
          .upsert(upserts, { onConflict: 'id' });
        
        if (error) throw error;
      }

      toast.success(language === 'ar' ? 'تم حفظ التقييمات بنجاح' : 'Scores saved successfully');
      queryClient.invalidateQueries({ queryKey: ['session-individual-scores', sessionId, programId] });
      queryClient.invalidateQueries({ queryKey: ['all-student-scores', programId] });
    } catch (error) {
      console.error('Error saving scores:', error);
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الحفظ' : 'Error saving scores');
    } finally {
      setIsSaving(false);
    }
  };

  if (!sessionId) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-8 text-center text-muted-foreground">
          {language === 'ar' ? 'يرجى تحديد لقاء أولاً' : 'Please select a session first'}
        </CardContent>
      </Card>
    );
  }

  const isLoading = criteriaLoading || studentsLoading || scoresLoading;

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  if (!criteria || criteria.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-8 text-center text-muted-foreground">
          {language === 'ar' ? 'لا توجد معايير تقييم فردية لهذا البرنامج' : 'No individual evaluation criteria for this program'}
        </CardContent>
      </Card>
    );
  }

  if (!registeredStudents || registeredStudents.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-8 text-center text-muted-foreground">
          {language === 'ar' ? 'لا يوجد طلاب مسجلين في هذا البرنامج' : 'No students registered in this program'}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-4">
        <div>
          <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
            <User className="h-5 w-5" />
            {language === 'ar' ? 'التقييم الفردي' : 'Individual Evaluation'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? `تقييم ${registeredStudents.length} طالب على ${criteria.length} معيار`
              : `Evaluating ${registeredStudents.length} students on ${criteria.length} criteria`}
          </CardDescription>
        </div>
        {canEdit && (
          <Button onClick={handleSave} disabled={isSaving} className="gap-2 rtl:flex-row-reverse">
            {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {language === 'ar' ? 'حفظ التقييمات' : 'Save Scores'}
          </Button>
        )}
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="sticky start-0 bg-background z-10 min-w-[150px]">
                  {language === 'ar' ? 'الطالب' : 'Student'}
                </TableHead>
                {criteria.map(criterion => (
                  <TableHead key={criterion.id} className="text-center min-w-[120px]">
                    <div className="flex flex-col items-center gap-1">
                      <span>{language === 'ar' ? criterion.name : (criterion.name_en || criterion.name)}</span>
                      <span className="text-xs text-muted-foreground">
                        ({language === 'ar' ? 'الحد الأقصى' : 'max'}: {criterion.max_score})
                      </span>
                    </div>
                  </TableHead>
                ))}
                <TableHead className="min-w-[100px] text-center">
                  {language === 'ar' ? 'المجموع' : 'Total'}
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {registeredStudents.map(reg => {
                if (!reg.student?.id) return null;
                
                const studentId = reg.student.id;
                const studentScores = scoreData[studentId] || {};
                
                // Calculate total score
                const total = Object.entries(studentScores).reduce((sum, [criterionId, data]) => {
                  const criterion = criteria.find(c => c.id === criterionId);
                  return sum + (data.score * (criterion?.weight || 1));
                }, 0);
                
                // Calculate max possible score
                const maxTotal = criteria.reduce((sum, c) => sum + (c.max_score * c.weight), 0);

                return (
                  <TableRow key={studentId}>
                    <TableCell className="sticky start-0 bg-background z-10 font-medium">
                      {reg.student.full_name}
                    </TableCell>
                    {criteria.map(criterion => {
                      const scoreInfo = studentScores[criterion.id] || { score: 0, notes: '' };
                      
                      return (
                        <TableCell key={criterion.id} className="text-center">
                          <div className="flex flex-col items-center gap-1">
                            <Input
                              type="number"
                              min={0}
                              max={criterion.max_score}
                              value={scoreInfo.score}
                              onChange={(e) => handleScoreChange(
                                studentId, 
                                criterion.id, 
                                parseFloat(e.target.value) || 0,
                                criterion.max_score
                              )}
                              className="w-20 text-center"
                              disabled={!canEdit}
                            />
                          </div>
                        </TableCell>
                      );
                    })}
                    <TableCell className="text-center font-semibold">
                      {total.toFixed(1)} / {maxTotal}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
