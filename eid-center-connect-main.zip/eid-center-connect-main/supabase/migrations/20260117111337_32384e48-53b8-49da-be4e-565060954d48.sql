-- Add new columns to profiles table for staff and parents
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS qid_number text,
ADD COLUMN IF NOT EXISTS nationality text,
ADD COLUMN IF NOT EXISTS mother_phone text;

-- Add new columns to students table
ALTER TABLE public.students
ADD COLUMN IF NOT EXISTS qid_number text,
ADD COLUMN IF NOT EXISTS school_grade integer,
ADD COLUMN IF NOT EXISTS mobile_number text,
ADD COLUMN IF NOT EXISTS nationality text,
ADD COLUMN IF NOT EXISTS has_health_conditions boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS health_conditions_details text;

-- Add check constraint for school_grade (1-12)
ALTER TABLE public.students
ADD CONSTRAINT students_school_grade_check CHECK (school_grade >= 1 AND school_grade <= 12);