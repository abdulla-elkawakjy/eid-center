import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface SupervisorPermissionsProps {
  assignmentId: string;
  permissions?: {
    can_edit_session_info: boolean;
    can_manage_criteria: boolean;
    can_submit_store_request: boolean;
    can_submit_session_report: boolean;
    can_enter_individual_evaluation: boolean;
    can_enter_group_evaluation: boolean;
    can_coordinate_catering: boolean;
  };
  onUpdate?: () => void;
}

const permissionLabels = {
  can_edit_session_info: { ar: 'تعديل معلومات اللقاء الأساسية', en: 'Edit basic session information' },
  can_manage_criteria: { ar: 'إضافة أو تعديل أو حذف معايير التقييم', en: 'Add, edit or delete evaluation criteria' },
  can_submit_store_request: { ar: 'تقديم طلب إلى أمين المخزن', en: 'Submit a request to the store keeper' },
  can_submit_session_report: { ar: 'تقديم تقرير اللقاء', en: 'Submit the session report' },
  can_enter_individual_evaluation: { ar: 'إدخال/تعديل التقييمات الفردية', en: 'Enter/Edit individual evaluations' },
  can_enter_group_evaluation: { ar: 'إدخال/تعديل التقييمات الجماعية', en: 'Enter/Edit group evaluations' },
  can_coordinate_catering: { ar: 'تنسيق الضيافة', en: 'Coordinate catering' },
};

export function SupervisorPermissions({ assignmentId, permissions, onUpdate }: SupervisorPermissionsProps) {
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  
  const [localPermissions, setLocalPermissions] = useState({
    can_edit_session_info: permissions?.can_edit_session_info ?? false,
    can_manage_criteria: permissions?.can_manage_criteria ?? false,
    can_submit_store_request: permissions?.can_submit_store_request ?? false,
    can_submit_session_report: permissions?.can_submit_session_report ?? false,
    can_enter_individual_evaluation: permissions?.can_enter_individual_evaluation ?? false,
    can_enter_group_evaluation: permissions?.can_enter_group_evaluation ?? false,
    can_coordinate_catering: permissions?.can_coordinate_catering ?? false,
  });

  useEffect(() => {
    if (permissions) {
      setLocalPermissions({
        can_edit_session_info: permissions.can_edit_session_info,
        can_manage_criteria: permissions.can_manage_criteria,
        can_submit_store_request: permissions.can_submit_store_request,
        can_submit_session_report: permissions.can_submit_session_report,
        can_enter_individual_evaluation: permissions.can_enter_individual_evaluation,
        can_enter_group_evaluation: permissions.can_enter_group_evaluation,
        can_coordinate_catering: permissions.can_coordinate_catering,
      });
    }
  }, [permissions]);

  const updatePermissionsMutation = useMutation({
    mutationFn: async (newPermissions: typeof localPermissions) => {
      // Upsert permissions
      const { error } = await supabase
        .from('supervisor_permissions')
        .upsert({
          assignment_id: assignmentId,
          ...newPermissions,
        }, {
          onConflict: 'assignment_id'
        });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-assignments'] });
      queryClient.invalidateQueries({ queryKey: ['supervisor-permissions'] });
      toast.success(language === 'ar' ? 'تم تحديث الصلاحيات' : 'Permissions updated');
      onUpdate?.();
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'Error updating permissions');
    }
  });

  const handleToggle = (key: keyof typeof localPermissions) => {
    const newPermissions = {
      ...localPermissions,
      [key]: !localPermissions[key],
    };
    setLocalPermissions(newPermissions);
    updatePermissionsMutation.mutate(newPermissions);
  };

  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-muted-foreground">
        {language === 'ar' ? 'الصلاحيات:' : 'Permissions:'}
      </p>
      <div className="grid gap-3">
        {Object.entries(permissionLabels).map(([key, label]) => (
          <div key={key} className="flex items-center justify-between gap-4 rtl:flex-row-reverse">
            <Label htmlFor={`${assignmentId}-${key}`} className="text-sm flex-1 text-start cursor-pointer">
              {language === 'ar' ? label.ar : label.en}
            </Label>
            <Switch
              id={`${assignmentId}-${key}`}
              checked={localPermissions[key as keyof typeof localPermissions]}
              onCheckedChange={() => handleToggle(key as keyof typeof localPermissions)}
              disabled={updatePermissionsMutation.isPending}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
