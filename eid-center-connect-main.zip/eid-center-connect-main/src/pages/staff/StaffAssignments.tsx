import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ClipboardList, Users, Calendar, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Assignment {
  id: string;
  program: {
    id: string;
    name: string;
    name_en: string | null;
    description: string | null;
    description_en: string | null;
    semester: {
      name: string;
      name_en: string | null;
    };
  };
  role: {
    id: string;
    name: string;
    name_en: string | null;
  } | null;
}

export default function StaffAssignments() {
  const { language } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: assignments, isLoading } = useQuery({
    queryKey: ['staff-assignments', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('staff_assignments')
        .select(`
          id,
          program:programs(
            id,
            name,
            name_en,
            description,
            description_en,
            semester:semesters(name, name_en)
          ),
          role:program_roles(id, name, name_en)
        `)
        .eq('staff_id', user.id);
      if (error) throw error;
      return data as unknown as Assignment[];
    },
    enabled: !!user
  });

  const getRoleBadgeColor = (roleName: string | null | undefined) => {
    if (!roleName) return 'secondary';
    if (roleName.includes('قائد') || roleName.toLowerCase().includes('leader')) return 'default';
    if (roleName.includes('مشرف') || roleName.toLowerCase().includes('supervisor')) return 'outline';
    return 'secondary';
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <ClipboardList className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-foreground">
            {language === 'ar' ? 'مهامي' : 'My Assignments'}
          </h1>
        </div>

        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : assignments?.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Users className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {language === 'ar' ? 'لا توجد مهام مسندة إليك' : 'No assignments yet'}
              </h3>
              <p className="text-muted-foreground text-center">
                {language === 'ar'
                  ? 'سيتم إسناد البرامج إليك من قبل المشرف'
                  : 'Programs will be assigned to you by the admin'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {assignments?.map((assignment) => (
              <Card key={assignment.id} className="hover:border-primary transition-colors">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>
                        {language === 'ar'
                          ? assignment.program?.name
                          : assignment.program?.name_en || assignment.program?.name}
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {language === 'ar'
                          ? assignment.program?.semester?.name
                          : assignment.program?.semester?.name_en || assignment.program?.semester?.name}
                      </CardDescription>
                    </div>
                    {assignment.role && (
                      <Badge variant={getRoleBadgeColor(assignment.role.name)}>
                        {language === 'ar'
                          ? assignment.role.name
                          : assignment.role.name_en || assignment.role.name}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {language === 'ar'
                      ? assignment.program?.description
                      : assignment.program?.description_en || assignment.program?.description}
                  </p>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => navigate(`/dashboard/program/${assignment.program?.id}`)}
                  >
                    <span>{language === 'ar' ? 'عرض التفاصيل' : 'View Details'}</span>
                    <ChevronRight className="h-4 w-4 ms-2 rtl:rotate-180" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
