import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Upload, Trash2, Download, FileText } from 'lucide-react';
import { UserPermissions } from '@/hooks/useUserPermissions';
import type { Database } from '@/integrations/supabase/types';

type FileVisibility = Database['public']['Enums']['file_visibility'];

interface SessionFilesTabProps {
  sessionId: string;
  permissions: UserPermissions;
}

interface SessionFile {
  id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  visibility: FileVisibility;
  created_at: string;
}

export function SessionFilesTab({ sessionId, permissions }: SessionFilesTabProps) {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [uploadForm, setUploadForm] = useState({
    file: null as File | null,
    visibility: 'staff_only' as FileVisibility,
  });

  const canEdit = permissions.isAdmin || permissions.isAssigned;

  // Fetch session files
  const { data: files, isLoading } = useQuery({
    queryKey: ['session-files', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('session_files')
        .select('*')
        .eq('session_id', sessionId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as SessionFile[];
    },
    enabled: !!sessionId,
  });

  // Upload file mutation
  const uploadFileMutation = useMutation({
    mutationFn: async () => {
      if (!uploadForm.file || !user?.id) throw new Error('No file selected');

      const fileExt = uploadForm.file.name.split('.').pop();
      const fileName = `${sessionId}/${Date.now()}.${fileExt}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('program-files')
        .upload(fileName, uploadForm.file);
      if (uploadError) throw uploadError;

      // Create database record
      const { error: dbError } = await supabase.from('session_files').insert({
        session_id: sessionId,
        file_name: uploadForm.file.name,
        file_path: fileName,
        file_type: uploadForm.file.type,
        file_size: uploadForm.file.size,
        visibility: uploadForm.visibility,
        uploaded_by: user.id,
      });
      if (dbError) throw dbError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['session-files', sessionId] });
      toast.success(language === 'ar' ? 'تم رفع الملف' : 'File uploaded');
      setIsUploadDialogOpen(false);
      setUploadForm({ file: null, visibility: 'staff_only' });
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'Error uploading file');
    },
  });

  // Delete file mutation
  const deleteFileMutation = useMutation({
    mutationFn: async (file: SessionFile) => {
      // Delete from storage
      await supabase.storage.from('program-files').remove([file.file_path]);
      // Delete from database
      const { error } = await supabase.from('session_files').delete().eq('id', file.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['session-files', sessionId] });
      toast.success(language === 'ar' ? 'تم حذف الملف' : 'File deleted');
    },
  });

  const handleDownload = async (file: SessionFile) => {
    const { data } = await supabase.storage.from('program-files').createSignedUrl(file.file_path, 60);
    if (data?.signedUrl) {
      window.open(data.signedUrl, '_blank');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center rtl:flex-row-reverse">
        <h3 className="text-lg font-semibold flex items-center gap-2 rtl:flex-row-reverse">
          <FileText className="h-5 w-5" />
          {language === 'ar' ? 'ملفات اللقاء' : 'Session Files'}
        </h3>
        {canEdit && (
          <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Upload className="h-4 w-4 me-2" />
                {language === 'ar' ? 'رفع ملف' : 'Upload File'}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{language === 'ar' ? 'رفع ملف جديد' : 'Upload New File'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={(e) => { e.preventDefault(); uploadFileMutation.mutate(); }} className="space-y-4">
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'الملف' : 'File'}</Label>
                  <Input
                    type="file"
                    onChange={(e) => setUploadForm({ ...uploadForm, file: e.target.files?.[0] || null })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'مرئي لـ' : 'Visible To'}</Label>
                  <Select
                    value={uploadForm.visibility}
                    onValueChange={(v: FileVisibility) => setUploadForm({ ...uploadForm, visibility: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="staff_only">
                        {language === 'ar' ? 'المشرفون فقط' : 'Staff Only'}
                      </SelectItem>
                      <SelectItem value="staff_and_parents">
                        {language === 'ar' ? 'المشرفون وأولياء الأمور' : 'Staff and Parents'}
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                  <Button type="button" variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </Button>
                  <Button type="submit" disabled={!uploadForm.file || uploadFileMutation.isPending}>
                    {language === 'ar' ? 'رفع' : 'Upload'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Files Table */}
      {isLoading ? (
        <div className="text-center py-8 text-muted-foreground">
          {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
        </div>
      ) : files?.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center text-muted-foreground">
            {language === 'ar' ? 'لا توجد ملفات' : 'No files yet'}
          </CardContent>
        </Card>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{language === 'ar' ? 'اسم الملف' : 'File Name'}</TableHead>
              <TableHead>{language === 'ar' ? 'الحجم' : 'Size'}</TableHead>
              <TableHead>{language === 'ar' ? 'الرؤية' : 'Visibility'}</TableHead>
              <TableHead className="w-[100px]">{language === 'ar' ? 'إجراءات' : 'Actions'}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {files?.map((file) => (
              <TableRow key={file.id}>
                <TableCell className="font-medium">{file.file_name}</TableCell>
                <TableCell>{formatFileSize(file.file_size)}</TableCell>
                <TableCell>
                  <Badge variant={file.visibility === 'staff_only' ? 'secondary' : 'default'}>
                    {file.visibility === 'staff_only'
                      ? (language === 'ar' ? 'المشرفون فقط' : 'Staff Only')
                      : (language === 'ar' ? 'الجميع' : 'Everyone')}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex gap-1 rtl:flex-row-reverse">
                    <Button size="sm" variant="ghost" onClick={() => handleDownload(file)}>
                      <Download className="h-4 w-4" />
                    </Button>
                    {canEdit && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive"
                        onClick={() => deleteFileMutation.mutate(file)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
