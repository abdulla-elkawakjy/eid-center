-- Create custom types/enums
CREATE TYPE public.app_role AS ENUM ('admin', 'staff', 'parent');
CREATE TYPE public.registration_status AS ENUM ('pending', 'approved', 'denied');
CREATE TYPE public.criterion_type AS ENUM ('daily', 'overall');
CREATE TYPE public.criterion_scope AS ENUM ('individual', 'group');

-- Profiles table for user information
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  preferred_language TEXT DEFAULT 'ar',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- User roles table (separate from profiles for security)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE (user_id, role)
);

-- Students table (children of parents)
CREATE TABLE public.students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  full_name TEXT NOT NULL,
  date_of_birth DATE,
  gender TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Semesters table
CREATE TABLE public.semesters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  name_en TEXT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Programs table
CREATE TABLE public.programs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  semester_id UUID REFERENCES public.semesters(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  name_en TEXT,
  description TEXT,
  description_en TEXT,
  age_range TEXT,
  capacity INTEGER,
  registration_open BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Sessions table (program sessions/classes)
CREATE TABLE public.sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID REFERENCES public.programs(id) ON DELETE CASCADE NOT NULL,
  session_date DATE,
  location TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Program roles table (custom roles for programs)
CREATE TABLE public.program_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  name_en TEXT,
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Insert default program roles
INSERT INTO public.program_roles (name, name_en, is_default) VALUES
  ('قائد البرنامج', 'Program Leader', true),
  ('مساعد القائد', 'Leader Assistant', true),
  ('مشرف مجموعة', 'Group Supervisor', true);

-- Staff assignments table
CREATE TABLE public.staff_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID REFERENCES public.programs(id) ON DELETE CASCADE NOT NULL,
  staff_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role_id UUID REFERENCES public.program_roles(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE (program_id, staff_id, role_id)
);

-- Student groups table
CREATE TABLE public.student_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID REFERENCES public.programs(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  supervisor_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Registration requests table
CREATE TABLE public.registration_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID REFERENCES public.programs(id) ON DELETE CASCADE NOT NULL,
  student_id UUID REFERENCES public.students(id) ON DELETE CASCADE NOT NULL,
  parent_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  status registration_status DEFAULT 'pending' NOT NULL,
  notes TEXT,
  reviewed_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE (program_id, student_id)
);

-- Student group assignments
CREATE TABLE public.student_group_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id UUID REFERENCES public.student_groups(id) ON DELETE CASCADE NOT NULL,
  student_id UUID REFERENCES public.students(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE (group_id, student_id)
);

-- Assessment criteria table
CREATE TABLE public.assessment_criteria (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  program_id UUID REFERENCES public.programs(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  name_en TEXT,
  criterion_type criterion_type NOT NULL,
  criterion_scope criterion_scope NOT NULL,
  max_score NUMERIC DEFAULT 10 NOT NULL,
  weight NUMERIC DEFAULT 1 NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Individual student scores
CREATE TABLE public.student_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  criterion_id UUID REFERENCES public.assessment_criteria(id) ON DELETE CASCADE NOT NULL,
  student_id UUID REFERENCES public.students(id) ON DELETE CASCADE NOT NULL,
  session_id UUID REFERENCES public.sessions(id) ON DELETE SET NULL,
  score NUMERIC NOT NULL,
  notes TEXT,
  scored_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Group scores
CREATE TABLE public.group_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  criterion_id UUID REFERENCES public.assessment_criteria(id) ON DELETE CASCADE NOT NULL,
  group_id UUID REFERENCES public.student_groups(id) ON DELETE CASCADE NOT NULL,
  session_id UUID REFERENCES public.sessions(id) ON DELETE SET NULL,
  score NUMERIC NOT NULL,
  notes TEXT,
  scored_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.semesters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.program_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.registration_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_group_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessment_criteria ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_scores ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles (prevents RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Function to get user role
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id UUID)
RETURNS app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role
  FROM public.user_roles
  WHERE user_id = _user_id
  LIMIT 1
$$;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage all profiles" ON public.profiles FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for user_roles
CREATE POLICY "Users can view own role" ON public.user_roles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage roles" ON public.user_roles FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for students
CREATE POLICY "Parents can view own children" ON public.students FOR SELECT USING (auth.uid() = parent_id);
CREATE POLICY "Parents can manage own children" ON public.students FOR ALL USING (auth.uid() = parent_id);
CREATE POLICY "Admins can manage all students" ON public.students FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Staff can view students" ON public.students FOR SELECT USING (public.has_role(auth.uid(), 'staff'));

-- RLS Policies for semesters (public read, admin write)
CREATE POLICY "Anyone can view semesters" ON public.semesters FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage semesters" ON public.semesters FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for programs
CREATE POLICY "Anyone can view programs" ON public.programs FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage programs" ON public.programs FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for sessions
CREATE POLICY "Anyone can view sessions" ON public.sessions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage sessions" ON public.sessions FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Staff can manage sessions" ON public.sessions FOR ALL USING (public.has_role(auth.uid(), 'staff'));

-- RLS Policies for program_roles
CREATE POLICY "Anyone can view program roles" ON public.program_roles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage program roles" ON public.program_roles FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for staff_assignments
CREATE POLICY "Staff can view own assignments" ON public.staff_assignments FOR SELECT USING (auth.uid() = staff_id);
CREATE POLICY "Admins can manage assignments" ON public.staff_assignments FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Staff can view all assignments" ON public.staff_assignments FOR SELECT USING (public.has_role(auth.uid(), 'staff'));

-- RLS Policies for student_groups
CREATE POLICY "Anyone can view groups" ON public.student_groups FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage groups" ON public.student_groups FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Staff can manage groups" ON public.student_groups FOR ALL USING (public.has_role(auth.uid(), 'staff'));

-- RLS Policies for registration_requests
CREATE POLICY "Parents can view own requests" ON public.registration_requests FOR SELECT USING (auth.uid() = parent_id);
CREATE POLICY "Parents can create requests" ON public.registration_requests FOR INSERT WITH CHECK (auth.uid() = parent_id);
CREATE POLICY "Admins can manage all requests" ON public.registration_requests FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for student_group_assignments
CREATE POLICY "Anyone can view group assignments" ON public.student_group_assignments FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage group assignments" ON public.student_group_assignments FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Staff can manage group assignments" ON public.student_group_assignments FOR ALL USING (public.has_role(auth.uid(), 'staff'));

-- RLS Policies for assessment_criteria
CREATE POLICY "Anyone can view criteria" ON public.assessment_criteria FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage criteria" ON public.assessment_criteria FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Staff can manage criteria" ON public.assessment_criteria FOR ALL USING (public.has_role(auth.uid(), 'staff'));

-- RLS Policies for student_scores
CREATE POLICY "Staff can manage student scores" ON public.student_scores FOR ALL USING (public.has_role(auth.uid(), 'staff'));
CREATE POLICY "Admins can manage student scores" ON public.student_scores FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Parents can view children scores" ON public.student_scores FOR SELECT USING (
  EXISTS (SELECT 1 FROM public.students WHERE students.id = student_scores.student_id AND students.parent_id = auth.uid())
);

-- RLS Policies for group_scores
CREATE POLICY "Staff can manage group scores" ON public.group_scores FOR ALL USING (public.has_role(auth.uid(), 'staff'));
CREATE POLICY "Admins can manage group scores" ON public.group_scores FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Anyone can view group scores" ON public.group_scores FOR SELECT TO authenticated USING (true);

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_students_updated_at BEFORE UPDATE ON public.students FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_semesters_updated_at BEFORE UPDATE ON public.semesters FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_programs_updated_at BEFORE UPDATE ON public.programs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_sessions_updated_at BEFORE UPDATE ON public.sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_student_groups_updated_at BEFORE UPDATE ON public.student_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_registration_requests_updated_at BEFORE UPDATE ON public.registration_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_assessment_criteria_updated_at BEFORE UPDATE ON public.assessment_criteria FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_student_scores_updated_at BEFORE UPDATE ON public.student_scores FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_group_scores_updated_at BEFORE UPDATE ON public.group_scores FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Function to create profile after signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', 'مستخدم جديد'), NEW.email);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger to create profile on signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();