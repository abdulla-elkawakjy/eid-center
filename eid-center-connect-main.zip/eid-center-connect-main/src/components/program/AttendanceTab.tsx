import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Save, Users } from 'lucide-react';
import { UserPermissions } from '@/hooks/useUserPermissions';

interface AttendanceTabProps {
  sessionId: string;
  programId: string;
  permissions: UserPermissions;
}

interface RegisteredStudent {
  id: string;
  student: {
    id: string;
    full_name: string;
  };
}

interface AttendanceRecord {
  id?: string;
  student_id: string;
  is_present: boolean;
  notes: string;
}

export function AttendanceTab({ sessionId, programId, permissions }: AttendanceTabProps) {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [attendanceData, setAttendanceData] = useState<Record<string, AttendanceRecord>>({});
  const [hasChanges, setHasChanges] = useState(false);

  const canEdit = permissions.isAdmin || permissions.canEnterIndividualEvaluation;

  // Fetch registered students
  const { data: registeredStudents } = useQuery({
    queryKey: ['registered-students', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('registration_requests')
        .select(`
          id,
          student:students(id, full_name)
        `)
        .eq('program_id', programId)
        .eq('status', 'approved');
      if (error) throw error;
      return data as unknown as RegisteredStudent[];
    },
    enabled: !!programId,
  });

  // Fetch existing attendance records
  const { data: existingAttendance } = useQuery({
    queryKey: ['student-attendance', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('student_attendance')
        .select('*')
        .eq('session_id', sessionId);
      if (error) throw error;
      return data;
    },
    enabled: !!sessionId,
  });

  // Initialize attendance data from existing records
  useEffect(() => {
    if (existingAttendance && registeredStudents) {
      const initialData: Record<string, AttendanceRecord> = {};
      registeredStudents.forEach((reg) => {
        const existing = existingAttendance.find((a) => a.student_id === reg.student?.id);
        if (reg.student?.id) {
          initialData[reg.student.id] = {
            id: existing?.id,
            student_id: reg.student.id,
            is_present: existing?.is_present ?? false,
            notes: existing?.notes ?? '',
          };
        }
      });
      setAttendanceData(initialData);
      setHasChanges(false);
    }
  }, [existingAttendance, registeredStudents]);

  // Save attendance mutation
  const saveAttendanceMutation = useMutation({
    mutationFn: async () => {
      const records = Object.values(attendanceData);
      for (const record of records) {
        if (record.id) {
          // Update existing
          const { error } = await supabase
            .from('student_attendance')
            .update({
              is_present: record.is_present,
              notes: record.notes || null,
              marked_by: user?.id,
            })
            .eq('id', record.id);
          if (error) throw error;
        } else {
          // Insert new
          const { error } = await supabase.from('student_attendance').insert({
            session_id: sessionId,
            student_id: record.student_id,
            is_present: record.is_present,
            notes: record.notes || null,
            marked_by: user?.id,
          });
          if (error) throw error;
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['student-attendance', sessionId] });
      toast.success(language === 'ar' ? 'تم حفظ الحضور' : 'Attendance saved');
      setHasChanges(false);
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'Error saving attendance');
    },
  });

  const handleTogglePresence = (studentId: string) => {
    setAttendanceData((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        is_present: !prev[studentId]?.is_present,
      },
    }));
    setHasChanges(true);
  };

  const handleNotesChange = (studentId: string, notes: string) => {
    setAttendanceData((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        notes,
      },
    }));
    setHasChanges(true);
  };

  const presentCount = Object.values(attendanceData).filter((a) => a.is_present).length;
  const totalCount = registeredStudents?.length ?? 0;

  return (
    <div className="space-y-4">
      {/* Summary Card */}
      <Card>
        <CardContent className="py-4">
          <div className="flex items-center justify-between rtl:flex-row-reverse">
            <div className="flex items-center gap-2 rtl:flex-row-reverse">
              <Users className="h-5 w-5 text-muted-foreground" />
              <span className="text-lg font-medium">
                {language === 'ar' 
                  ? `الحضور: ${presentCount} من ${totalCount}` 
                  : `Attendance: ${presentCount} of ${totalCount}`}
              </span>
            </div>
            {canEdit && (
              <Button 
                onClick={() => saveAttendanceMutation.mutate()} 
                disabled={!hasChanges || saveAttendanceMutation.isPending}
              >
                <Save className="h-4 w-4 me-2" />
                {language === 'ar' ? 'حفظ' : 'Save'}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Attendance Table */}
      {registeredStudents?.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center text-muted-foreground">
            {language === 'ar' ? 'لا يوجد طلاب مسجلين' : 'No registered students'}
          </CardContent>
        </Card>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]">{language === 'ar' ? 'حاضر' : 'Present'}</TableHead>
              <TableHead>{language === 'ar' ? 'اسم الطالب' : 'Student Name'}</TableHead>
              <TableHead>{language === 'ar' ? 'ملاحظات' : 'Notes'}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {registeredStudents?.map((reg) => {
              const studentId = reg.student?.id;
              if (!studentId) return null;
              const record = attendanceData[studentId];
              
              return (
                <TableRow key={studentId}>
                  <TableCell>
                    <Checkbox
                      checked={record?.is_present ?? false}
                      onCheckedChange={() => handleTogglePresence(studentId)}
                      disabled={!canEdit}
                    />
                  </TableCell>
                  <TableCell className="font-medium">{reg.student?.full_name}</TableCell>
                  <TableCell>
                    <Input
                      value={record?.notes ?? ''}
                      onChange={(e) => handleNotesChange(studentId, e.target.value)}
                      placeholder={language === 'ar' ? 'ملاحظات...' : 'Notes...'}
                      disabled={!canEdit}
                      className="max-w-[200px]"
                    />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
