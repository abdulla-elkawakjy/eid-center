import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { TrendingUp, User, BookOpen, Star, FileText, Download, Eye, Image as ImageIcon, File as FileIcon, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';

interface StudentWithScores {
  id: string;
  full_name: string;
  registrations: {
    status: string;
    program: {
      id: string;
      name: string;
      name_en: string | null;
    };
  }[];
}

interface Score {
  score: number;
  notes: string | null;
  criterion: {
    name: string;
    name_en: string | null;
    max_score: number;
    criterion_type: string;
    weight: number;
  };
}

interface ProgramFile {
  id: string;
  program_id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  visibility: string;
  created_at: string;
  program?: {
    name: string;
    name_en: string | null;
  };
}

export default function ChildProgress() {
  const { language } = useLanguage();
  const { user } = useAuth();
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<ProgramFile | null>(null);
  const [signedUrls, setSignedUrls] = useState<Record<string, string>>({});
  const [selectedFileUrl, setSelectedFileUrl] = useState<string | null>(null);

  const { data: children, isLoading } = useQuery({
    queryKey: ['children-with-registrations', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('students')
        .select(`
          id,
          full_name,
          registrations:registration_requests(
            status,
            program:programs(id, name, name_en)
          )
        `)
        .eq('parent_id', user.id);
      if (error) throw error;
      return data as unknown as StudentWithScores[];
    },
    enabled: !!user
  });

  const { data: scores } = useQuery({
    queryKey: ['student-scores', children?.map(c => c.id)],
    queryFn: async () => {
      if (!children || children.length === 0) return {};
      const studentIds = children.map(c => c.id);
      const { data, error } = await supabase
        .from('student_scores')
        .select(`
          student_id,
          score,
          notes,
          criterion:assessment_criteria(name, name_en, max_score, criterion_type, weight)
        `)
        .in('student_id', studentIds);
      if (error) throw error;
      
      // Group scores by student
      const scoresByStudent: Record<string, Score[]> = {};
      data?.forEach((score: any) => {
        if (!scoresByStudent[score.student_id]) {
          scoresByStudent[score.student_id] = [];
        }
        scoresByStudent[score.student_id].push(score);
      });
      return scoresByStudent;
    },
    enabled: !!children && children.length > 0
  });

  // Fetch program files visible to parents
  const { data: programFiles } = useQuery({
    queryKey: ['parent-program-files', children?.map(c => c.id)],
    queryFn: async () => {
      if (!children || children.length === 0) return [];
      
      // Get all program IDs from approved registrations
      const programIds = children.flatMap(child => 
        child.registrations
          ?.filter(r => r.status === 'approved')
          .map(r => r.program?.id)
          .filter(Boolean)
      ) as string[];
      
      if (programIds.length === 0) return [];
      
      const uniqueProgramIds = [...new Set(programIds)];
      
      const { data, error } = await supabase
        .from('program_files')
        .select('*, program:programs(name, name_en)')
        .in('program_id', uniqueProgramIds)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as unknown as ProgramFile[];
    },
    enabled: !!children && children.length > 0
  });

  const calculateOverallProgress = (studentScores: Score[] | undefined) => {
    if (!studentScores || studentScores.length === 0) return 0;
    const totalWeight = studentScores.reduce((acc, s) => acc + s.criterion.weight, 0);
    const weightedScore = studentScores.reduce((acc, s) => {
      const percentage = (s.score / s.criterion.max_score) * 100;
      return acc + (percentage * s.criterion.weight);
    }, 0);
    return Math.round(weightedScore / totalWeight);
  };

  // Generate signed URLs for all files
  const generateSignedUrls = useCallback(async (files: ProgramFile[]) => {
    const urls: Record<string, string> = {};
    for (const file of files) {
      const { data, error } = await supabase.storage
        .from('program-files')
        .createSignedUrl(file.file_path, 3600); // 1 hour expiry
      if (!error && data) {
        urls[file.file_path] = data.signedUrl;
      }
    }
    setSignedUrls(urls);
  }, []);

  // Refresh signed URLs when files change
  useEffect(() => {
    if (programFiles && programFiles.length > 0) {
      generateSignedUrls(programFiles);
    }
  }, [programFiles, generateSignedUrls]);

  const getFileUrl = (filePath: string) => {
    return signedUrls[filePath] || '';
  };

  const handleDownload = async (file: ProgramFile) => {
    // Get a fresh signed URL for download
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 60); // 1 minute expiry for download
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في تحميل الملف' : 'Error downloading file');
      return;
    }
    
    const link = document.createElement('a');
    link.href = data.signedUrl;
    link.download = file.file_name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleViewFile = async (file: ProgramFile) => {
    // Get a fresh signed URL for viewing
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 3600); // 1 hour expiry
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في عرض الملف' : 'Error viewing file');
      return;
    }
    
    setSelectedFileUrl(data.signedUrl);
    setSelectedFile(file);
    setIsViewerOpen(true);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const isImageFile = (fileType: string) => fileType.startsWith('image/');
  const isPdfFile = (fileType: string) => fileType === 'application/pdf';

  const getFileIcon = (fileType: string) => {
    if (isImageFile(fileType)) return <ImageIcon className="h-6 w-6 text-blue-500" />;
    if (isPdfFile(fileType)) return <FileText className="h-6 w-6 text-red-500" />;
    return <FileIcon className="h-6 w-6 text-muted-foreground" />;
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <TrendingUp className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-foreground">
            {language === 'ar' ? 'تقارير الأداء' : 'Performance Reports'}
          </h1>
        </div>

        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : children?.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <User className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {language === 'ar' ? 'لا يوجد أبناء مسجلين' : 'No children registered'}
              </h3>
              <p className="text-muted-foreground text-center">
                {language === 'ar'
                  ? 'قم بتسجيل أبنائك في البرامج لمتابعة أدائهم'
                  : 'Register your children in programs to track their progress'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue={children?.[0]?.id} className="w-full">
            <TabsList className="flex-wrap h-auto gap-2 p-2">
              {children?.map((child) => (
                <TabsTrigger key={child.id} value={child.id} className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  {child.full_name}
                </TabsTrigger>
              ))}
            </TabsList>

            {children?.map((child) => {
              const childScores = scores?.[child.id];
              const overallProgress = calculateOverallProgress(childScores);
              const approvedRegistrations = child.registrations?.filter(r => r.status === 'approved') || [];

              return (
                <TabsContent key={child.id} value={child.id} className="space-y-6">
                  {/* Overall Progress Card */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Star className="h-5 w-5 text-yellow-500" />
                        {language === 'ar' ? 'الأداء العام' : 'Overall Performance'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-primary">{overallProgress}%</span>
                          <Badge variant={overallProgress >= 70 ? 'default' : overallProgress >= 50 ? 'secondary' : 'destructive'}>
                            {overallProgress >= 70
                              ? (language === 'ar' ? 'ممتاز' : 'Excellent')
                              : overallProgress >= 50
                              ? (language === 'ar' ? 'جيد' : 'Good')
                              : (language === 'ar' ? 'يحتاج تحسين' : 'Needs Improvement')}
                          </Badge>
                        </div>
                        <Progress value={overallProgress} className="h-3" />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Programs Enrolled */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <BookOpen className="h-5 w-5 text-primary" />
                        {language === 'ar' ? 'البرامج المسجلة' : 'Enrolled Programs'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {approvedRegistrations.length === 0 ? (
                        <p className="text-muted-foreground text-center py-4">
                          {language === 'ar'
                            ? 'لا يوجد برامج مسجلة حالياً'
                            : 'No programs enrolled currently'}
                        </p>
                      ) : (
                        <div className="space-y-4">
                          {approvedRegistrations.map((reg, index) => (
                            <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                              <div>
                                <h4 className="font-medium">
                                  {language === 'ar'
                                    ? reg.program?.name
                                    : reg.program?.name_en || reg.program?.name}
                                </h4>
                              </div>
                              <Badge className="bg-green-500">
                                {language === 'ar' ? 'مسجل' : 'Enrolled'}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Detailed Scores */}
                  {childScores && childScores.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle>{language === 'ar' ? 'التقييمات التفصيلية' : 'Detailed Assessments'}</CardTitle>
                        <CardDescription>
                          {language === 'ar'
                            ? 'درجات الطالب في معايير التقييم المختلفة'
                            : "Student's scores in different assessment criteria"}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {childScores.map((score, index) => {
                            const percentage = Math.round((score.score / score.criterion.max_score) * 100);
                            return (
                              <div key={index} className="space-y-2">
                                <div className="flex items-center justify-between">
                                  <span className="font-medium">
                                    {language === 'ar'
                                      ? score.criterion.name
                                      : score.criterion.name_en || score.criterion.name}
                                  </span>
                                  <span className="text-sm text-muted-foreground">
                                    {score.score} / {score.criterion.max_score}
                                  </span>
                                </div>
                                <Progress value={percentage} className="h-2" />
                                {score.notes && (
                                  <p className="text-sm text-muted-foreground">{score.notes}</p>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {(!childScores || childScores.length === 0) && approvedRegistrations.length > 0 && (
                    <Card className="border-dashed">
                      <CardContent className="flex flex-col items-center justify-center py-12">
                        <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                        <h3 className="text-lg font-medium mb-2">
                          {language === 'ar' ? 'لا توجد تقييمات بعد' : 'No assessments yet'}
                        </h3>
                        <p className="text-muted-foreground text-center">
                          {language === 'ar'
                            ? 'سيتم إضافة التقييمات من قبل المشرفين'
                            : 'Assessments will be added by supervisors'}
                        </p>
                      </CardContent>
                    </Card>
                  )}

                  {/* Program Files */}
                  {approvedRegistrations.length > 0 && (() => {
                    const childProgramIds = approvedRegistrations.map(r => r.program?.id).filter(Boolean);
                    const childFiles = programFiles?.filter(f => childProgramIds.includes(f.program_id)) || [];
                    
                    if (childFiles.length === 0) return null;
                    
                    return (
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <FileText className="h-5 w-5 text-primary" />
                            {language === 'ar' ? 'ملفات البرامج' : 'Program Files'}
                          </CardTitle>
                          <CardDescription>
                            {language === 'ar'
                              ? 'الملفات المتاحة من البرامج المسجل فيها'
                              : 'Files shared from enrolled programs'}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {childFiles.map((file) => (
                              <div 
                                key={file.id} 
                                className="flex items-center justify-between p-3 rounded-lg bg-muted/50 gap-3"
                              >
                                <div className="flex items-center gap-3 min-w-0 flex-1">
                                  {isImageFile(file.file_type) ? (
                                    <div className="w-10 h-10 rounded overflow-hidden flex-shrink-0 bg-background">
                                      <img 
                                        src={getFileUrl(file.file_path)} 
                                        alt={file.file_name}
                                        className="w-full h-full object-cover"
                                      />
                                    </div>
                                  ) : (
                                    <div className="flex-shrink-0">
                                      {getFileIcon(file.file_type)}
                                    </div>
                                  )}
                                  <div className="min-w-0 flex-1">
                                    <p className="font-medium text-sm truncate" title={file.file_name}>
                                      {file.file_name}
                                    </p>
                                    <p className="text-xs text-muted-foreground">
                                      {language === 'ar' ? file.program?.name : file.program?.name_en || file.program?.name}
                                      {' · '}
                                      {formatFileSize(file.file_size)}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2 flex-shrink-0">
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => handleViewFile(file)}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => handleDownload(file)}
                                  >
                                    <Download className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })()}
                </TabsContent>
              );
            })}
          </Tabs>
        )}

        {/* File Viewer Modal */}
        <Dialog open={isViewerOpen} onOpenChange={setIsViewerOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                <span className="truncate pe-4">{selectedFile?.file_name}</span>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => setIsViewerOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </DialogTitle>
            </DialogHeader>
            <div className="flex items-center justify-center min-h-[400px]">
              {selectedFile && selectedFileUrl && isImageFile(selectedFile.file_type) && (
                <img 
                  src={selectedFileUrl} 
                  alt={selectedFile.file_name}
                  className="max-w-full max-h-[70vh] object-contain rounded"
                />
              )}
              {selectedFile && selectedFileUrl && isPdfFile(selectedFile.file_type) && (
                <iframe
                  src={selectedFileUrl}
                  className="w-full h-[70vh] rounded border"
                  title={selectedFile.file_name}
                />
              )}
            </div>
            <div className="flex justify-end gap-2 pt-4">
              <Button onClick={() => selectedFile && handleDownload(selectedFile)}>
                <Download className="h-4 w-4 me-2" />
                {language === 'ar' ? 'تنزيل' : 'Download'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
