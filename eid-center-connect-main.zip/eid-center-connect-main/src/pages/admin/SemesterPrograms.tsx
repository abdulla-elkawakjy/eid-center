import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, BookOpen, ChevronLeft, ChevronRight, ArrowLeft, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

interface Semester {
  id: string;
  name: string;
  name_en: string | null;
  start_date: string;
  end_date: string;
}

interface Program {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
  description_en: string | null;
  age_range: string | null;
  capacity: number | null;
  registration_open: boolean | null;
  semester_id: string;
  created_at: string;
}

export default function SemesterPrograms() {
  const { semesterId } = useParams<{ semesterId: string }>();
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [isProgramDialogOpen, setIsProgramDialogOpen] = useState(false);
  const [editingProgram, setEditingProgram] = useState<Program | null>(null);

  const [programForm, setProgramForm] = useState({
    name: '',
    name_en: '',
    description: '',
    description_en: '',
    age_range: '',
    capacity: '',
    registration_open: true
  });

  // Fetch semester details
  const { data: semester } = useQuery({
    queryKey: ['semester', semesterId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('semesters')
        .select('id, name, name_en, start_date, end_date')
        .eq('id', semesterId)
        .single();
      if (error) throw error;
      return data as Semester;
    },
    enabled: !!semesterId
  });

  // Fetch programs for this semester
  const { data: programs, isLoading: loadingPrograms } = useQuery({
    queryKey: ['programs', semesterId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('programs')
        .select('*')
        .eq('semester_id', semesterId)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as Program[];
    },
    enabled: !!semesterId
  });

  const createProgramMutation = useMutation({
    mutationFn: async (data: typeof programForm) => {
      const { error } = await supabase.from('programs').insert({
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
        description_en: data.description_en || null,
        age_range: data.age_range || null,
        capacity: data.capacity ? parseInt(data.capacity) : null,
        registration_open: data.registration_open,
        semester_id: semesterId!
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['programs', semesterId] });
      toast.success(language === 'ar' ? 'تم إضافة البرنامج بنجاح' : 'Program added successfully');
      resetProgramForm();
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الإضافة' : 'Error adding program');
    }
  });

  const updateProgramMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof programForm }) => {
      const { error } = await supabase.from('programs').update({
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
        description_en: data.description_en || null,
        age_range: data.age_range || null,
        capacity: data.capacity ? parseInt(data.capacity) : null,
        registration_open: data.registration_open
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['programs', semesterId] });
      toast.success(language === 'ar' ? 'تم تحديث البرنامج بنجاح' : 'Program updated successfully');
      resetProgramForm();
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء التحديث' : 'Error updating program');
    }
  });

  const deleteProgramMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('programs').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['programs', semesterId] });
      toast.success(language === 'ar' ? 'تم حذف البرنامج بنجاح' : 'Program deleted successfully');
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الحذف' : 'Error deleting program');
    }
  });

  const resetProgramForm = () => {
    setProgramForm({ name: '', name_en: '', description: '', description_en: '', age_range: '', capacity: '', registration_open: true });
    setEditingProgram(null);
    setIsProgramDialogOpen(false);
  };

  const handleEditProgram = (program: Program, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingProgram(program);
    setProgramForm({
      name: program.name,
      name_en: program.name_en || '',
      description: program.description || '',
      description_en: program.description_en || '',
      age_range: program.age_range || '',
      capacity: program.capacity?.toString() || '',
      registration_open: program.registration_open ?? true
    });
    setIsProgramDialogOpen(true);
  };

  const handleProgramSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProgram) {
      updateProgramMutation.mutate({ id: editingProgram.id, data: programForm });
    } else {
      createProgramMutation.mutate(programForm);
    }
  };

  const handleProgramClick = (program: Program) => {
    navigate(`/dashboard/program/${program.id}`);
  };

  const formatDate = (date: string) => {
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  const DirectionChevron = language === 'ar' ? ChevronLeft : ChevronRight;
  const BackArrow = language === 'ar' ? ArrowRight : ArrowLeft;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Back button and header */}
        <div className="flex items-center gap-4 flex-wrap">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard/programs')}
            className="gap-2"
          >
            <BackArrow className="h-4 w-4" />
            {language === 'ar' ? 'الفصول الدراسية' : 'Semesters'}
          </Button>
        </div>

        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <BookOpen className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                {language === 'ar' ? semester?.name : semester?.name_en || semester?.name}
              </h1>
              {semester && (
                <p className="text-muted-foreground">
                  {formatDate(semester.start_date)} - {formatDate(semester.end_date)}
                </p>
              )}
            </div>
          </div>
          <Dialog open={isProgramDialogOpen} onOpenChange={setIsProgramDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetProgramForm()}>
                <Plus className="h-4 w-4 me-2" />
                {language === 'ar' ? 'إضافة برنامج' : 'Add Program'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingProgram
                    ? (language === 'ar' ? 'تعديل البرنامج' : 'Edit Program')
                    : (language === 'ar' ? 'إضافة برنامج جديد' : 'Add New Program')}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleProgramSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                    <Input
                      value={programForm.name}
                      onChange={(e) => setProgramForm({ ...programForm, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                    <Input
                      value={programForm.name_en}
                      onChange={(e) => setProgramForm({ ...programForm, name_en: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الوصف (عربي)' : 'Description (Arabic)'}</Label>
                    <Textarea
                      value={programForm.description}
                      onChange={(e) => setProgramForm({ ...programForm, description: e.target.value })}
                      rows={3}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الوصف (إنجليزي)' : 'Description (English)'}</Label>
                    <Textarea
                      value={programForm.description_en}
                      onChange={(e) => setProgramForm({ ...programForm, description_en: e.target.value })}
                      rows={3}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الفئة العمرية' : 'Age Range'}</Label>
                    <Input
                      value={programForm.age_range}
                      onChange={(e) => setProgramForm({ ...programForm, age_range: e.target.value })}
                      placeholder={language === 'ar' ? 'مثال: 8-12 سنة' : 'e.g., 8-12 years'}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'السعة' : 'Capacity'}</Label>
                    <Input
                      type="number"
                      value={programForm.capacity}
                      onChange={(e) => setProgramForm({ ...programForm, capacity: e.target.value })}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={programForm.registration_open}
                    onCheckedChange={(checked) => setProgramForm({ ...programForm, registration_open: checked })}
                  />
                  <Label>{language === 'ar' ? 'التسجيل مفتوح' : 'Registration Open'}</Label>
                </div>
                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={resetProgramForm}>
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </Button>
                  <Button type="submit">
                    {editingProgram
                      ? (language === 'ar' ? 'حفظ التغييرات' : 'Save Changes')
                      : (language === 'ar' ? 'إضافة' : 'Add')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {loadingPrograms ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : programs?.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'لا يوجد برامج في هذا الفصل' : 'No programs in this semester'}
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {programs?.map((program) => (
              <Card 
                key={program.id}
                className="cursor-pointer transition-all hover:border-primary hover:shadow-md"
                onClick={() => handleProgramClick(program)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="truncate">
                        {language === 'ar' ? program.name : program.name_en || program.name}
                      </CardTitle>
                      <CardDescription className="line-clamp-2">
                        {language === 'ar' ? program.description : program.description_en || program.description}
                      </CardDescription>
                    </div>
                    <Badge variant={program.registration_open ? "default" : "secondary"} className="shrink-0">
                      {program.registration_open
                        ? (language === 'ar' ? 'التسجيل مفتوح' : 'Open')
                        : (language === 'ar' ? 'التسجيل مغلق' : 'Closed')}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex gap-4">
                      {program.age_range && (
                        <span>{language === 'ar' ? 'العمر:' : 'Age:'} {program.age_range}</span>
                      )}
                      {program.capacity && (
                        <span>{language === 'ar' ? 'السعة:' : 'Capacity:'} {program.capacity}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={(e) => handleEditProgram(program, e)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteProgramMutation.mutate(program.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <DirectionChevron className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
