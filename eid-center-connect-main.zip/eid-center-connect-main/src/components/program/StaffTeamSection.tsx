import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { Plus, Trash2, UserPlus, Phone, Mail, Crown } from 'lucide-react';
import { SupervisorPermissions } from './SupervisorPermissions';

interface StaffMember {
  user_id: string;
  full_name: string;
  email: string;
  phone: string | null;
}

interface SupervisorPermission {
  id: string;
  can_edit_session_info: boolean;
  can_manage_criteria: boolean;
  can_submit_store_request: boolean;
  can_submit_session_report: boolean;
  can_enter_individual_evaluation: boolean;
  can_enter_group_evaluation: boolean;
  can_coordinate_catering: boolean;
}

interface StaffAssignment {
  id: string;
  staff_id: string;
  role_name: string | null;
  role_name_en: string | null;
  is_leader: boolean;
  staff?: {
    full_name: string;
    email: string;
    phone: string | null;
  };
  permissions?: SupervisorPermission | null;
}

interface StaffTeamSectionProps {
  programId: string;
  canEdit: boolean;
}

export function StaffTeamSection({ programId, canEdit }: StaffTeamSectionProps) {
  const { language } = useLanguage();
  const queryClient = useQueryClient();
  const [isStaffDialogOpen, setIsStaffDialogOpen] = useState(false);

  const [staffAssignForm, setStaffAssignForm] = useState({
    staff_id: '',
    role_name: '',
    role_name_en: ''
  });

  // Fetch staff members
  const { data: staffMembers } = useQuery({
    queryKey: ['staff-members'],
    queryFn: async () => {
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'staff');
      if (rolesError) throw rolesError;

      if (!roles || roles.length === 0) return [];

      const userIds = roles.map(r => r.user_id);
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('user_id, full_name, email, phone')
        .in('user_id', userIds);
      if (profilesError) throw profilesError;

      return profiles as StaffMember[];
    }
  });

  // Fetch staff assignments for this program with permissions
  const { data: staffAssignments, isLoading: loadingAssignments } = useQuery({
    queryKey: ['staff-assignments', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff_assignments')
        .select('id, staff_id, role_name, role_name_en, is_leader')
        .eq('program_id', programId);
      if (error) throw error;

      // Fetch staff profiles
      const staffIds = data.map(a => a.staff_id);

      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name, email, phone')
        .in('user_id', staffIds);

      // Fetch permissions
      const assignmentIds = data.map(a => a.id);
      const { data: permissions } = await supabase
        .from('supervisor_permissions')
        .select('*')
        .in('assignment_id', assignmentIds);

      const profilesMap = new Map<string, { user_id: string; full_name: string; email: string; phone: string | null }>(
        (profiles || []).map(p => [p.user_id, p])
      );
      const permissionsMap = new Map<string, SupervisorPermission>(
        (permissions || []).map(p => [p.assignment_id, p])
      );

      return data.map(a => ({
        ...a,
        is_leader: a.is_leader ?? false,
        staff: profilesMap.get(a.staff_id),
        permissions: permissionsMap.get(a.id) || null
      })) as StaffAssignment[];
    },
    enabled: !!programId
  });

  // Staff assignment mutations
  const assignStaffMutation = useMutation({
    mutationFn: async (data: typeof staffAssignForm) => {
      // Create staff assignment
      const { data: assignment, error } = await supabase.from('staff_assignments').insert({
        program_id: programId,
        staff_id: data.staff_id,
        role_name: data.role_name || null,
        role_name_en: data.role_name_en || null
      }).select('id').single();
      if (error) throw error;

      // Create default permissions record
      const { error: permError } = await supabase.from('supervisor_permissions').insert({
        assignment_id: assignment.id
      });
      if (permError) throw permError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-assignments', programId] });
      toast.success(language === 'ar' ? 'تم إسناد المشرف بنجاح' : 'Supervisor assigned successfully');
      setIsStaffDialogOpen(false);
      setStaffAssignForm({ staff_id: '', role_name: '', role_name_en: '' });
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الإسناد' : 'Error assigning supervisor');
    }
  });

  const removeStaffMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('staff_assignments').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-assignments', programId] });
      toast.success(language === 'ar' ? 'تم إزالة المشرف' : 'Supervisor removed');
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'Error');
    }
  });

  // Update role name mutation
  const updateRoleNameMutation = useMutation({
    mutationFn: async ({ id, role_name, role_name_en }: { id: string; role_name: string; role_name_en: string }) => {
      const { error } = await supabase.from('staff_assignments').update({
        role_name: role_name || null,
        role_name_en: role_name_en || null
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-assignments', programId] });
      toast.success(language === 'ar' ? 'تم تحديث الدور' : 'Role updated');
    }
  });

  // Set leader mutation
  const setLeaderMutation = useMutation({
    mutationFn: async (assignmentId: string) => {
      // First, unset all leaders for this program
      const { error: unsetError } = await supabase
        .from('staff_assignments')
        .update({ is_leader: false })
        .eq('program_id', programId);
      if (unsetError) throw unsetError;

      // Then set the new leader
      const { error } = await supabase
        .from('staff_assignments')
        .update({ is_leader: true })
        .eq('id', assignmentId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-assignments', programId] });
      queryClient.invalidateQueries({ queryKey: ['user-permissions', programId] });
      toast.success(language === 'ar' ? 'تم تعيين قائد البرنامج' : 'Program leader set');
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'Error');
    }
  });

  // Read-only view for regular supervisors
  if (!canEdit) {
    return (
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">
          {language === 'ar' ? 'المشرفون' : 'Supervisors'}
        </h2>

        {loadingAssignments ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : staffAssignments?.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-8 text-center text-muted-foreground">
              {language === 'ar' ? 'لا يوجد مشرفين مسندين لهذا البرنامج' : 'No supervisors assigned to this program'}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{language === 'ar' ? 'الاسم' : 'Name'}</TableHead>
                  <TableHead>{language === 'ar' ? 'الدور' : 'Role'}</TableHead>
                  <TableHead>{language === 'ar' ? 'رقم الجوال' : 'Mobile Number'}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {staffAssignments?.map((assignment) => (
                  <TableRow key={assignment.id}>
                    <TableCell>
                      <div className="flex items-center gap-2 rtl:flex-row-reverse">
                        {assignment.staff?.full_name}
                        {assignment.is_leader && (
                          <Crown className="h-4 w-4 text-yellow-500" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {language === 'ar' 
                        ? assignment.role_name || '-' 
                        : assignment.role_name_en || assignment.role_name || '-'}
                    </TableCell>
                    <TableCell>{assignment.staff?.phone || '-'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        )}
      </div>
    );
  }

  // Edit view for admins and program leaders
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <h2 className="text-xl font-semibold">
          {language === 'ar' ? 'المشرفون' : 'Supervisors'}
        </h2>
        <Dialog open={isStaffDialogOpen} onOpenChange={setIsStaffDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="h-4 w-4 me-2" />
              {language === 'ar' ? 'إضافة مشرف' : 'Add Supervisor'}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{language === 'ar' ? 'إسناد مشرف للبرنامج' : 'Assign Supervisor to Program'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); assignStaffMutation.mutate(staffAssignForm); }} className="space-y-4">
              <div className="space-y-2">
                <Label>{language === 'ar' ? 'المشرف' : 'Supervisor'}</Label>
                <Select
                  value={staffAssignForm.staff_id}
                  onValueChange={(v) => setStaffAssignForm({ ...staffAssignForm, staff_id: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={language === 'ar' ? 'اختر المشرف' : 'Select Supervisor'} />
                  </SelectTrigger>
                  <SelectContent>
                    {staffMembers?.filter(s => !staffAssignments?.some(a => a.staff_id === s.user_id)).map((staff) => (
                      <SelectItem key={staff.user_id} value={staff.user_id}>
                        {staff.full_name} ({staff.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'اسم الدور (عربي)' : 'Role Name (Arabic)'}</Label>
                  <Input
                    value={staffAssignForm.role_name}
                    onChange={(e) => setStaffAssignForm({ ...staffAssignForm, role_name: e.target.value })}
                    placeholder={language === 'ar' ? 'مثال: مشرف، قائد فريق' : 'e.g., Supervisor, Team Leader'}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'اسم الدور (إنجليزي)' : 'Role Name (English)'}</Label>
                  <Input
                    value={staffAssignForm.role_name_en}
                    onChange={(e) => setStaffAssignForm({ ...staffAssignForm, role_name_en: e.target.value })}
                    placeholder="e.g., Supervisor, Team Leader"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                <Button type="button" variant="outline" onClick={() => setIsStaffDialogOpen(false)}>
                  {language === 'ar' ? 'إلغاء' : 'Cancel'}
                </Button>
                <Button type="submit" disabled={!staffAssignForm.staff_id}>
                  {language === 'ar' ? 'إسناد' : 'Assign'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {loadingAssignments ? (
        <div className="text-center py-8 text-muted-foreground">
          {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
        </div>
      ) : staffAssignments?.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center text-muted-foreground">
            {language === 'ar' ? 'لا يوجد مشرفين مسندين لهذا البرنامج' : 'No supervisors assigned to this program'}
          </CardContent>
        </Card>
      ) : (
        <Accordion type="multiple" className="space-y-3">
          {staffAssignments?.map((assignment) => (
            <AccordionItem key={assignment.id} value={assignment.id} className="border rounded-lg">
              <AccordionTrigger className="px-4 hover:no-underline">
                <div className="flex items-center justify-between flex-1 me-4 rtl:flex-row-reverse">
                  <div className="flex items-center gap-3 rtl:flex-row-reverse">
                    <span className="font-medium text-start">{assignment.staff?.full_name}</span>
                    {assignment.is_leader && (
                      <Badge variant="default" className="bg-yellow-500 hover:bg-yellow-600">
                        <Crown className="h-3 w-3 me-1" />
                        {language === 'ar' ? 'قائد' : 'Leader'}
                      </Badge>
                    )}
                    {(assignment.role_name || assignment.role_name_en) && (
                      <Badge variant="secondary">
                        {language === 'ar' ? assignment.role_name : assignment.role_name_en || assignment.role_name}
                      </Badge>
                    )}
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-4">
                <div className="space-y-4">
                  {/* Contact Info */}
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1 rtl:flex-row-reverse">
                      <Mail className="h-4 w-4" />
                      {assignment.staff?.email}
                    </div>
                    {assignment.staff?.phone && (
                      <div className="flex items-center gap-1 rtl:flex-row-reverse">
                        <Phone className="h-4 w-4" />
                        {assignment.staff.phone}
                      </div>
                    )}
                  </div>

                  {/* Role Name Edit */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm">{language === 'ar' ? 'اسم الدور (عربي)' : 'Role Name (Arabic)'}</Label>
                      <Input
                        value={assignment.role_name || ''}
                        onChange={(e) => updateRoleNameMutation.mutate({
                          id: assignment.id,
                          role_name: e.target.value,
                          role_name_en: assignment.role_name_en || ''
                        })}
                        placeholder={language === 'ar' ? 'مثال: مشرف' : 'e.g., Supervisor'}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm">{language === 'ar' ? 'اسم الدور (إنجليزي)' : 'Role Name (English)'}</Label>
                      <Input
                        value={assignment.role_name_en || ''}
                        onChange={(e) => updateRoleNameMutation.mutate({
                          id: assignment.id,
                          role_name: assignment.role_name || '',
                          role_name_en: e.target.value
                        })}
                        placeholder="e.g., Supervisor"
                      />
                    </div>
                  </div>

                  {/* Permissions */}
                  <SupervisorPermissions
                    assignmentId={assignment.id}
                    permissions={assignment.permissions ?? undefined}
                    onUpdate={() => queryClient.invalidateQueries({ queryKey: ['staff-assignments', programId] })}
                  />

                  {/* Action Buttons */}
                  <div className="flex justify-between items-center pt-2 flex-wrap gap-2">
                    {!assignment.is_leader && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setLeaderMutation.mutate(assignment.id)}
                      >
                        <Crown className="h-4 w-4 me-2" />
                        {language === 'ar' ? 'تعيين كقائد' : 'Set as Leader'}
                      </Button>
                    )}
                    {assignment.is_leader && (
                      <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                        <Crown className="h-3 w-3 me-1" />
                        {language === 'ar' ? 'قائد البرنامج' : 'Program Leader'}
                      </Badge>
                    )}
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => removeStaffMutation.mutate(assignment.id)}
                    >
                      <Trash2 className="h-4 w-4 me-2" />
                      {language === 'ar' ? 'إزالة' : 'Remove'}
                    </Button>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      )}
    </div>
  );
}
