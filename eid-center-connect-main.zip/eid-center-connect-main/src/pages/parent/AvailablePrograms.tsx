import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { BookOpen, Users, Calendar, UserPlus, ClipboardList } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';

interface Program {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
  description_en: string | null;
  age_range: string | null;
  capacity: number | null;
  registration_open: boolean | null;
  semester: {
    name: string;
    name_en: string | null;
  };
}

interface Student {
  id: string;
  full_name: string;
}

export default function AvailablePrograms() {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);
  const [selectedChild, setSelectedChild] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: programs, isLoading } = useQuery({
    queryKey: ['available-programs'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('programs')
        .select(`
          id,
          name,
          name_en,
          description,
          description_en,
          age_range,
          capacity,
          registration_open,
          semester:semesters(name, name_en)
        `)
        .eq('registration_open', true)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as unknown as Program[];
    }
  });

  const { data: children } = useQuery({
    queryKey: ['my-children-for-registration', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('students')
        .select('id, full_name')
        .eq('parent_id', user.id);
      if (error) throw error;
      return data as Student[];
    },
    enabled: !!user
  });

  const { data: existingRequests } = useQuery({
    queryKey: ['my-registration-requests', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('registration_requests')
        .select('student_id, program_id, status')
        .eq('parent_id', user.id);
      if (error) throw error;
      return data;
    },
    enabled: !!user
  });

  // Fetch full registration requests with student and program details for display
  const { data: registrationRequestsFull } = useQuery({
    queryKey: ['my-registration-requests-full', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('registration_requests')
        .select(`
          id, status, created_at,
          student:students(full_name),
          program:programs(name, name_en)
        `)
        .eq('parent_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as unknown as {
        id: string;
        status: string;
        created_at: string;
        student: { full_name: string } | null;
        program: { name: string; name_en: string | null } | null;
      }[];
    },
    enabled: !!user
  });

  const registerMutation = useMutation({
    mutationFn: async ({ programId, studentId }: { programId: string; studentId: string }) => {
      if (!user) throw new Error('Not authenticated');
      const { error } = await supabase.from('registration_requests').insert({
        program_id: programId,
        student_id: studentId,
        parent_id: user.id,
        status: 'pending'
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-registration-requests'] });
      toast.success(language === 'ar' ? 'تم تقديم طلب التسجيل بنجاح' : 'Registration request submitted successfully');
      setIsDialogOpen(false);
      setSelectedChild('');
      setSelectedProgram(null);
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء التسجيل' : 'Error submitting registration');
    }
  });

  const handleRegister = (program: Program) => {
    setSelectedProgram(program);
    setIsDialogOpen(true);
  };

  const handleSubmitRegistration = () => {
    if (selectedProgram && selectedChild) {
      registerMutation.mutate({
        programId: selectedProgram.id,
        studentId: selectedChild
      });
    }
  };

  const isAlreadyRegistered = (programId: string, studentId: string) => {
    return existingRequests?.some(
      (req) => req.program_id === programId && req.student_id === studentId
    );
  };

  const getRegistrationStatus = (programId: string, studentId: string) => {
    const request = existingRequests?.find(
      (req) => req.program_id === programId && req.student_id === studentId
    );
    return request?.status;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500 hover:bg-yellow-500/80">{language === 'ar' ? 'قيد الانتظار' : 'Pending'}</Badge>;
      case 'approved':
        return <Badge className="bg-green-500 hover:bg-green-500/80">{language === 'ar' ? 'مقبول' : 'Approved'}</Badge>;
      case 'denied':
        return <Badge variant="destructive">{language === 'ar' ? 'مرفوض' : 'Denied'}</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3 rtl:flex-row-reverse">
          <ClipboardList className="h-7 w-7 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            {language === 'ar' ? 'التسجيل في برنامج' : 'Register for a Program'}
          </h1>
        </div>

        {/* Registration Requests Section */}
        {registrationRequestsFull && registrationRequestsFull.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse text-base sm:text-lg">
                <ClipboardList className="h-5 w-5 text-primary flex-shrink-0" />
                {language === 'ar' ? 'طلبات التسجيل' : 'Registration Requests'}
              </CardTitle>
              <CardDescription className="text-sm">
                {language === 'ar' ? 'حالة طلبات تسجيل أبنائك في البرامج' : 'Status of your children\'s registration requests'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Mobile Card Layout */}
              <div className="space-y-3 sm:hidden">
                {registrationRequestsFull.map((request) => (
                  <div key={request.id} className="p-4 rounded-lg border bg-card">
                    <div className="flex items-start justify-between gap-2 rtl:flex-row-reverse mb-2">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-foreground">
                          {request.student?.full_name || '-'}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {request.program
                            ? (language === 'ar' ? request.program.name : request.program.name_en || request.program.name)
                            : '-'}
                        </p>
                      </div>
                      {getStatusBadge(request.status)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {format(parseISO(request.created_at), 'dd MMM yyyy', {
                        locale: language === 'ar' ? ar : enUS
                      })}
                    </p>
                  </div>
                ))}
              </div>
              {/* Desktop Table Layout */}
              <div className="hidden sm:block">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{language === 'ar' ? 'الابن' : 'Child'}</TableHead>
                      <TableHead>{language === 'ar' ? 'البرنامج' : 'Program'}</TableHead>
                      <TableHead>{language === 'ar' ? 'الحالة' : 'Status'}</TableHead>
                      <TableHead>{language === 'ar' ? 'التاريخ' : 'Date'}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {registrationRequestsFull.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-medium">
                          {request.student?.full_name || '-'}
                        </TableCell>
                        <TableCell>
                          {request.program
                            ? (language === 'ar' ? request.program.name : request.program.name_en || request.program.name)
                            : '-'}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(request.status)}
                        </TableCell>
                        <TableCell>
                          {format(parseISO(request.created_at), 'dd MMM yyyy', {
                            locale: language === 'ar' ? ar : enUS
                          })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Available Programs Section */}
        <div>
          <h2 className="text-lg sm:text-xl font-semibold mb-4">
            {language === 'ar' ? 'البرامج المتاحة للتسجيل' : 'Available Programs'}
          </h2>

        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">
            {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
          </div>
        ) : programs?.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <BookOpen className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {language === 'ar' ? 'لا توجد برامج متاحة حالياً' : 'No programs available'}
              </h3>
              <p className="text-muted-foreground text-center">
                {language === 'ar'
                  ? 'سيتم الإعلان عن البرامج الجديدة قريباً'
                  : 'New programs will be announced soon'}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {programs?.map((program) => (
              <Card key={program.id} className="flex flex-col">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>
                        {language === 'ar' ? program.name : program.name_en || program.name}
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {language === 'ar'
                          ? program.semester?.name
                          : program.semester?.name_en || program.semester?.name}
                      </CardDescription>
                    </div>
                    <Badge className="bg-green-500">
                      {language === 'ar' ? 'التسجيل مفتوح' : 'Open'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <p className="text-muted-foreground text-sm mb-4 flex-1">
                    {language === 'ar'
                      ? program.description
                      : program.description_en || program.description}
                  </p>
                  <div className="space-y-2 text-sm text-muted-foreground mb-4">
                    {program.age_range && (
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        <span>{language === 'ar' ? 'الفئة العمرية:' : 'Age Range:'} {program.age_range}</span>
                      </div>
                    )}
                    {program.capacity && (
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{language === 'ar' ? 'السعة:' : 'Capacity:'} {program.capacity}</span>
                      </div>
                    )}
                  </div>
                  <Button onClick={() => handleRegister(program)} className="w-full min-h-[44px]">
                    <UserPlus className="h-5 w-5 me-2 flex-shrink-0" />
                    {language === 'ar' ? 'تسجيل ابن' : 'Register Child'}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {language === 'ar' ? 'تسجيل في البرنامج' : 'Register for Program'}
              </DialogTitle>
              <DialogDescription>
                {selectedProgram && (
                  <span>
                    {language === 'ar'
                      ? `التسجيل في برنامج: ${selectedProgram.name}`
                      : `Registering for: ${selectedProgram.name_en || selectedProgram.name}`}
                  </span>
                )}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {children?.length === 0 ? (
                <div className="text-center py-4">
                  <p className="text-muted-foreground mb-4">
                    {language === 'ar'
                      ? 'يجب إضافة أبنائك أولاً قبل التسجيل'
                      : 'You need to add your children first before registering'}
                  </p>
                  <Button variant="outline" onClick={() => window.location.href = '/parent/children'}>
                    {language === 'ar' ? 'إضافة أبنائي' : 'Add My Children'}
                  </Button>
                </div>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'اختر الابن' : 'Select Child'}</Label>
                    <Select value={selectedChild} onValueChange={setSelectedChild}>
                      <SelectTrigger>
                        <SelectValue placeholder={language === 'ar' ? 'اختر الابن' : 'Select a child'} />
                      </SelectTrigger>
                      <SelectContent>
                        {children?.map((child) => {
                          const status = selectedProgram
                            ? getRegistrationStatus(selectedProgram.id, child.id)
                            : null;
                          const isRegistered = selectedProgram
                            ? isAlreadyRegistered(selectedProgram.id, child.id)
                            : false;
                          return (
                            <SelectItem
                              key={child.id}
                              value={child.id}
                              disabled={isRegistered}
                            >
                              {child.full_name}
                              {status === 'pending' && (
                                <span className="ms-2 text-yellow-600">
                                  ({language === 'ar' ? 'قيد الانتظار' : 'Pending'})
                                </span>
                              )}
                              {status === 'approved' && (
                                <span className="ms-2 text-green-600">
                                  ({language === 'ar' ? 'مسجل' : 'Registered'})
                                </span>
                              )}
                              {status === 'denied' && (
                                <span className="ms-2 text-destructive">
                                  ({language === 'ar' ? 'مرفوض' : 'Denied'})
                                </span>
                              )}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2 justify-end">
                    <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="min-h-[44px]">
                      {language === 'ar' ? 'إلغاء' : 'Cancel'}
                    </Button>
                    <Button
                      onClick={handleSubmitRegistration}
                      disabled={!selectedChild || registerMutation.isPending}
                      className="min-h-[44px]"
                    >
                      {language === 'ar' ? 'تقديم الطلب' : 'Submit Request'}
                    </Button>
                  </div>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
