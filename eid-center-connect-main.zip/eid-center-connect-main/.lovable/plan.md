
# Parent Interface Enhancements

## Overview
This plan covers three changes to the parent interface:
1. **Rename "Available Programs" to "Register for a Program"** and add a section showing existing registration requests with their status
2. **Update Staff Team table in "My Programs"** to show "Program Supervisors" with name, role (Leader/Supervisor), and mobile
3. **Add session details to "Upcoming Sessions"** on the dashboard including session number, assembly time, and dismissal time

---

## Part 1: Rename and Enhance "Available Programs" Page

### Current State
- Page title: "البرامج المتاحة" / "Available Programs"
- Shows only available programs with open registration
- Registration request status is shown inline in the child selector dialog

### Changes Required
1. **Update navigation label** in DashboardLayout.tsx
2. **Update page title** in AvailablePrograms.tsx
3. **Add new section** showing all registration requests with status (pending/approved/denied)

### New Layout
```text
┌────────────────────────────────────────────────────────────┐
│  📋 Register for a Program                                 │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  MY REGISTRATION REQUESTS                                  │
│  ┌──────────────────────────────────────────────────────┐ │
│  │ Child        │ Program      │ Status    │ Date       │ │
│  ├──────────────┼──────────────┼───────────┼────────────┤ │
│  │ Ahmed        │ Nadi Sumo    │ [Pending] │ Jan 25     │ │
│  │ Ahmed        │ Quran Club   │ [Approved]│ Jan 20     │ │
│  │ Sara         │ Nadi Sumo    │ [Denied]  │ Jan 18     │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                            │
│  AVAILABLE PROGRAMS (existing cards)                       │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                    │
│  │Program 1│  │Program 2│  │Program 3│                    │
│  └─────────┘  └─────────┘  └─────────┘                    │
│                                                            │
└────────────────────────────────────────────────────────────┘
```

### Data Fetching for Requests Section
```typescript
// Fetch all registration requests with student and program details
const { data: registrationRequests } = useQuery({
  queryKey: ['my-registration-requests-full', user?.id],
  queryFn: async () => {
    const { data, error } = await supabase
      .from('registration_requests')
      .select(`
        id, status, created_at,
        student:students(full_name),
        program:programs(name, name_en)
      `)
      .eq('parent_id', user.id)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  },
  enabled: !!user
});
```

---

## Part 2: Update Staff Team Table in My Programs

### Current State
- Title: "فريق العمل" / "Staff Team"
- Columns: Name, Role, Mobile Phone
- Role column shows the program role from `program_roles` table

### Changes Required
1. **Update title** to "مشرفو البرنامج" / "Program Supervisors"
2. **Update Role column** to show "قائد" / "Leader" or "مشرف" / "Supervisor" based on `is_leader` field
3. **Keep mobile phone column** as-is

### Updated Query
```typescript
// Update staff_assignments query to include is_leader
const { data: staffMembers } = useQuery({
  queryKey: ['program-staff', selectedProgram],
  queryFn: async () => {
    const { data, error } = await supabase
      .from('staff_assignments')
      .select(`
        id,
        staff_id,
        is_leader,
        role:program_roles(name, name_en)
      `)
      .eq('program_id', selectedProgram);
    // ... rest of the fetching
  }
});
```

### Updated Table Display
```text
┌──────────────────────────────────────────────────────────┐
│  👥 Program Supervisors                                   │
├──────────────────────────────────────────────────────────┤
│  Name              │ Role        │ Mobile Phone          │
├───────────────────┼─────────────┼───────────────────────┤
│  Mohammed Ahmed 👑 │ Leader      │ 📞 55512345           │
│  Ahmed Salem       │ Supervisor  │ 📞 55567890           │
│  Khalid Omar       │ Supervisor  │ -                     │
└──────────────────────────────────────────────────────────┘
```

---

## Part 3: Enhance Upcoming Sessions in Dashboard

### Current State
- Shows: Program name, student name, date, location, notes
- Missing: Session number, assembly time, dismissal time

### Changes Required
1. **Update query** to fetch session_number, assembly_time, dismissal_time
2. **Update UpcomingSession interface** to include new fields
3. **Update UI** to display session number and times

### Updated Query
```typescript
const { data, error } = await supabase
  .from('sessions')
  .select('id, session_number, session_date, assembly_time, dismissal_time, location, notes, program:programs(id, name, name_en)')
  .in('program_id', uniqueProgramIds)
  .gte('session_date', today)
  .order('session_date', { ascending: true })
  .limit(10);
```

### Updated Session Card
```text
┌──────────────────────────────────────────────────────────┐
│  Nadi Sumo - Session #3                     [25 Jan]     │
│  Ahmed, Sara                                             │
├──────────────────────────────────────────────────────────┤
│  ⏰ 08:30 → 12:00                                        │
│  📍 Main Hall                                            │
│  📝 Outdoor activities if weather permits                │
└──────────────────────────────────────────────────────────┘
```

---

## Files to Modify

| File | Changes |
|------|---------|
| `src/components/layouts/DashboardLayout.tsx` | Update nav label from "البرامج المتاحة" to "التسجيل في برنامج" |
| `src/pages/parent/AvailablePrograms.tsx` | Update title, add registration requests table section |
| `src/pages/parent/MyPrograms.tsx` | Update staff table title, add is_leader to query, show Leader/Supervisor role |
| `src/pages/parent/ParentDashboard.tsx` | Update session query and UI to show session number and times |

---

## Detailed Implementation

### DashboardLayout.tsx (line ~49)
```typescript
// Change from:
{ href: '/parent/available-programs', icon: ClipboardList, label: t('البرامج المتاحة', 'Available Programs') },

// To:
{ href: '/parent/available-programs', icon: ClipboardList, label: t('التسجيل في برنامج', 'Register for a Program') },
```

### AvailablePrograms.tsx
- Update page title to "التسجيل في برنامج" / "Register for a Program"
- Add new query for full registration request details with student/program names
- Add new section before the program cards grid showing a table of all registration requests
- Include status badges (pending=yellow, approved=green, denied=red)

### MyPrograms.tsx (lines ~183-215, ~506-556)
- Update staff query to include `is_leader` field
- Update interface to include `is_leader: boolean`
- Update card title from "فريق العمل" / "Staff Team" to "مشرفو البرنامج" / "Program Supervisors"
- Update Role column to show "قائد" / "Leader" or "مشرف" / "Supervisor" based on is_leader
- Optionally add Crown icon for leader

### ParentDashboard.tsx (lines ~88-136, ~319-360)
- Update UpcomingSession interface to include session_number, assembly_time, dismissal_time
- Update query to fetch these fields
- Update UI to display session number in the header
- Add time display showing assembly → dismissal time with clock icon

---

## Summary

| Change | Component | Description |
|--------|-----------|-------------|
| Navigation | DashboardLayout | Rename "Available Programs" to "Register for a Program" |
| Registration Requests | AvailablePrograms | Add table showing all requests with status |
| Page Title | AvailablePrograms | Update to "Register for a Program" |
| Staff Title | MyPrograms | Change to "Program Supervisors" |
| Staff Role | MyPrograms | Show Leader/Supervisor based on is_leader |
| Session Info | ParentDashboard | Add session number, assembly/dismissal times |
