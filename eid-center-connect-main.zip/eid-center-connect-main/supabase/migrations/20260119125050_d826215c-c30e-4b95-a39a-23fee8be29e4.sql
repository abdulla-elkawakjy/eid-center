-- Add user_id column to students table for student accounts
ALTER TABLE public.students 
ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;

-- Add unique constraint to prevent duplicate student accounts
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'students_user_id_key'
  ) THEN
    ALTER TABLE public.students ADD CONSTRAINT students_user_id_key UNIQUE (user_id);
  END IF;
END $$;

-- RLS Policy: Students can view their own student record
CREATE POLICY "Students can view own student record"
ON public.students FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND user_id = auth.uid()
);

-- RLS Policy: Students can view relevant announcements (global or for their enrolled programs)
CREATE POLICY "Students can view relevant announcements"
ON public.announcements FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND (
    is_global = true OR
    EXISTS (
      SELECT 1 FROM registration_requests rr
      JOIN students s ON s.id = rr.student_id
      WHERE rr.program_id = announcements.program_id
      AND s.user_id = auth.uid()
      AND rr.status = 'approved'
    )
  )
);

-- RLS Policy: Students can view staff profiles for their enrolled programs
CREATE POLICY "Students can view staff profiles for enrolled programs"
ON public.profiles FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND
  EXISTS (
    SELECT 1 FROM staff_assignments sa
    JOIN registration_requests rr ON rr.program_id = sa.program_id
    JOIN students s ON s.id = rr.student_id
    WHERE sa.staff_id = profiles.user_id
    AND s.user_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- RLS Policy: Students can view program files with staff_and_parents visibility for enrolled programs
CREATE POLICY "Students can view visible program files"
ON public.program_files FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND 
  visibility = 'staff_and_parents' AND
  EXISTS (
    SELECT 1 FROM registration_requests rr
    JOIN students s ON s.id = rr.student_id
    WHERE rr.program_id = program_files.program_id
    AND s.user_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- RLS Policy: Students can view their own scores
CREATE POLICY "Students can view own scores"
ON public.student_scores FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM students
    WHERE students.id = student_scores.student_id
    AND students.user_id = auth.uid()
  )
);

-- RLS Policy: Students can view sessions for their enrolled programs
CREATE POLICY "Students can view program sessions"
ON public.sessions FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND
  EXISTS (
    SELECT 1 FROM registration_requests rr
    JOIN students s ON s.id = rr.student_id
    WHERE rr.program_id = sessions.program_id
    AND s.user_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- RLS Policy: Students can view their registration requests
CREATE POLICY "Students can view own registration requests"
ON public.registration_requests FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM students
    WHERE students.id = registration_requests.student_id
    AND students.user_id = auth.uid()
  )
);

-- RLS Policy: Students can view programs they are enrolled in
CREATE POLICY "Students can view enrolled programs"
ON public.programs FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND
  EXISTS (
    SELECT 1 FROM registration_requests rr
    JOIN students s ON s.id = rr.student_id
    WHERE rr.program_id = programs.id
    AND s.user_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- RLS Policy: Students can view assessment criteria for their enrolled programs
CREATE POLICY "Students can view program assessment criteria"
ON public.assessment_criteria FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND
  EXISTS (
    SELECT 1 FROM registration_requests rr
    JOIN students s ON s.id = rr.student_id
    WHERE rr.program_id = assessment_criteria.program_id
    AND s.user_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- RLS Policy: Students can view staff assignments for their enrolled programs
CREATE POLICY "Students can view program staff assignments"
ON public.staff_assignments FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student') AND
  EXISTS (
    SELECT 1 FROM registration_requests rr
    JOIN students s ON s.id = rr.student_id
    WHERE rr.program_id = staff_assignments.program_id
    AND s.user_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- RLS Policy: Students can view program roles
CREATE POLICY "Students can view program roles"
ON public.program_roles FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student')
);

-- RLS Policy: Students can view semesters for their enrolled programs
CREATE POLICY "Students can view semesters"
ON public.semesters FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'student')
);