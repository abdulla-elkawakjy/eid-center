import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { ClipboardList, Check, X } from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import type { Database } from '@/integrations/supabase/types';

type RegistrationStatus = Database['public']['Enums']['registration_status'];

interface RegistrationRequest {
  id: string;
  status: RegistrationStatus;
  notes: string | null;
  created_at: string;
  reviewed_at: string | null;
  student: {
    full_name: string;
  };
  program: {
    name: string;
    name_en: string | null;
  };
  parent_id: string;
}

export default function RegistrationRequests() {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: requests, isLoading } = useQuery({
    queryKey: ['registration-requests'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('registration_requests')
        .select(`
          id,
          status,
          notes,
          created_at,
          reviewed_at,
          parent_id,
          student:students(full_name),
          program:programs(name, name_en)
        `)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as unknown as RegistrationRequest[];
    }
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: RegistrationStatus }) => {
      const { error } = await supabase
        .from('registration_requests')
        .update({
          status,
          reviewed_at: new Date().toISOString(),
          reviewed_by: user?.id
        })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: (_, { status }) => {
      queryClient.invalidateQueries({ queryKey: ['registration-requests'] });
      const message = status === 'approved'
        ? (language === 'ar' ? 'تم قبول الطلب' : 'Request approved')
        : (language === 'ar' ? 'تم رفض الطلب' : 'Request denied');
      toast.success(message);
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'An error occurred');
    }
  });

  const getStatusBadge = (status: RegistrationStatus) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary">{language === 'ar' ? 'قيد الانتظار' : 'Pending'}</Badge>;
      case 'approved':
        return <Badge className="bg-green-500">{language === 'ar' ? 'مقبول' : 'Approved'}</Badge>;
      case 'denied':
        return <Badge variant="destructive">{language === 'ar' ? 'مرفوض' : 'Denied'}</Badge>;
      default:
        return null;
    }
  };

  const formatDate = (date: string) => {
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <ClipboardList className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-foreground">
            {language === 'ar' ? 'طلبات التسجيل' : 'Registration Requests'}
          </h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'جميع الطلبات' : 'All Requests'}</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">
                {language === 'ar' ? 'جاري التحميل...' : 'Loading...'}
              </div>
            ) : requests?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {language === 'ar' ? 'لا يوجد طلبات' : 'No requests found'}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{language === 'ar' ? 'الطالب' : 'Student'}</TableHead>
                      <TableHead>{language === 'ar' ? 'البرنامج' : 'Program'}</TableHead>
                      <TableHead>{language === 'ar' ? 'تاريخ الطلب' : 'Request Date'}</TableHead>
                      <TableHead>{language === 'ar' ? 'الحالة' : 'Status'}</TableHead>
                      <TableHead>{language === 'ar' ? 'الإجراءات' : 'Actions'}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {requests?.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-medium">
                          {request.student?.full_name || '-'}
                        </TableCell>
                        <TableCell>
                          {language === 'ar'
                            ? request.program?.name
                            : request.program?.name_en || request.program?.name}
                        </TableCell>
                        <TableCell>{formatDate(request.created_at)}</TableCell>
                        <TableCell>{getStatusBadge(request.status)}</TableCell>
                        <TableCell>
                          {request.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-green-600 hover:text-green-700 hover:bg-green-50"
                                onClick={() => updateStatusMutation.mutate({ id: request.id, status: 'approved' })}
                              >
                                <Check className="h-4 w-4 me-1" />
                                {language === 'ar' ? 'قبول' : 'Approve'}
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-destructive hover:text-destructive hover:bg-destructive/10"
                                onClick={() => updateStatusMutation.mutate({ id: request.id, status: 'denied' })}
                              >
                                <X className="h-4 w-4 me-1" />
                                {language === 'ar' ? 'رفض' : 'Deny'}
                              </Button>
                            </div>
                          )}
                          {request.status !== 'pending' && request.reviewed_at && (
                            <span className="text-sm text-muted-foreground">
                              {formatDate(request.reviewed_at)}
                            </span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
