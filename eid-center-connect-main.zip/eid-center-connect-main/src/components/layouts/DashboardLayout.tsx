import { ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Logo } from '@/components/Logo';
import { LanguageToggle } from '@/components/LanguageToggle';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { LayoutDashboard, Users, GraduationCap, BookOpen, ClipboardList, UserCog, LogOut, Menu, X, Baby, FileText, Package } from 'lucide-react';
import { useState } from 'react';

interface DashboardLayoutProps {
  children: ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { t } = useLanguage();
  const { role, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const adminNavItems = [
    { href: '/dashboard', icon: LayoutDashboard, label: t('لوحة التحكم', 'Dashboard') },
    { href: '/dashboard/staff', icon: UserCog, label: t('المشرفون', 'Supervisors') },
    { href: '/dashboard/parents', icon: Users, label: t('أولياء الأمور', 'Parents') },
    { href: '/dashboard/students', icon: GraduationCap, label: t('الطلاب', 'Students') },
    { href: '/dashboard/programs', icon: BookOpen, label: t('البرامج', 'Programs') },
    { href: '/dashboard/registrations', icon: ClipboardList, label: t('طلبات التسجيل', 'Registrations') },
    { href: '/dashboard/reports', icon: FileText, label: t('التقارير', 'Reports') },
    { href: '/store', icon: Package, label: t('المخزن', 'Store') },
  ];

  const staffNavItems = [
    { href: '/dashboard', icon: LayoutDashboard, label: t('لوحة التحكم', 'Dashboard') },
    { href: '/dashboard/assignments', icon: ClipboardList, label: t('المهام', 'Assignments') },
  ];

  const storeKeeperNavItems = [
    { href: '/dashboard', icon: LayoutDashboard, label: t('لوحة التحكم', 'Dashboard') },
    { href: '/store', icon: Package, label: t('المخزن', 'Store') },
  ];

  const parentNavItems = [
    { href: '/parent/dashboard', icon: LayoutDashboard, label: t('لوحة التحكم', 'Dashboard') },
    { href: '/parent/children', icon: Baby, label: t('أبنائي', 'My Children') },
    { href: '/parent/my-programs', icon: BookOpen, label: t('برامجي', 'My Programs') },
    { href: '/parent/available-programs', icon: ClipboardList, label: t('التسجيل في برنامج', 'Register for a Program') },
  ];

  const studentNavItems = [
    { href: '/student/dashboard', icon: LayoutDashboard, label: t('لوحة التحكم', 'Dashboard') },
    { href: '/student/programs', icon: BookOpen, label: t('برامجي', 'My Programs') },
  ];

  const navItems = role === 'admin' 
    ? adminNavItems 
    : role === 'staff' 
    ? staffNavItems 
    : role === 'store_keeper'
    ? storeKeeperNavItems
    : role === 'student' 
    ? studentNavItems 
    : parentNavItems;

  

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Mobile Menu Button */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="lg:hidden fixed top-4 end-4 z-50 p-2 rounded-lg bg-primary text-primary-foreground"
      >
        {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </button>

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 start-0 z-40 w-72 bg-sidebar transform transition-transform duration-300',
          'lg:ltr:translate-x-0 lg:rtl:translate-x-0',
          sidebarOpen
            ? 'ltr:translate-x-0 rtl:translate-x-0'
            : 'ltr:-translate-x-full rtl:translate-x-full'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-sidebar-border">
            <Logo size="sm" className="text-sidebar-foreground" />
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {navItems.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-4 py-3 rounded-lg transition-colors',
                    isActive
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Footer */}
          <div className="p-4 border-t border-sidebar-border space-y-3">
            <div className="flex items-center gap-2">
              <LanguageToggle />
              <ThemeToggle />
            </div>
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              onClick={handleSignOut}
            >
              <LogOut className="h-5 w-5" />
              {t('تسجيل الخروج', 'Sign Out')}
            </Button>
          </div>
        </div>
      </aside>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="flex-1 lg:ms-72">
        <div className="p-6 lg:p-8">{children}</div>
      </main>
    </div>
  );
}
