import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, Loader2, Users } from 'lucide-react';
import { NationalitySelect } from '@/components/shared/NationalitySelect';

interface Parent {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  qid_number: string | null;
  nationality: string | null;
  mother_phone: string | null;
  created_at: string;
}

export default function ParentsManagement() {
  const { t } = useLanguage();
  const { user, role, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [parents, setParents] = useState<Parent[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingParent, setEditingParent] = useState<Parent | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    qidNumber: '',
    nationality: '',
    motherPhone: '',
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/staff-login');
      return;
    }

    if (!authLoading && role !== 'admin') {
      navigate('/dashboard');
      return;
    }

    if (user && role === 'admin') {
      fetchParents();
    }
  }, [user, role, authLoading, navigate]);

  const fetchParents = async () => {
    try {
      const { data: parentRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'parent');

      if (rolesError) throw rolesError;

      if (parentRoles && parentRoles.length > 0) {
        const userIds = parentRoles.map((r) => r.user_id);
        
        const { data: profiles, error: profilesError } = await supabase
          .from('profiles')
          .select('*')
          .in('user_id', userIds);

        if (profilesError) throw profilesError;

        setParents(profiles || []);
      } else {
        setParents([]);
      }
    } catch (error) {
      console.error('Error fetching parents:', error);
      toast({
        title: t('خطأ', 'Error'),
        description: t('فشل في تحميل بيانات أولياء الأمور', 'Failed to load parents data'),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      if (editingParent) {
        // Update existing parent profile
        const { error } = await supabase
          .from('profiles')
          .update({
            full_name: formData.fullName,
            phone: formData.phone,
            qid_number: formData.qidNumber,
            nationality: formData.nationality,
            mother_phone: formData.motherPhone || null,
          })
          .eq('id', editingParent.id);

        if (error) throw error;

        toast({
          title: t('تم التحديث', 'Updated'),
          description: t('تم تحديث بيانات ولي الأمر بنجاح', 'Parent updated successfully'),
        });
      } else {
        // Create new parent user via edge function (preserves admin session)
        const { data: funcData, error: funcError } = await supabase.functions.invoke('admin-create-user', {
          body: {
            email: formData.email,
            password: formData.password,
            fullName: formData.fullName,
            phone: formData.phone || undefined,
            qidNumber: formData.qidNumber,
            nationality: formData.nationality,
            motherPhone: formData.motherPhone || undefined,
            role: 'parent'
          }
        });

        if (funcError) throw funcError;
        if (funcData?.error) throw new Error(funcData.error);

        toast({
          title: t('تم الإنشاء', 'Created'),
          description: t('تم إنشاء حساب ولي الأمر بنجاح', 'Parent account created successfully'),
        });
      }

      setIsDialogOpen(false);
      resetForm();
      fetchParents();
    } catch (error: any) {
      console.error('Error saving parent:', error);
      toast({
        title: t('خطأ', 'Error'),
        description: error.message || t('فشل في حفظ البيانات', 'Failed to save data'),
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (parent: Parent) => {
    if (!confirm(t('هل أنت متأكد من حذف ولي الأمر هذا؟', 'Are you sure you want to delete this parent?'))) {
      return;
    }

    try {
      // Delete the user role first
      const { error: roleError } = await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', parent.user_id);

      if (roleError) throw roleError;

      toast({
        title: t('تم الحذف', 'Deleted'),
        description: t('تم حذف ولي الأمر بنجاح', 'Parent deleted successfully'),
      });

      fetchParents();
    } catch (error: any) {
      console.error('Error deleting parent:', error);
      toast({
        title: t('خطأ', 'Error'),
        description: t('فشل في حذف ولي الأمر', 'Failed to delete parent'),
        variant: 'destructive',
      });
    }
  };

  const openEditDialog = (parent: Parent) => {
    setEditingParent(parent);
    setFormData({
      fullName: parent.full_name,
      email: parent.email,
      phone: parent.phone || '',
      password: '',
      qidNumber: parent.qid_number || '',
      nationality: parent.nationality || '',
      motherPhone: parent.mother_phone || '',
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({ fullName: '', email: '', phone: '', password: '', qidNumber: '', nationality: '', motherPhone: '' });
    setEditingParent(null);
  };

  if (authLoading || loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              <Users className="h-8 w-8 text-primary" />
              {t('أولياء الأمور', 'Parents')}
            </h1>
            <p className="text-muted-foreground mt-1">
              {t('إضافة وتعديل وحذف حسابات أولياء الأمور', 'Add, edit, and delete parent accounts')}
            </p>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                {t('إضافة ولي أمر', 'Add Parent')}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingParent
                    ? t('تعديل بيانات ولي الأمر', 'Edit Parent')
                    : t('إضافة ولي أمر جديد', 'Add New Parent')}
                </DialogTitle>
                <DialogDescription>
                  {editingParent
                    ? t('قم بتحديث بيانات ولي الأمر', 'Update parent details')
                    : t('أدخل بيانات ولي الأمر الجديد', 'Enter new parent details')}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>{t('اسم الأب الكامل', 'Father Full Name')} *</Label>
                  <Input
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('رقم البطاقة الشخصية للأب', 'Father QID Number')} *</Label>
                  <Input
                    value={formData.qidNumber}
                    onChange={(e) => setFormData({ ...formData, qidNumber: e.target.value })}
                    required
                    placeholder="XXXXXXXXXXX"
                    maxLength={11}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('رقم جوال الأب', 'Father Mobile Number')} *</Label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                    placeholder="+974 XXXXXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('رقم جوال الأم', 'Mother Mobile Number')} ({t('اختياري', 'Optional')})</Label>
                  <Input
                    value={formData.motherPhone}
                    onChange={(e) => setFormData({ ...formData, motherPhone: e.target.value })}
                    placeholder="+974 XXXXXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('جنسية الأب', 'Father Nationality')} *</Label>
                  <NationalitySelect
                    value={formData.nationality}
                    onValueChange={(value) => setFormData({ ...formData, nationality: value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('البريد الإلكتروني', 'Email')} *</Label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    disabled={!!editingParent}
                  />
                </div>
                {!editingParent && (
                  <div className="space-y-2">
                    <Label>{t('كلمة المرور', 'Password')} *</Label>
                    <Input
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      required
                      minLength={6}
                    />
                  </div>
                )}
                <div className="flex gap-3 pt-4">
                  <Button type="submit" className="flex-1" disabled={submitting}>
                    {submitting && <Loader2 className="h-4 w-4 me-2 animate-spin" />}
                    {editingParent ? t('تحديث', 'Update') : t('إضافة', 'Add')}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    {t('إلغاء', 'Cancel')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Parents Table */}
        <Card>
          <CardHeader>
            <CardTitle>{t('قائمة أولياء الأمور', 'Parents List')}</CardTitle>
          </CardHeader>
          <CardContent>
            {parents.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                {t('لا يوجد أولياء أمور مسجلين', 'No parents registered')}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('اسم الأب', 'Father Name')}</TableHead>
                      <TableHead>{t('رقم البطاقة', 'QID')}</TableHead>
                      <TableHead>{t('جوال الأب', 'Father Mobile')}</TableHead>
                      <TableHead>{t('الجنسية', 'Nationality')}</TableHead>
                      <TableHead>{t('البريد', 'Email')}</TableHead>
                      <TableHead className="w-[100px]">{t('إجراءات', 'Actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parents.map((parent) => (
                      <TableRow key={parent.id}>
                        <TableCell className="font-medium">{parent.full_name}</TableCell>
                        <TableCell>{parent.qid_number || '-'}</TableCell>
                        <TableCell>{parent.phone || '-'}</TableCell>
                        <TableCell>{parent.nationality || '-'}</TableCell>
                        <TableCell>{parent.email}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditDialog(parent)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-destructive"
                              onClick={() => handleDelete(parent)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
