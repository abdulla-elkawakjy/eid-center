import { useState, useEffect } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Loader2 } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  name_en: string | null;
  description?: string | null;
}

interface CategoryFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  category?: Category | null;
  onSubmit: (data: { name: string; name_en: string; description: string }) => void;
  isLoading?: boolean;
}

export function CategoryForm({ open, onOpenChange, category, onSubmit, isLoading }: CategoryFormProps) {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    name_en: '',
    description: '',
  });

  useEffect(() => {
    if (category) {
      setFormData({
        name: category.name,
        name_en: category.name_en || '',
        description: category.description || '',
      });
    } else {
      setFormData({ name: '', name_en: '', description: '' });
    }
  }, [category, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {category ? t('تعديل الفئة', 'Edit Category') : t('إضافة فئة', 'Add Category')}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>{t('الاسم بالعربية', 'Arabic Name')} *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              dir="rtl"
            />
          </div>
          <div className="space-y-2">
            <Label>{t('الاسم بالإنجليزية', 'English Name')}</Label>
            <Input
              value={formData.name_en}
              onChange={(e) => setFormData({ ...formData, name_en: e.target.value })}
              dir="ltr"
            />
          </div>
          <div className="space-y-2">
            <Label>{t('الوصف', 'Description')}</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>
          <div className="flex gap-3 pt-4 rtl:flex-row-reverse">
            <Button type="submit" className="flex-1" disabled={isLoading}>
              {isLoading && <Loader2 className="h-4 w-4 me-2 animate-spin" />}
              {category ? t('تحديث', 'Update') : t('إضافة', 'Add')}
            </Button>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('إلغاء', 'Cancel')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
