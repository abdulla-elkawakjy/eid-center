import { useState, useEffect } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

type ItemType = 'disposable' | 'reusable';

interface Category {
  id: string;
  name: string;
  name_en: string | null;
}

interface StoreItem {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
  category_id: string | null;
  item_type: ItemType;
  quantity: number;
  available_quantity: number;
}

interface ItemFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: StoreItem | null;
  categories: Category[];
  onSubmit: (data: {
    name: string;
    name_en: string;
    description: string;
    category_id: string;
    item_type: ItemType;
    quantity: number;
  }) => void;
  isLoading?: boolean;
}

export function ItemForm({ open, onOpenChange, item, categories, onSubmit, isLoading }: ItemFormProps) {
  const { t, language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    name_en: '',
    description: '',
    category_id: '',
    item_type: 'reusable' as ItemType,
    quantity: 0,
  });

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name,
        name_en: item.name_en || '',
        description: item.description || '',
        category_id: item.category_id || '',
        item_type: item.item_type,
        quantity: item.quantity,
      });
    } else {
      setFormData({
        name: '',
        name_en: '',
        description: '',
        category_id: '',
        item_type: 'reusable',
        quantity: 0,
      });
    }
  }, [item, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {item ? t('تعديل المنتج', 'Edit Item') : t('إضافة منتج', 'Add Item')}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>{t('الاسم بالعربية', 'Arabic Name')} *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              dir="rtl"
            />
          </div>
          <div className="space-y-2">
            <Label>{t('الاسم بالإنجليزية', 'English Name')}</Label>
            <Input
              value={formData.name_en}
              onChange={(e) => setFormData({ ...formData, name_en: e.target.value })}
              dir="ltr"
            />
          </div>
          <div className="space-y-2">
            <Label>{t('الفئة', 'Category')}</Label>
            <Select
              value={formData.category_id}
              onValueChange={(value) => setFormData({ ...formData, category_id: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder={t('اختر الفئة', 'Select Category')} />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {language === 'ar' ? cat.name : cat.name_en || cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>{t('النوع', 'Type')} *</Label>
            <Select
              value={formData.item_type}
              onValueChange={(value: ItemType) => setFormData({ ...formData, item_type: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="reusable">{t('قابل للإرجاع', 'Reusable')}</SelectItem>
                <SelectItem value="disposable">{t('مستهلك', 'Disposable')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>{t('الكمية', 'Quantity')} *</Label>
            <Input
              type="number"
              min="0"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 0 })}
              required
            />
          </div>
          <div className="space-y-2">
            <Label>{t('الوصف', 'Description')}</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>
          <div className="flex gap-3 pt-4 rtl:flex-row-reverse">
            <Button type="submit" className="flex-1" disabled={isLoading}>
              {isLoading && <Loader2 className="h-4 w-4 me-2 animate-spin" />}
              {item ? t('تحديث', 'Update') : t('إضافة', 'Add')}
            </Button>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('إلغاء', 'Cancel')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
