import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, BookOpen, Upload, FileText, Download, X, GripVertical } from 'lucide-react';

interface ProgramCoursesSectionProps {
  programId: string;
  isAdmin: boolean;
}

interface ProgramCourse {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
  description_en: string | null;
  order_index: number;
}

interface CourseFile {
  id: string;
  course_id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
}

export function ProgramCoursesSection({ programId, isAdmin }: ProgramCoursesSectionProps) {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<ProgramCourse | null>(null);
  const [uploadingCourseId, setUploadingCourseId] = useState<string | null>(null);
  
  const [form, setForm] = useState({
    name: '',
    name_en: '',
    description: '',
    description_en: '',
    order_index: '0'
  });
  
  const [editForm, setEditForm] = useState({
    name: '',
    name_en: '',
    description: '',
    description_en: '',
    order_index: '0'
  });

  // Fetch courses
  const { data: courses } = useQuery({
    queryKey: ['program-courses', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('program_courses')
        .select('*')
        .eq('program_id', programId)
        .order('order_index', { ascending: true });
      if (error) throw error;
      return data as ProgramCourse[];
    },
    enabled: !!programId
  });

  // Fetch course files
  const { data: courseFiles } = useQuery({
    queryKey: ['course-files', programId],
    queryFn: async () => {
      const courseIds = courses?.map(c => c.id) || [];
      if (courseIds.length === 0) return [];
      
      const { data, error } = await supabase
        .from('course_files')
        .select('*')
        .in('course_id', courseIds);
      if (error) throw error;
      return data as CourseFile[];
    },
    enabled: !!courses && courses.length > 0
  });

  // Create course mutation
  const createCourseMutation = useMutation({
    mutationFn: async (data: typeof form) => {
      const { error } = await supabase.from('program_courses').insert({
        program_id: programId,
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
        description_en: data.description_en || null,
        order_index: parseInt(data.order_index) || 0
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['program-courses', programId] });
      toast.success(language === 'ar' ? 'تم إضافة المقرر' : 'Course added');
      setIsDialogOpen(false);
      setForm({ name: '', name_en: '', description: '', description_en: '', order_index: '0' });
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'Error adding course');
    }
  });

  // Update course mutation
  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof editForm }) => {
      const { error } = await supabase.from('program_courses').update({
        name: data.name,
        name_en: data.name_en || null,
        description: data.description || null,
        description_en: data.description_en || null,
        order_index: parseInt(data.order_index) || 0
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['program-courses', programId] });
      toast.success(language === 'ar' ? 'تم تحديث المقرر' : 'Course updated');
      setIsEditDialogOpen(false);
      setEditingCourse(null);
    }
  });

  // Delete course mutation
  const deleteCourseMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('program_courses').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['program-courses', programId] });
      toast.success(language === 'ar' ? 'تم حذف المقرر' : 'Course deleted');
    }
  });

  // Upload file mutation
  const uploadFileMutation = useMutation({
    mutationFn: async ({ courseId, file }: { courseId: string; file: File }) => {
      const filePath = `courses/${courseId}/${Date.now()}_${file.name}`;
      
      const { error: uploadError } = await supabase.storage
        .from('program-files')
        .upload(filePath, file);
      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase.from('course_files').insert({
        course_id: courseId,
        file_name: file.name,
        file_path: filePath,
        file_type: file.type,
        file_size: file.size,
        uploaded_by: user?.id
      });
      if (dbError) throw dbError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['course-files', programId] });
      toast.success(language === 'ar' ? 'تم رفع الملف' : 'File uploaded');
      setUploadingCourseId(null);
    },
    onError: () => {
      toast.error(language === 'ar' ? 'خطأ في رفع الملف' : 'Error uploading file');
    }
  });

  // Delete file mutation
  const deleteFileMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const file = courseFiles?.find(f => f.id === fileId);
      if (file) {
        await supabase.storage.from('program-files').remove([file.file_path]);
      }
      const { error } = await supabase.from('course_files').delete().eq('id', fileId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['course-files', programId] });
      toast.success(language === 'ar' ? 'تم حذف الملف' : 'File deleted');
    }
  });

  const handleEditCourse = (course: ProgramCourse) => {
    setEditingCourse(course);
    setEditForm({
      name: course.name,
      name_en: course.name_en || '',
      description: course.description || '',
      description_en: course.description_en || '',
      order_index: course.order_index.toString()
    });
    setIsEditDialogOpen(true);
  };

  const handleFileUpload = async (courseId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingCourseId(courseId);
    uploadFileMutation.mutate({ courseId, file });
  };

  const handleDownloadFile = async (file: CourseFile) => {
    const { data } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 3600);
    if (data?.signedUrl) {
      window.open(data.signedUrl, '_blank');
    }
  };

  const getFilesForCourse = (courseId: string) => 
    courseFiles?.filter(f => f.course_id === courseId) || [];

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center rtl:flex-row-reverse">
        <h3 className="text-lg font-semibold flex items-center gap-2 rtl:flex-row-reverse">
          <BookOpen className="h-5 w-5" />
          {language === 'ar' ? 'مقررات البرنامج' : 'Program Courses'}
        </h3>
        {isAdmin && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 me-2" />
                {language === 'ar' ? 'إضافة مقرر' : 'Add Course'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>{language === 'ar' ? 'إضافة مقرر جديد' : 'Add New Course'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={(e) => { e.preventDefault(); createCourseMutation.mutate(form); }} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                    <Input
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                    <Input
                      value={form.name_en}
                      onChange={(e) => setForm({ ...form, name_en: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'الوصف (عربي)' : 'Description (Arabic)'}</Label>
                  <Textarea
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'الوصف (إنجليزي)' : 'Description (English)'}</Label>
                  <Textarea
                    value={form.description_en}
                    onChange={(e) => setForm({ ...form, description_en: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'الترتيب' : 'Order'}</Label>
                  <Input
                    type="number"
                    value={form.order_index}
                    onChange={(e) => setForm({ ...form, order_index: e.target.value })}
                  />
                </div>
                <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </Button>
                  <Button type="submit" disabled={createCourseMutation.isPending}>
                    {language === 'ar' ? 'إضافة' : 'Add'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {courses?.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center text-muted-foreground">
            {language === 'ar' ? 'لا توجد مقررات' : 'No courses yet'}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {courses?.map((course, index) => {
            const files = getFilesForCourse(course.id);
            return (
              <Card key={course.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start rtl:flex-row-reverse">
                    <div className="flex items-center gap-2 rtl:flex-row-reverse">
                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">{index + 1}.</span>
                      <CardTitle className="text-base">
                        {language === 'ar' ? course.name : course.name_en || course.name}
                      </CardTitle>
                    </div>
                    {isAdmin && (
                      <div className="flex gap-1 rtl:flex-row-reverse">
                        <Button size="sm" variant="ghost" onClick={() => handleEditCourse(course)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-destructive" 
                          onClick={() => deleteCourseMutation.mutate(course.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {(course.description || course.description_en) && (
                    <p className="text-sm text-muted-foreground">
                      {language === 'ar' ? course.description : course.description_en || course.description}
                    </p>
                  )}
                  
                  {/* Files */}
                  <div className="flex flex-wrap gap-2 items-center">
                    {files.map(file => (
                      <div 
                        key={file.id} 
                        className="flex items-center gap-2 bg-muted px-3 py-1.5 rounded-md text-sm rtl:flex-row-reverse"
                      >
                        <FileText className="h-4 w-4" />
                        <span className="max-w-[150px] truncate">{file.file_name}</span>
                        <span className="text-muted-foreground text-xs">({formatFileSize(file.file_size)})</span>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-6 w-6 p-0" 
                          onClick={() => handleDownloadFile(file)}
                        >
                          <Download className="h-3 w-3" />
                        </Button>
                        {isAdmin && (
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-6 w-6 p-0 text-destructive" 
                            onClick={() => deleteFileMutation.mutate(file.id)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    ))}
                    
                    {isAdmin && (
                      <label className="cursor-pointer">
                        <input
                          type="file"
                          className="hidden"
                          onChange={(e) => handleFileUpload(course.id, e)}
                          disabled={uploadingCourseId === course.id}
                        />
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="gap-1" 
                          asChild
                          disabled={uploadingCourseId === course.id}
                        >
                          <span>
                            <Upload className="h-3 w-3" />
                            {uploadingCourseId === course.id 
                              ? (language === 'ar' ? 'جاري الرفع...' : 'Uploading...')
                              : (language === 'ar' ? 'رفع ملف' : 'Upload')
                            }
                          </span>
                        </Button>
                      </label>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{language === 'ar' ? 'تعديل المقرر' : 'Edit Course'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={(e) => { 
            e.preventDefault(); 
            if (editingCourse) {
              updateCourseMutation.mutate({ id: editingCourse.id, data: editForm }); 
            }
          }} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                <Input
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                <Input
                  value={editForm.name_en}
                  onChange={(e) => setEditForm({ ...editForm, name_en: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>{language === 'ar' ? 'الوصف (عربي)' : 'Description (Arabic)'}</Label>
              <Textarea
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label>{language === 'ar' ? 'الوصف (إنجليزي)' : 'Description (English)'}</Label>
              <Textarea
                value={editForm.description_en}
                onChange={(e) => setEditForm({ ...editForm, description_en: e.target.value })}
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label>{language === 'ar' ? 'الترتيب' : 'Order'}</Label>
              <Input
                type="number"
                value={editForm.order_index}
                onChange={(e) => setEditForm({ ...editForm, order_index: e.target.value })}
              />
            </div>
            <div className="flex justify-end gap-2 rtl:flex-row-reverse">
              <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                {language === 'ar' ? 'إلغاء' : 'Cancel'}
              </Button>
              <Button type="submit" disabled={updateCourseMutation.isPending}>
                {language === 'ar' ? 'حفظ' : 'Save'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
