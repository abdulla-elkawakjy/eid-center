import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Baby, User, Key, Loader2, CheckCircle, Mail, Lock } from 'lucide-react';
import { NationalitySelect } from '@/components/shared/NationalitySelect';

interface Student {
  id: string;
  full_name: string;
  date_of_birth: string | null;
  gender: string | null;
  notes: string | null;
  parent_id: string;
  created_at: string;
  qid_number: string | null;
  school_grade: number | null;
  mobile_number: string | null;
  nationality: string | null;
  has_health_conditions: boolean | null;
  health_conditions_details: string | null;
  user_id: string | null;
}

export default function MyChildren() {
  const { language, t } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAccountDialogOpen, setIsAccountDialogOpen] = useState(false);
  const [editingChild, setEditingChild] = useState<Student | null>(null);
  const [selectedChildForAccount, setSelectedChildForAccount] = useState<Student | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [creatingAccount, setCreatingAccount] = useState(false);
  
  // Combined form data for new registration (profile + account)
  const [formData, setFormData] = useState({
    full_name: '',
    date_of_birth: '',
    gender: '',
    notes: '',
    qid_number: '',
    school_grade: '',
    mobile_number: '',
    nationality: '',
    has_health_conditions: 'no' as 'yes' | 'no',
    health_conditions_details: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  // Separate form for legacy account creation
  const [accountFormData, setAccountFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
  });

  const { data: children, isLoading } = useQuery({
    queryKey: ['my-children', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('parent_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as Student[];
    },
    enabled: !!user
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<typeof formData> }) => {
      const { error } = await supabase.from('students').update({
        full_name: data.full_name,
        date_of_birth: data.date_of_birth || null,
        gender: data.gender || null,
        notes: data.notes || null,
        qid_number: data.qid_number,
        school_grade: data.school_grade ? parseInt(data.school_grade) : null,
        mobile_number: data.mobile_number || null,
        nationality: data.nationality,
        has_health_conditions: data.has_health_conditions === 'yes',
        health_conditions_details: data.has_health_conditions === 'yes' ? data.health_conditions_details : null,
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-children'] });
      toast.success(language === 'ar' ? 'تم تحديث البيانات بنجاح' : 'Child updated successfully');
      resetForm();
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء التحديث' : 'Error updating child');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('students').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-children'] });
      toast.success(language === 'ar' ? 'تم حذف الابن بنجاح' : 'Child removed successfully');
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الحذف' : 'Error removing child');
    }
  });

  const resetForm = () => {
    setFormData({
      full_name: '',
      date_of_birth: '',
      gender: '',
      notes: '',
      qid_number: '',
      school_grade: '',
      mobile_number: '',
      nationality: '',
      has_health_conditions: 'no',
      health_conditions_details: '',
      email: '',
      password: '',
      confirmPassword: '',
    });
    setEditingChild(null);
    setIsDialogOpen(false);
  };

  const resetAccountForm = () => {
    setAccountFormData({
      email: '',
      password: '',
      confirmPassword: '',
    });
    setSelectedChildForAccount(null);
    setIsAccountDialogOpen(false);
  };

  const handleEdit = (child: Student) => {
    setEditingChild(child);
    setFormData({
      full_name: child.full_name,
      date_of_birth: child.date_of_birth || '',
      gender: child.gender || '',
      notes: child.notes || '',
      qid_number: child.qid_number || '',
      school_grade: child.school_grade?.toString() || '',
      mobile_number: child.mobile_number || '',
      nationality: child.nationality || '',
      has_health_conditions: child.has_health_conditions ? 'yes' : 'no',
      health_conditions_details: child.health_conditions_details || '',
      email: '',
      password: '',
      confirmPassword: '',
    });
    setIsDialogOpen(true);
  };

  const handleOpenAccountDialog = (child: Student) => {
    setSelectedChildForAccount(child);
    setAccountFormData({
      email: '',
      password: '',
      confirmPassword: '',
    });
    setIsAccountDialogOpen(true);
  };

  // Create account for existing (legacy) student
  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedChildForAccount) return;
    
    if (accountFormData.password !== accountFormData.confirmPassword) {
      toast.error(language === 'ar' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
      return;
    }

    if (accountFormData.password.length < 6) {
      toast.error(language === 'ar' ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' : 'Password must be at least 6 characters');
      return;
    }

    setCreatingAccount(true);

    try {
      const response = await supabase.functions.invoke('admin-create-user', {
        body: {
          email: accountFormData.email,
          password: accountFormData.password,
          fullName: selectedChildForAccount.full_name,
          role: 'student',
          studentId: selectedChildForAccount.id,
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to create account');
      }

      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      toast.success(language === 'ar' ? 'تم إنشاء حساب الطالب بنجاح' : 'Student account created successfully');
      queryClient.invalidateQueries({ queryKey: ['my-children'] });
      resetAccountForm();
    } catch (error: any) {
      console.error('Error creating student account:', error);
      toast.error(error.message || (language === 'ar' ? 'حدث خطأ أثناء إنشاء الحساب' : 'Error creating account'));
    } finally {
      setCreatingAccount(false);
    }
  };

  // Combined submit for new registration (creates profile + account together)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingChild) {
      // Just update the profile (no account changes for existing students)
      updateMutation.mutate({ id: editingChild.id, data: formData });
      return;
    }

    // Validate password match for new registration
    if (formData.password !== formData.confirmPassword) {
      toast.error(language === 'ar' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      toast.error(language === 'ar' ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' : 'Password must be at least 6 characters');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await supabase.functions.invoke('admin-create-user', {
        body: {
          email: formData.email,
          password: formData.password,
          fullName: formData.full_name,
          role: 'student',
          studentData: {
            full_name: formData.full_name,
            date_of_birth: formData.date_of_birth || undefined,
            gender: formData.gender || undefined,
            notes: formData.notes || undefined,
            qid_number: formData.qid_number || undefined,
            school_grade: formData.school_grade ? parseInt(formData.school_grade) : undefined,
            mobile_number: formData.mobile_number || undefined,
            nationality: formData.nationality || undefined,
            has_health_conditions: formData.has_health_conditions === 'yes',
            health_conditions_details: formData.has_health_conditions === 'yes' ? formData.health_conditions_details : undefined,
          },
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to register child');
      }

      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      toast.success(language === 'ar' ? 'تم تسجيل الابن بنجاح' : 'Child registered successfully');
      queryClient.invalidateQueries({ queryKey: ['my-children'] });
      resetForm();
    } catch (error: any) {
      console.error('Error registering child:', error);
      toast.error(error.message || (language === 'ar' ? 'حدث خطأ أثناء التسجيل' : 'Error registering child'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const gradeOptions = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Baby className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">
              {language === 'ar' ? 'أبنائي' : 'My Children'}
            </h1>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetForm()}>
                <Plus className="h-4 w-4 me-2" />
                {language === 'ar' ? 'تسجيل ابن جديد' : 'Register Child'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingChild
                    ? (language === 'ar' ? 'تعديل بيانات الابن' : 'Edit Child')
                    : (language === 'ar' ? 'تسجيل ابن جديد' : 'Register New Child')}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Account Section - Only for new registration */}
                {!editingChild && (
                  <>
                    <div className="flex items-center gap-2 text-primary">
                      <Key className="h-4 w-4" />
                      <span className="font-medium">{t('معلومات الحساب', 'Account Information')}</span>
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        {t('البريد الإلكتروني', 'Email')} *
                      </Label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        placeholder={t('أدخل البريد الإلكتروني', 'Enter email')}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <Lock className="h-4 w-4" />
                          {t('كلمة المرور', 'Password')} *
                        </Label>
                        <Input
                          type="password"
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          required
                          minLength={6}
                          placeholder={t('6 أحرف على الأقل', 'At least 6 characters')}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>{t('تأكيد كلمة المرور', 'Confirm Password')} *</Label>
                        <Input
                          type="password"
                          value={formData.confirmPassword}
                          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                          required
                          minLength={6}
                          placeholder={t('أعد إدخال كلمة المرور', 'Re-enter password')}
                        />
                      </div>
                    </div>

                    <Separator className="my-4" />
                    
                    <div className="flex items-center gap-2 text-primary">
                      <User className="h-4 w-4" />
                      <span className="font-medium">{t('معلومات الابن', 'Child Information')}</span>
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label>{t('الاسم الكامل', 'Full Name')} *</Label>
                  <Input
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('رقم البطاقة الشخصية', 'QID Number')} *</Label>
                  <Input
                    value={formData.qid_number}
                    onChange={(e) => setFormData({ ...formData, qid_number: e.target.value })}
                    required
                    placeholder="XXXXXXXXXXX"
                    maxLength={11}
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('تاريخ الميلاد', 'Date of Birth')} *</Label>
                  <Input
                    type="date"
                    value={formData.date_of_birth}
                    onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('الصف الدراسي الحالي', 'Current School Grade')} *</Label>
                  <Select
                    value={formData.school_grade}
                    onValueChange={(value) => setFormData({ ...formData, school_grade: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('اختر الصف', 'Select Grade')} />
                    </SelectTrigger>
                    <SelectContent>
                      {gradeOptions.map((grade) => (
                        <SelectItem key={grade} value={grade.toString()}>
                          {language === 'ar' ? `الصف ${grade}` : `Grade ${grade}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>{t('الجنس', 'Gender')}</Label>
                  <Select
                    value={formData.gender}
                    onValueChange={(value) => setFormData({ ...formData, gender: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={language === 'ar' ? 'اختر الجنس' : 'Select Gender'} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">{language === 'ar' ? 'ذكر' : 'Male'}</SelectItem>
                      <SelectItem value="female">{language === 'ar' ? 'أنثى' : 'Female'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>{t('رقم الجوال', 'Mobile Number')} ({t('اختياري', 'Optional')})</Label>
                  <Input
                    value={formData.mobile_number}
                    onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                    placeholder="+974 XXXXXXXX"
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('الجنسية', 'Nationality')} *</Label>
                  <NationalitySelect
                    value={formData.nationality}
                    onValueChange={(value) => setFormData({ ...formData, nationality: value })}
                    required
                  />
                </div>

                <div className="space-y-3">
                  <Label>{t('الحساسية أو الأمراض المزمنة', 'Allergies or Chronic Diseases')} *</Label>
                  <RadioGroup
                    value={formData.has_health_conditions}
                    onValueChange={(value: 'yes' | 'no') => setFormData({ ...formData, has_health_conditions: value })}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <RadioGroupItem value="no" id="health-no" />
                      <Label htmlFor="health-no" className="cursor-pointer">{t('لا', 'No')}</Label>
                    </div>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <RadioGroupItem value="yes" id="health-yes" />
                      <Label htmlFor="health-yes" className="cursor-pointer">{t('نعم، يرجى التحديد', 'Yes, please specify')}</Label>
                    </div>
                  </RadioGroup>
                  {formData.has_health_conditions === 'yes' && (
                    <Textarea
                      value={formData.health_conditions_details}
                      onChange={(e) => setFormData({ ...formData, health_conditions_details: e.target.value })}
                      required
                      rows={3}
                      placeholder={t('اذكر تفاصيل الحساسية أو الأمراض المزمنة...', 'Describe the allergies or chronic diseases...')}
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <Label>{t('ملاحظات إضافية', 'Additional Notes')} ({t('اختياري', 'Optional')})</Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    rows={2}
                    placeholder={language === 'ar' ? 'أي ملاحظات خاصة بالابن...' : 'Any special notes about the child...'}
                  />
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </Button>
                  <Button type="submit" disabled={isSubmitting || updateMutation.isPending}>
                    {(isSubmitting || updateMutation.isPending) && (
                      <Loader2 className="h-4 w-4 animate-spin me-2" />
                    )}
                    {editingChild
                      ? (language === 'ar' ? 'حفظ التغييرات' : 'Save Changes')
                      : (language === 'ar' ? 'تسجيل' : 'Register')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Create Account Dialog for Legacy Students */}
        <Dialog open={isAccountDialogOpen} onOpenChange={setIsAccountDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Key className="h-5 w-5 text-primary" />
                {t('إنشاء حساب طالب', 'Create Student Account')}
              </DialogTitle>
            </DialogHeader>
            {selectedChildForAccount && (
              <form onSubmit={handleCreateAccount} className="space-y-4">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    {t('إنشاء حساب لـ', 'Creating account for')}:
                  </p>
                  <p className="font-medium">{selectedChildForAccount.full_name}</p>
                </div>

                <div className="space-y-2">
                  <Label>{t('البريد الإلكتروني', 'Email')} *</Label>
                  <Input
                    type="email"
                    value={accountFormData.email}
                    onChange={(e) => setAccountFormData({ ...accountFormData, email: e.target.value })}
                    required
                    placeholder={t('أدخل البريد الإلكتروني', 'Enter email')}
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('كلمة المرور', 'Password')} *</Label>
                  <Input
                    type="password"
                    value={accountFormData.password}
                    onChange={(e) => setAccountFormData({ ...accountFormData, password: e.target.value })}
                    required
                    minLength={6}
                    placeholder={t('6 أحرف على الأقل', 'At least 6 characters')}
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('تأكيد كلمة المرور', 'Confirm Password')} *</Label>
                  <Input
                    type="password"
                    value={accountFormData.confirmPassword}
                    onChange={(e) => setAccountFormData({ ...accountFormData, confirmPassword: e.target.value })}
                    required
                    minLength={6}
                    placeholder={t('أعد إدخال كلمة المرور', 'Re-enter password')}
                  />
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <Button type="button" variant="outline" onClick={resetAccountForm}>
                    {t('إلغاء', 'Cancel')}
                  </Button>
                  <Button type="submit" disabled={creatingAccount}>
                    {creatingAccount ? (
                      <Loader2 className="h-4 w-4 animate-spin me-2" />
                    ) : (
                      <Key className="h-4 w-4 me-2" />
                    )}
                    {t('إنشاء الحساب', 'Create Account')}
                  </Button>
                </div>
              </form>
            )}
          </DialogContent>
        </Dialog>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : children?.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 text-center">
              <Baby className="h-16 w-16 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                {language === 'ar' ? 'لا يوجد أبناء مسجلين' : 'No children registered'}
              </h3>
              <p className="text-muted-foreground mb-4">
                {language === 'ar' ? 'قم بتسجيل ابنك الأول للبدء' : 'Register your first child to get started'}
              </p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="h-4 w-4 me-2" />
                {language === 'ar' ? 'تسجيل ابن جديد' : 'Register Child'}
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {children?.map((child) => (
              <Card key={child.id} className="relative">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{child.full_name}</CardTitle>
                        {child.date_of_birth && (
                          <CardDescription>
                            {calculateAge(child.date_of_birth)} {language === 'ar' ? 'سنة' : 'years old'}
                          </CardDescription>
                        )}
                      </div>
                    </div>
                    {child.user_id && (
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <CheckCircle className="h-3 w-3" />
                        {t('لديه حساب', 'Has Account')}
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {child.qid_number && (
                      <div>
                        <span className="text-muted-foreground">{t('رقم الهوية:', 'QID:')}</span>
                        <span className="ms-1 font-medium">{child.qid_number}</span>
                      </div>
                    )}
                    {child.school_grade && (
                      <div>
                        <span className="text-muted-foreground">{t('الصف:', 'Grade:')}</span>
                        <span className="ms-1 font-medium">{child.school_grade}</span>
                      </div>
                    )}
                    {child.gender && (
                      <div>
                        <span className="text-muted-foreground">{t('الجنس:', 'Gender:')}</span>
                        <span className="ms-1 font-medium">
                          {child.gender === 'male' 
                            ? (language === 'ar' ? 'ذكر' : 'Male')
                            : (language === 'ar' ? 'أنثى' : 'Female')}
                        </span>
                      </div>
                    )}
                    {child.nationality && (
                      <div>
                        <span className="text-muted-foreground">{t('الجنسية:', 'Nationality:')}</span>
                        <span className="ms-1 font-medium">{child.nationality}</span>
                      </div>
                    )}
                  </div>
                  
                  {child.has_health_conditions && child.health_conditions_details && (
                    <div className="text-sm p-2 bg-destructive/10 rounded-md">
                      <span className="text-destructive font-medium">{t('حالة صحية:', 'Health Condition:')}</span>
                      <p className="text-muted-foreground mt-1">{child.health_conditions_details}</p>
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(child)} className="flex-1">
                      <Pencil className="h-3 w-3 me-1" />
                      {language === 'ar' ? 'تعديل' : 'Edit'}
                    </Button>
                    {!child.user_id && (
                      <Button size="sm" variant="secondary" onClick={() => handleOpenAccountDialog(child)} className="flex-1">
                        <Key className="h-3 w-3 me-1" />
                        {t('إنشاء حساب', 'Create Account')}
                      </Button>
                    )}
                    <Button 
                      size="sm" 
                      variant="destructive" 
                      onClick={() => {
                        if (confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا الابن؟' : 'Are you sure you want to remove this child?')) {
                          deleteMutation.mutate(child.id);
                        }
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
