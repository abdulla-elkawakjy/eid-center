import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { useUserPermissions } from '@/hooks/useUserPermissions';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';
import {
  Plus,
  Users,
  Calendar,
  ClipboardCheck,
  UserPlus,
  Trash2,
  BookOpen,
  Save,
  Pencil,
  FileText,
  ArrowLeft,
  ArrowRight,
  Package,
  Clock,
  ListChecks,
  FolderOpen,
} from 'lucide-react';
import { ProgramFilesSection } from '@/components/program/ProgramFilesSection';
import { ProgramCoursesSection } from '@/components/program/ProgramCoursesSection';
import { StaffTeamSection } from '@/components/program/StaffTeamSection';
import { StoreRequestsTab } from '@/components/store/StoreRequestsTab';
import { SessionSelector } from '@/components/program/SessionSelector';
import { SessionScheduleTab } from '@/components/program/SessionScheduleTab';
import { AttendanceTab } from '@/components/program/AttendanceTab';
import { SessionFilesTab } from '@/components/program/SessionFilesTab';
import { SessionReportTab } from '@/components/program/SessionReportTab';
import { IndividualEvaluationTab } from '@/components/program/IndividualEvaluationTab';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import type { Database } from '@/integrations/supabase/types';

type CriterionScope = Database['public']['Enums']['criterion_scope'];
type CriterionType = Database['public']['Enums']['criterion_type'];

interface Program {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
}

interface Session {
  id: string;
  session_date: string | null;
  session_number: number | null;
  location: string | null;
  notes: string | null;
  planned_courses: string | null;
}

interface StudentGroup {
  id: string;
  name: string;
  supervisor_id: string | null;
}

interface SessionCoursePortion {
  course_id: string;
  portion_from: string;
  portion_to: string;
}

interface ProgramCourse {
  id: string;
  name: string;
  name_en: string | null;
}

interface AssessmentCriterion {
  id: string;
  name: string;
  name_en: string | null;
  criterion_scope: CriterionScope;
  criterion_type: CriterionType;
  max_score: number;
  weight: number;
}

interface RegisteredStudent {
  id: string;
  student: {
    id: string;
    full_name: string;
    mobile_number: string | null;
    parent_id: string;
  };
}

interface GroupAssignment {
  id: string;
  student_id: string;
  group_id: string;
  student?: {
    full_name: string;
  };
}

interface StudentScore {
  id?: string;
  student_id: string;
  criterion_id: string;
  score: number;
  notes: string | null;
  session_id: string | null;
}

export default function ProgramDetail() {
  const { programId } = useParams<{ programId: string }>();
  const { language } = useLanguage();
  const { user, role } = useAuth();
  const { permissions, isLoading: permissionsLoading } = useUserPermissions(programId);
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  
  // Dialog states
  const [isSessionDialogOpen, setIsSessionDialogOpen] = useState(false);
  const [isEditSessionDialogOpen, setIsEditSessionDialogOpen] = useState(false);
  const [editingSession, setEditingSession] = useState<Session | null>(null);
  const [isGroupDialogOpen, setIsGroupDialogOpen] = useState(false);
  const [isCriteriaDialogOpen, setIsCriteriaDialogOpen] = useState(false);
  const [isEditCriteriaDialogOpen, setIsEditCriteriaDialogOpen] = useState(false);
  const [isAddStudentDialogOpen, setIsAddStudentDialogOpen] = useState(false);
  const [selectedGroupForStudent, setSelectedGroupForStudent] = useState<string>('');
  const [selectedStudentToAdd, setSelectedStudentToAdd] = useState<string>('');
  const [editingCriterion, setEditingCriterion] = useState<AssessmentCriterion | null>(null);
  
  // Session tab state
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [sessionSubTab, setSessionSubTab] = useState('schedule');
  
  // Scoring states
  const [selectedSessionForScoring, setSelectedSessionForScoring] = useState<string>('');
  const [selectedGroupForScoring, setSelectedGroupForScoring] = useState<string>('');
  const [scoringData, setScoringData] = useState<Record<string, { score: number; notes: string }>>({});
  
  // Form states
  const [sessionForm, setSessionForm] = useState({ 
    session_date: '', 
    session_number: '',
    location: '', 
    notes: '',
    coursePortions: [] as SessionCoursePortion[]
  });
  const [editSessionForm, setEditSessionForm] = useState({ 
    session_date: '', 
    session_number: '',
    location: '', 
    notes: '',
    coursePortions: [] as SessionCoursePortion[]
  });
  const [groupForm, setGroupForm] = useState({ name: '', supervisor_id: '' });
  const [criteriaForm, setCriteriaForm] = useState({
    name: '',
    name_en: '',
    criterion_scope: 'individual' as CriterionScope,
    criterion_type: 'daily' as CriterionType,
    max_score: '10',
    weight: '1'
  });
  const [editCriteriaForm, setEditCriteriaForm] = useState({
    name: '',
    name_en: '',
    criterion_scope: 'individual' as CriterionScope,
    criterion_type: 'daily' as CriterionType,
    max_score: '10',
    weight: '1'
  });

  // Fetch program details
  const { data: program } = useQuery({
    queryKey: ['program', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('programs')
        .select('id, name, name_en, description')
        .eq('id', programId)
        .single();
      if (error) throw error;
      return data as Program;
    },
    enabled: !!programId
  });

  // Fetch sessions with new fields
  const { data: sessions } = useQuery({
    queryKey: ['sessions', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sessions')
        .select('id, session_date, session_number, location, notes, planned_courses')
        .eq('program_id', programId)
        .order('session_number', { ascending: true, nullsFirst: false })
        .order('session_date', { ascending: true });
      if (error) throw error;
      return data as Session[];
    },
    enabled: !!programId
  });

  // Fetch student groups
  const { data: groups } = useQuery({
    queryKey: ['student-groups', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('student_groups')
        .select('*')
        .eq('program_id', programId)
        .order('created_at', { ascending: true });
      if (error) throw error;
      return data as StudentGroup[];
    },
    enabled: !!programId
  });

  // Fetch assessment criteria
  const { data: criteria } = useQuery({
    queryKey: ['assessment-criteria', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('assessment_criteria')
        .select('*')
        .eq('program_id', programId)
        .order('created_at', { ascending: true });
      if (error) throw error;
      return data as AssessmentCriterion[];
    },
    enabled: !!programId
  });

  // Fetch registered students with parent info
  const { data: registeredStudents } = useQuery({
    queryKey: ['registered-students-full', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('registration_requests')
        .select(`
          id,
          student:students(id, full_name, mobile_number, parent_id)
        `)
        .eq('program_id', programId)
        .eq('status', 'approved');
      if (error) throw error;
      return data as unknown as RegisteredStudent[];
    },
    enabled: !!programId
  });

  // Fetch parent profiles for phone numbers
  const { data: parentProfiles } = useQuery({
    queryKey: ['parent-profiles', programId],
    queryFn: async () => {
      const parentIds = registeredStudents?.map(r => r.student?.parent_id).filter(Boolean) || [];
      if (parentIds.length === 0) return new Map();
      
      const { data } = await supabase
        .from('profiles')
        .select('user_id, phone')
        .in('user_id', parentIds as string[]);
      
      return new Map(data?.map(p => [p.user_id, p.phone]) || []);
    },
    enabled: !!registeredStudents && registeredStudents.length > 0
  });

  // Fetch group assignments
  const { data: groupAssignments } = useQuery({
    queryKey: ['group-assignments', programId],
    queryFn: async () => {
      if (!groups || groups.length === 0) return [];
      const groupIds = groups.map(g => g.id);
      const { data, error } = await supabase
        .from('student_group_assignments')
        .select('id, student_id, group_id')
        .in('group_id', groupIds);
      if (error) throw error;
      
      const studentIds = data.map(a => a.student_id);
      if (studentIds.length === 0) return data;
      
      const { data: students } = await supabase
        .from('students')
        .select('id, full_name')
        .in('id', studentIds);
      
      const studentsMap = new Map(students?.map(s => [s.id, s]) || []);
      
      return data.map(a => ({
        ...a,
        student: studentsMap.get(a.student_id)
      })) as GroupAssignment[];
    },
    enabled: !!groups && groups.length > 0
  });

  // Fetch staff for supervisor assignment
  const { data: staffList } = useQuery({
    queryKey: ['staff-for-program', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff_assignments')
        .select('staff_id')
        .eq('program_id', programId);
      if (error) throw error;
      
      if (!data || data.length === 0) return [];
      
      const staffIds = data.map(s => s.staff_id);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name')
        .in('user_id', staffIds);
      
      return profiles || [];
    },
    enabled: !!programId
  });

  // Fetch cumulative scores for all students
  const { data: allStudentScores } = useQuery({
    queryKey: ['all-student-scores', programId],
    queryFn: async () => {
      const studentIds = registeredStudents?.map(r => r.student?.id).filter(Boolean) || [];
      if (studentIds.length === 0) return [];
      
      const individualCriteria = criteria?.filter(c => c.criterion_scope === 'individual') || [];
      if (individualCriteria.length === 0) return [];
      
      const criteriaIds = individualCriteria.map(c => c.id);
      
      const { data, error } = await supabase
        .from('student_scores')
        .select('*')
        .in('student_id', studentIds as string[])
        .in('criterion_id', criteriaIds);
      if (error) throw error;
      return data as StudentScore[];
    },
    enabled: !!registeredStudents && registeredStudents.length > 0 && !!criteria && criteria.length > 0
  });

  // Fetch program courses for session dialogs
  const { data: programCourses } = useQuery({
    queryKey: ['program-courses-for-session', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('program_courses')
        .select('id, name, name_en')
        .eq('program_id', programId)
        .order('order_index', { ascending: true });
      if (error) throw error;
      return data as ProgramCourse[];
    },
    enabled: !!programId
  });

  // Helper functions for course portion management
  const toggleCourseInSession = (courseId: string, isSelected: boolean, formType: 'add' | 'edit') => {
    const setForm = formType === 'add' ? setSessionForm : setEditSessionForm;
    setForm(prev => {
      if (isSelected) {
        return {
          ...prev,
          coursePortions: [...prev.coursePortions, { course_id: courseId, portion_from: '', portion_to: '' }]
        };
      } else {
        return {
          ...prev,
          coursePortions: prev.coursePortions.filter(p => p.course_id !== courseId)
        };
      }
    });
  };

  const updatePortionInSession = (courseId: string, field: 'portion_from' | 'portion_to', value: string, formType: 'add' | 'edit') => {
    const setForm = formType === 'add' ? setSessionForm : setEditSessionForm;
    setForm(prev => ({
      ...prev,
      coursePortions: prev.coursePortions.map(p =>
        p.course_id === courseId ? { ...p, [field]: value } : p
      )
    }));
  };

  // Session mutations
  const createSessionMutation = useMutation({
    mutationFn: async (data: typeof sessionForm) => {
      // 1. Create session
      const { data: newSession, error } = await supabase.from('sessions').insert({
        program_id: programId,
        session_date: data.session_date || null,
        session_number: data.session_number ? parseInt(data.session_number) : null,
        location: data.location || null,
        notes: data.notes || null
      }).select('id').single();
      if (error) throw error;

      // 2. Insert course portions if any selected
      if (data.coursePortions.length > 0) {
        const portions = data.coursePortions
          .filter(p => p.portion_from || p.portion_to)
          .map(p => ({
            session_id: newSession.id,
            course_id: p.course_id,
            portion_from: p.portion_from || null,
            portion_to: p.portion_to || null,
            is_completed: false
          }));
        
        if (portions.length > 0) {
          const { error: portionError } = await supabase
            .from('session_course_portions')
            .insert(portions);
          if (portionError) throw portionError;
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sessions', programId] });
      queryClient.invalidateQueries({ queryKey: ['session-course-portions'] });
      toast.success(language === 'ar' ? 'تم إضافة اللقاء' : 'Session added');
      setIsSessionDialogOpen(false);
      setSessionForm({ session_date: '', session_number: '', location: '', notes: '', coursePortions: [] });
    }
  });

  const updateSessionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof editSessionForm }) => {
      // 1. Update session
      const { error } = await supabase.from('sessions').update({
        session_date: data.session_date || null,
        session_number: data.session_number ? parseInt(data.session_number) : null,
        location: data.location || null,
        notes: data.notes || null
      }).eq('id', id);
      if (error) throw error;

      // 2. Handle course portions - delete existing and insert new
      await supabase.from('session_course_portions').delete().eq('session_id', id);
      
      if (data.coursePortions.length > 0) {
        const portions = data.coursePortions
          .filter(p => p.portion_from || p.portion_to)
          .map(p => ({
            session_id: id,
            course_id: p.course_id,
            portion_from: p.portion_from || null,
            portion_to: p.portion_to || null,
            is_completed: false
          }));
        
        if (portions.length > 0) {
          const { error: portionError } = await supabase
            .from('session_course_portions')
            .insert(portions);
          if (portionError) throw portionError;
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sessions', programId] });
      queryClient.invalidateQueries({ queryKey: ['session-course-portions'] });
      toast.success(language === 'ar' ? 'تم تحديث اللقاء' : 'Session updated');
      setIsEditSessionDialogOpen(false);
      setEditingSession(null);
    }
  });

  const deleteSessionMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('sessions').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sessions', programId] });
      toast.success(language === 'ar' ? 'تم حذف اللقاء' : 'Session deleted');
    }
  });

  // Group mutations
  const createGroupMutation = useMutation({
    mutationFn: async (data: typeof groupForm) => {
      const { error } = await supabase.from('student_groups').insert({
        program_id: programId,
        name: data.name,
        supervisor_id: data.supervisor_id || null
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['student-groups', programId] });
      toast.success(language === 'ar' ? 'تم إنشاء المجموعة' : 'Group created');
      setIsGroupDialogOpen(false);
      setGroupForm({ name: '', supervisor_id: '' });
    }
  });

  const deleteGroupMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('student_groups').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['student-groups', programId] });
      toast.success(language === 'ar' ? 'تم حذف المجموعة' : 'Group deleted');
    }
  });

  // Criteria mutations
  const createCriteriaMutation = useMutation({
    mutationFn: async (data: typeof criteriaForm) => {
      const { error } = await supabase.from('assessment_criteria').insert({
        program_id: programId,
        name: data.name,
        name_en: data.name_en || null,
        criterion_scope: data.criterion_scope,
        criterion_type: data.criterion_type,
        max_score: parseInt(data.max_score),
        weight: parseFloat(data.weight)
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assessment-criteria', programId] });
      toast.success(language === 'ar' ? 'تم إضافة المعيار' : 'Criterion added');
      setIsCriteriaDialogOpen(false);
      setCriteriaForm({
        name: '',
        name_en: '',
        criterion_scope: 'individual',
        criterion_type: 'daily',
        max_score: '10',
        weight: '1'
      });
    }
  });

  const updateCriteriaMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof editCriteriaForm }) => {
      const { error } = await supabase.from('assessment_criteria').update({
        name: data.name,
        name_en: data.name_en || null,
        criterion_scope: data.criterion_scope,
        criterion_type: data.criterion_type,
        max_score: parseInt(data.max_score),
        weight: parseFloat(data.weight)
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assessment-criteria', programId] });
      toast.success(language === 'ar' ? 'تم تحديث المعيار' : 'Criterion updated');
      setIsEditCriteriaDialogOpen(false);
      setEditingCriterion(null);
    }
  });

  const deleteCriteriaMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('assessment_criteria').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assessment-criteria', programId] });
      toast.success(language === 'ar' ? 'تم حذف المعيار' : 'Criterion deleted');
    }
  });

  // Add student to group mutation
  const addStudentToGroupMutation = useMutation({
    mutationFn: async ({ studentId, groupId }: { studentId: string; groupId: string }) => {
      const { error } = await supabase.from('student_group_assignments').insert({
        student_id: studentId,
        group_id: groupId
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group-assignments', programId] });
      toast.success(language === 'ar' ? 'تم إضافة الطالب للمجموعة' : 'Student added to group');
      setIsAddStudentDialogOpen(false);
      setSelectedStudentToAdd('');
      setSelectedGroupForStudent('');
    }
  });

  const removeStudentFromGroupMutation = useMutation({
    mutationFn: async (assignmentId: string) => {
      const { error } = await supabase.from('student_group_assignments').delete().eq('id', assignmentId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['group-assignments', programId] });
      toast.success(language === 'ar' ? 'تم إزالة الطالب من المجموعة' : 'Student removed from group');
    }
  });

  // Handlers
  const handleEditCriterion = (criterion: AssessmentCriterion) => {
    setEditingCriterion(criterion);
    setEditCriteriaForm({
      name: criterion.name,
      name_en: criterion.name_en || '',
      criterion_scope: criterion.criterion_scope,
      criterion_type: criterion.criterion_type,
      max_score: criterion.max_score.toString(),
      weight: criterion.weight.toString()
    });
    setIsEditCriteriaDialogOpen(true);
  };

  const handleEditSession = async (session: Session) => {
    setEditingSession(session);
    
    // Fetch existing course portions for this session
    const { data: existingPortions } = await supabase
      .from('session_course_portions')
      .select('course_id, portion_from, portion_to')
      .eq('session_id', session.id);
    
    setEditSessionForm({
      session_date: session.session_date || '',
      session_number: session.session_number?.toString() || '',
      location: session.location || '',
      notes: session.notes || '',
      coursePortions: (existingPortions || []).map(p => ({
        course_id: p.course_id,
        portion_from: p.portion_from || '',
        portion_to: p.portion_to || ''
      }))
    });
    setIsEditSessionDialogOpen(true);
  };

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  // Get unassigned students
  const unassignedStudents = registeredStudents?.filter(
    reg => !groupAssignments?.some(ga => ga.student_id === reg.student?.id)
  ) || [];

  // Calculate cumulative score for a student
  const getStudentCumulativeScore = (studentId: string) => {
    const studentScores = allStudentScores?.filter(s => s.student_id === studentId) || [];
    if (studentScores.length === 0) return 0;
    const totalScore = studentScores.reduce((sum, s) => sum + s.score, 0);
    return Math.round(totalScore * 10) / 10;
  };

  // Get student group name
  const getStudentGroupName = (studentId: string) => {
    const assignment = groupAssignments?.find(a => a.student_id === studentId);
    if (!assignment) return '-';
    const group = groups?.find(g => g.id === assignment.group_id);
    return group?.name || '-';
  };

  const isAdmin = permissions.isAdmin;
  const canEditSessions = permissions.isAdmin || permissions.canEditSessionInfo;
  const canManageCriteria = permissions.isAdmin || permissions.canManageCriteria;
  const canSubmitStoreRequest = permissions.isAdmin || permissions.canSubmitStoreRequest;
  
  const BackArrow = language === 'ar' ? ArrowRight : ArrowLeft;

  const selectedSession = sessions?.find(s => s.id === selectedSessionId);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Back button */}
        {isAdmin && (
          <div className="flex items-center gap-4 flex-wrap">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate(-1)}
              className="gap-2 rtl:flex-row-reverse"
            >
              <BackArrow className="h-4 w-4" />
              {language === 'ar' ? 'البرامج' : 'Programs'}
            </Button>
          </div>
        )}

        {/* Header */}
        <div className="flex items-center gap-3 rtl:flex-row-reverse">
          <BookOpen className="h-8 w-8 text-primary" />
          <div className="text-start">
            <h1 className="text-3xl font-bold text-foreground">
              {language === 'ar' ? program?.name : program?.name_en || program?.name}
            </h1>
            <p className="text-muted-foreground">{program?.description}</p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                {language === 'ar' ? 'اللقاءات' : 'Sessions'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-start">{sessions?.length || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                {language === 'ar' ? 'المجموعات' : 'Groups'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-start">{groups?.length || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                {language === 'ar' ? 'الطلاب المسجلين' : 'Registered Students'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-start">{registeredStudents?.length || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                {language === 'ar' ? 'معايير التقييم' : 'Assessment Criteria'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-start">{criteria?.length || 0}</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="plan" className="w-full">
          <TabsList className="flex-wrap h-auto gap-1 p-1.5 bg-muted/70 border rounded-lg">
            <TabsTrigger value="plan" className="flex items-center gap-2 px-4 py-2 text-sm font-medium rtl:flex-row-reverse">
              <ListChecks className="h-4 w-4" />
              {language === 'ar' ? 'خطة البرنامج' : 'Program Plan'}
            </TabsTrigger>
            <TabsTrigger value="sessions" className="flex items-center gap-2 px-4 py-2 text-sm font-medium rtl:flex-row-reverse">
              <Calendar className="h-4 w-4" />
              {language === 'ar' ? 'اللقاءات' : 'Sessions'}
            </TabsTrigger>
            <TabsTrigger value="students" className="flex items-center gap-2 px-4 py-2 text-sm font-medium rtl:flex-row-reverse">
              <UserPlus className="h-4 w-4" />
              {language === 'ar' ? 'الطلاب' : 'Students'}
            </TabsTrigger>
            <TabsTrigger value="groups" className="flex items-center gap-2 px-4 py-2 text-sm font-medium rtl:flex-row-reverse">
              <Users className="h-4 w-4" />
              {language === 'ar' ? 'المجموعات' : 'Groups'}
            </TabsTrigger>
            {(isAdmin || permissions.isAssigned) && (
              <TabsTrigger value="supervisors" className="flex items-center gap-2 px-4 py-2 text-sm font-medium rtl:flex-row-reverse">
                <Users className="h-4 w-4" />
                {language === 'ar' ? 'المشرفون' : 'Supervisors'}
              </TabsTrigger>
            )}
            <TabsTrigger value="criteria" className="flex items-center gap-2 px-4 py-2 text-sm font-medium rtl:flex-row-reverse">
              <ClipboardCheck className="h-4 w-4" />
              {language === 'ar' ? 'معايير التقييم' : 'Criteria'}
            </TabsTrigger>
          </TabsList>

          {/* Tab 1: Program Plan */}
          <TabsContent value="plan" className="space-y-6">
            {/* Sessions List */}
            <div className="space-y-4">
              <div className="flex justify-between items-center rtl:flex-row-reverse">
                <h3 className="text-lg font-semibold">{language === 'ar' ? 'اللقاءات المخططة' : 'Planned Sessions'}</h3>
                {canEditSessions && (
                  <Dialog open={isSessionDialogOpen} onOpenChange={setIsSessionDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 me-2" />
                        {language === 'ar' ? 'إضافة لقاء' : 'Add Session'}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>{language === 'ar' ? 'إضافة لقاء جديد' : 'Add New Session'}</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={(e) => { e.preventDefault(); createSessionMutation.mutate(sessionForm); }} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>{language === 'ar' ? 'رقم اللقاء' : 'Session Number'}</Label>
                            <Input
                              type="number"
                              value={sessionForm.session_number}
                              onChange={(e) => setSessionForm({ ...sessionForm, session_number: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>{language === 'ar' ? 'التاريخ' : 'Date'}</Label>
                            <Input
                              type="date"
                              value={sessionForm.session_date}
                              onChange={(e) => setSessionForm({ ...sessionForm, session_date: e.target.value })}
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'الموقع' : 'Location'}</Label>
                          <Input
                            value={sessionForm.location}
                            onChange={(e) => setSessionForm({ ...sessionForm, location: e.target.value })}
                          />
                        </div>
                        {/* Course Portions Section */}
                        {programCourses && programCourses.length > 0 && (
                          <div className="space-y-2">
                            <Label className="flex items-center gap-2 rtl:flex-row-reverse">
                              <BookOpen className="h-4 w-4" />
                              {language === 'ar' ? 'حصص المقررات' : 'Course Portions'}
                            </Label>
                            <div className="space-y-2 max-h-48 overflow-y-auto border rounded-md p-2">
                              {programCourses.map(course => {
                                const portion = sessionForm.coursePortions.find(p => p.course_id === course.id);
                                const isSelected = !!portion;
                                return (
                                  <div key={course.id} className={`p-2 rounded border ${isSelected ? 'border-primary bg-primary/5' : 'border-border'}`}>
                                    <div className="flex items-center gap-2 rtl:flex-row-reverse">
                                      <Checkbox
                                        checked={isSelected}
                                        onCheckedChange={(checked) => toggleCourseInSession(course.id, !!checked, 'add')}
                                      />
                                      <span className="font-medium text-sm">
                                        {language === 'ar' ? course.name : course.name_en || course.name}
                                      </span>
                                    </div>
                                    {isSelected && (
                                      <div className="grid grid-cols-2 gap-2 mt-2 ms-6">
                                        <Input
                                          placeholder={language === 'ar' ? 'من' : 'From'}
                                          value={portion?.portion_from || ''}
                                          onChange={(e) => updatePortionInSession(course.id, 'portion_from', e.target.value, 'add')}
                                          className="h-8 text-sm"
                                        />
                                        <Input
                                          placeholder={language === 'ar' ? 'إلى' : 'To'}
                                          value={portion?.portion_to || ''}
                                          onChange={(e) => updatePortionInSession(course.id, 'portion_to', e.target.value, 'add')}
                                          className="h-8 text-sm"
                                        />
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'ملاحظات' : 'Notes'}</Label>
                          <Textarea
                            value={sessionForm.notes}
                            onChange={(e) => setSessionForm({ ...sessionForm, notes: e.target.value })}
                            rows={2}
                          />
                        </div>
                        <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                          <Button type="button" variant="outline" onClick={() => setIsSessionDialogOpen(false)}>
                            {language === 'ar' ? 'إلغاء' : 'Cancel'}
                          </Button>
                          <Button type="submit">{language === 'ar' ? 'إضافة' : 'Add'}</Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>

              {sessions?.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="py-8 text-center text-muted-foreground">
                    {language === 'ar' ? 'لا توجد لقاءات' : 'No sessions yet'}
                  </CardContent>
                </Card>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[80px]">#</TableHead>
                      <TableHead>{language === 'ar' ? 'التاريخ' : 'Date'}</TableHead>
                      <TableHead>{language === 'ar' ? 'الموقع' : 'Location'}</TableHead>
                      {canEditSessions && <TableHead className="w-[100px]">{language === 'ar' ? 'إجراءات' : 'Actions'}</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sessions?.map((session) => (
                      <TableRow key={session.id}>
                        <TableCell className="font-medium">{session.session_number || '-'}</TableCell>
                        <TableCell>{formatDate(session.session_date)}</TableCell>
                        <TableCell>{session.location || '-'}</TableCell>
                        {canEditSessions && (
                          <TableCell>
                            <div className="flex gap-1 rtl:flex-row-reverse">
                              <Button size="sm" variant="ghost" onClick={() => handleEditSession(session)}>
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteSessionMutation.mutate(session.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>

            {/* Program Courses Section */}
            {programId && <ProgramCoursesSection programId={programId} isAdmin={isAdmin} />}

            {/* Program Files */}
            {programId && <ProgramFilesSection programId={programId} />}

            {/* Edit Session Dialog */}
            <Dialog open={isEditSessionDialogOpen} onOpenChange={setIsEditSessionDialogOpen}>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>{language === 'ar' ? 'تعديل اللقاء' : 'Edit Session'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={(e) => { 
                  e.preventDefault(); 
                  if (editingSession) {
                    updateSessionMutation.mutate({ id: editingSession.id, data: editSessionForm }); 
                  }
                }} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'رقم اللقاء' : 'Session Number'}</Label>
                      <Input
                        type="number"
                        value={editSessionForm.session_number}
                        onChange={(e) => setEditSessionForm({ ...editSessionForm, session_number: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'التاريخ' : 'Date'}</Label>
                      <Input
                        type="date"
                        value={editSessionForm.session_date}
                        onChange={(e) => setEditSessionForm({ ...editSessionForm, session_date: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'الموقع' : 'Location'}</Label>
                    <Input
                      value={editSessionForm.location}
                      onChange={(e) => setEditSessionForm({ ...editSessionForm, location: e.target.value })}
                    />
                  </div>
                  {/* Course Portions Section */}
                  {programCourses && programCourses.length > 0 && (
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2 rtl:flex-row-reverse">
                        <BookOpen className="h-4 w-4" />
                        {language === 'ar' ? 'حصص المقررات' : 'Course Portions'}
                      </Label>
                      <div className="space-y-2 max-h-48 overflow-y-auto border rounded-md p-2">
                        {programCourses.map(course => {
                          const portion = editSessionForm.coursePortions.find(p => p.course_id === course.id);
                          const isSelected = !!portion;
                          return (
                            <div key={course.id} className={`p-2 rounded border ${isSelected ? 'border-primary bg-primary/5' : 'border-border'}`}>
                              <div className="flex items-center gap-2 rtl:flex-row-reverse">
                                <Checkbox
                                  checked={isSelected}
                                  onCheckedChange={(checked) => toggleCourseInSession(course.id, !!checked, 'edit')}
                                />
                                <span className="font-medium text-sm">
                                  {language === 'ar' ? course.name : course.name_en || course.name}
                                </span>
                              </div>
                              {isSelected && (
                                <div className="grid grid-cols-2 gap-2 mt-2 ms-6">
                                  <Input
                                    placeholder={language === 'ar' ? 'من' : 'From'}
                                    value={portion?.portion_from || ''}
                                    onChange={(e) => updatePortionInSession(course.id, 'portion_from', e.target.value, 'edit')}
                                    className="h-8 text-sm"
                                  />
                                  <Input
                                    placeholder={language === 'ar' ? 'إلى' : 'To'}
                                    value={portion?.portion_to || ''}
                                    onChange={(e) => updatePortionInSession(course.id, 'portion_to', e.target.value, 'edit')}
                                    className="h-8 text-sm"
                                  />
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label>{language === 'ar' ? 'ملاحظات' : 'Notes'}</Label>
                    <Textarea
                      value={editSessionForm.notes}
                      onChange={(e) => setEditSessionForm({ ...editSessionForm, notes: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                    <Button type="button" variant="outline" onClick={() => setIsEditSessionDialogOpen(false)}>
                      {language === 'ar' ? 'إلغاء' : 'Cancel'}
                    </Button>
                    <Button type="submit">{language === 'ar' ? 'حفظ' : 'Save'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </TabsContent>

          {/* Tab 2: Sessions (with sub-tabs) */}
          <TabsContent value="sessions" className="space-y-6">
            {/* Session Selector */}
            <div className="flex items-center gap-4 flex-wrap rtl:flex-row-reverse">
              <Label className="font-medium">{language === 'ar' ? 'اختر لقاء:' : 'Select Session:'}</Label>
              <SessionSelector
                sessions={sessions || []}
                selectedSessionId={selectedSessionId}
                onSessionChange={setSelectedSessionId}
              />
            </div>

            {selectedSessionId ? (
              <Tabs value={sessionSubTab} onValueChange={setSessionSubTab}>
                <TabsList className="flex-wrap h-auto gap-4 p-0 bg-transparent border-b border-border rounded-none">
                  <TabsTrigger value="schedule" className="flex items-center gap-2 px-2 py-2 text-sm rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none rtl:flex-row-reverse">
                    <Clock className="h-4 w-4" />
                    {language === 'ar' ? 'الجدول' : 'Schedule'}
                  </TabsTrigger>
                  {canSubmitStoreRequest && (
                    <TabsTrigger value="store-requests" className="flex items-center gap-2 px-2 py-2 text-sm rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none rtl:flex-row-reverse">
                      <Package className="h-4 w-4" />
                      {language === 'ar' ? 'طلبات المخزن' : 'Store Requests'}
                    </TabsTrigger>
                  )}
                  <TabsTrigger value="attendance" className="flex items-center gap-2 px-2 py-2 text-sm rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none rtl:flex-row-reverse">
                    <Users className="h-4 w-4" />
                    {language === 'ar' ? 'الحضور' : 'Attendance'}
                  </TabsTrigger>
                  <TabsTrigger value="individual-eval" className="flex items-center gap-2 px-2 py-2 text-sm rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none rtl:flex-row-reverse">
                    <ClipboardCheck className="h-4 w-4" />
                    {language === 'ar' ? 'التقييم الفردي' : 'Individual Eval'}
                  </TabsTrigger>
                  <TabsTrigger value="group-eval" className="flex items-center gap-2 px-2 py-2 text-sm rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none rtl:flex-row-reverse">
                    <ClipboardCheck className="h-4 w-4" />
                    {language === 'ar' ? 'التقييم الجماعي' : 'Group Eval'}
                  </TabsTrigger>
                  <TabsTrigger value="files" className="flex items-center gap-2 px-2 py-2 text-sm rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none rtl:flex-row-reverse">
                    <FolderOpen className="h-4 w-4" />
                    {language === 'ar' ? 'الملفات' : 'Files'}
                  </TabsTrigger>
                  <TabsTrigger value="report" className="flex items-center gap-2 px-2 py-2 text-sm rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none rtl:flex-row-reverse">
                    <FileText className="h-4 w-4" />
                    {language === 'ar' ? 'التقرير' : 'Report'}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="schedule">
                  {programId && <SessionScheduleTab sessionId={selectedSessionId} programId={programId} permissions={permissions} />}
                </TabsContent>

                <TabsContent value="store-requests">
                  {programId && <StoreRequestsTab programId={programId} sessions={sessions || []} isLeader={permissions.isAdmin || canSubmitStoreRequest} />}
                </TabsContent>

                <TabsContent value="attendance">
                  {programId && <AttendanceTab sessionId={selectedSessionId} programId={programId} permissions={permissions} />}
                </TabsContent>

                <TabsContent value="individual-eval">
                  {programId && <IndividualEvaluationTab sessionId={selectedSessionId} programId={programId} permissions={permissions} />}
                </TabsContent>

                <TabsContent value="group-eval">
                  <Card>
                    <CardContent className="py-8 text-center text-muted-foreground">
                      {language === 'ar' ? 'سيتم إضافة التقييم الجماعي قريباً' : 'Group evaluation coming soon'}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="files">
                  <SessionFilesTab sessionId={selectedSessionId} permissions={permissions} />
                </TabsContent>

                <TabsContent value="report">
                  {programId && <SessionReportTab sessionId={selectedSessionId} programId={programId} permissions={permissions} />}
                </TabsContent>
              </Tabs>
            ) : (
              <Card className="border-dashed">
                <CardContent className="py-12 text-center text-muted-foreground">
                  {language === 'ar' ? 'اختر لقاء لعرض التفاصيل' : 'Select a session to view details'}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tab 3: Students */}
          <TabsContent value="students" className="space-y-4">
            {registeredStudents?.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="py-8 text-center text-muted-foreground">
                  {language === 'ar' ? 'لا يوجد طلاب مسجلين' : 'No registered students'}
                </CardContent>
              </Card>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{language === 'ar' ? 'الاسم' : 'Name'}</TableHead>
                    <TableHead>{language === 'ar' ? 'رقم الجوال' : 'Mobile'}</TableHead>
                    <TableHead>{language === 'ar' ? 'جوال ولي الأمر' : "Parent's Mobile"}</TableHead>
                    <TableHead>{language === 'ar' ? 'المجموعة' : 'Group'}</TableHead>
                    <TableHead>{language === 'ar' ? 'الدرجة' : 'Score'}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {registeredStudents?.map((reg) => (
                    <TableRow key={reg.id}>
                      <TableCell className="font-medium">{reg.student?.full_name}</TableCell>
                      <TableCell>{reg.student?.mobile_number || '-'}</TableCell>
                      <TableCell>{parentProfiles?.get(reg.student?.parent_id) || '-'}</TableCell>
                      <TableCell>
                        {reg.student?.id ? (
                          <Badge variant="outline">{getStudentGroupName(reg.student.id)}</Badge>
                        ) : '-'}
                      </TableCell>
                      <TableCell>
                        {reg.student?.id ? getStudentCumulativeScore(reg.student.id) : 0}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </TabsContent>

          {/* Tab 4: Groups */}
          <TabsContent value="groups" className="space-y-4">
            {isAdmin && (
              <div className="flex justify-between items-center flex-wrap gap-4">
                <div className="flex gap-2 rtl:flex-row-reverse">
                  {unassignedStudents.length > 0 && (
                    <Dialog open={isAddStudentDialogOpen} onOpenChange={setIsAddStudentDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline">
                          <UserPlus className="h-4 w-4 me-2" />
                          {language === 'ar' ? 'إضافة طالب لمجموعة' : 'Add Student to Group'}
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>{language === 'ar' ? 'إضافة طالب لمجموعة' : 'Add Student to Group'}</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={(e) => { 
                          e.preventDefault(); 
                          addStudentToGroupMutation.mutate({ studentId: selectedStudentToAdd, groupId: selectedGroupForStudent }); 
                        }} className="space-y-4">
                          <div className="space-y-2">
                            <Label>{language === 'ar' ? 'الطالب' : 'Student'}</Label>
                            <Select value={selectedStudentToAdd} onValueChange={setSelectedStudentToAdd}>
                              <SelectTrigger>
                                <SelectValue placeholder={language === 'ar' ? 'اختر الطالب' : 'Select Student'} />
                              </SelectTrigger>
                              <SelectContent>
                                {unassignedStudents.map((reg) => (
                                  <SelectItem key={reg.student?.id} value={reg.student?.id || ''}>
                                    {reg.student?.full_name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label>{language === 'ar' ? 'المجموعة' : 'Group'}</Label>
                            <Select value={selectedGroupForStudent} onValueChange={setSelectedGroupForStudent}>
                              <SelectTrigger>
                                <SelectValue placeholder={language === 'ar' ? 'اختر المجموعة' : 'Select Group'} />
                              </SelectTrigger>
                              <SelectContent>
                                {groups?.map((group) => (
                                  <SelectItem key={group.id} value={group.id}>{group.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                            <Button type="button" variant="outline" onClick={() => setIsAddStudentDialogOpen(false)}>
                              {language === 'ar' ? 'إلغاء' : 'Cancel'}
                            </Button>
                            <Button type="submit" disabled={!selectedStudentToAdd || !selectedGroupForStudent}>
                              {language === 'ar' ? 'إضافة' : 'Add'}
                            </Button>
                          </div>
                        </form>
                      </DialogContent>
                    </Dialog>
                  )}
                  <Dialog open={isGroupDialogOpen} onOpenChange={setIsGroupDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 me-2" />
                        {language === 'ar' ? 'مجموعة جديدة' : 'New Group'}
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{language === 'ar' ? 'إنشاء مجموعة جديدة' : 'Create New Group'}</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={(e) => { e.preventDefault(); createGroupMutation.mutate(groupForm); }} className="space-y-4">
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'اسم المجموعة' : 'Group Name'}</Label>
                          <Input
                            value={groupForm.name}
                            onChange={(e) => setGroupForm({ ...groupForm, name: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'المشرف' : 'Supervisor'}</Label>
                          <Select value={groupForm.supervisor_id} onValueChange={(v) => setGroupForm({ ...groupForm, supervisor_id: v })}>
                            <SelectTrigger>
                              <SelectValue placeholder={language === 'ar' ? 'اختر المشرف' : 'Select Supervisor'} />
                            </SelectTrigger>
                            <SelectContent>
                              {staffList?.map((staff) => (
                                <SelectItem key={staff.user_id} value={staff.user_id}>
                                  {staff.full_name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                          <Button type="button" variant="outline" onClick={() => setIsGroupDialogOpen(false)}>
                            {language === 'ar' ? 'إلغاء' : 'Cancel'}
                          </Button>
                          <Button type="submit">{language === 'ar' ? 'إنشاء' : 'Create'}</Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            )}

            {groups?.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="py-8 text-center text-muted-foreground">
                  {language === 'ar' ? 'لا توجد مجموعات' : 'No groups yet'}
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {groups?.map((group) => {
                  const studentsInGroup = groupAssignments?.filter(a => a.group_id === group.id) || [];
                  return (
                    <Card key={group.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start rtl:flex-row-reverse">
                          <CardTitle className="text-lg text-start">{group.name}</CardTitle>
                          {isAdmin && (
                            <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteGroupMutation.mutate(group.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                        <CardDescription>
                          {studentsInGroup.length} {language === 'ar' ? 'طالب' : 'students'}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {studentsInGroup.length > 0 && (
                          <div className="space-y-2">
                            {studentsInGroup.map((assignment) => (
                              <div key={assignment.id} className="flex items-center justify-between text-sm rtl:flex-row-reverse">
                                <span className="text-start">{(assignment as GroupAssignment).student?.full_name}</span>
                                {isAdmin && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-6 w-6 p-0 text-destructive"
                                    onClick={() => removeStudentFromGroupMutation.mutate(assignment.id)}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Tab 5: Supervisors (visible to all assigned, editable by admin/leader) */}
          {(isAdmin || permissions.isAssigned) && (
            <TabsContent value="supervisors">
              {programId && <StaffTeamSection programId={programId} canEdit={isAdmin || permissions.isProgramLeader} />}
            </TabsContent>
          )}

          {/* Tab 6: Criteria */}
          <TabsContent value="criteria" className="space-y-4">
            {canManageCriteria && (
              <div className="flex justify-end">
                <Dialog open={isCriteriaDialogOpen} onOpenChange={setIsCriteriaDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="h-4 w-4 me-2" />
                      {language === 'ar' ? 'إضافة معيار' : 'Add Criterion'}
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{language === 'ar' ? 'إضافة معيار تقييم' : 'Add Assessment Criterion'}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={(e) => { e.preventDefault(); createCriteriaMutation.mutate(criteriaForm); }} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                          <Input
                            value={criteriaForm.name}
                            onChange={(e) => setCriteriaForm({ ...criteriaForm, name: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                          <Input
                            value={criteriaForm.name_en}
                            onChange={(e) => setCriteriaForm({ ...criteriaForm, name_en: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'النطاق' : 'Scope'}</Label>
                          <Select value={criteriaForm.criterion_scope} onValueChange={(v: CriterionScope) => setCriteriaForm({ ...criteriaForm, criterion_scope: v })}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="individual">{language === 'ar' ? 'فردي' : 'Individual'}</SelectItem>
                              <SelectItem value="group">{language === 'ar' ? 'جماعي' : 'Group'}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'النوع' : 'Type'}</Label>
                          <Select value={criteriaForm.criterion_type} onValueChange={(v: CriterionType) => setCriteriaForm({ ...criteriaForm, criterion_type: v })}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="daily">{language === 'ar' ? 'للقاء' : 'Per Session'}</SelectItem>
                              <SelectItem value="overall">{language === 'ar' ? 'نهائي' : 'Overall'}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'الدرجة القصوى' : 'Max Score'}</Label>
                          <Input
                            type="number"
                            value={criteriaForm.max_score}
                            onChange={(e) => setCriteriaForm({ ...criteriaForm, max_score: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>{language === 'ar' ? 'الوزن' : 'Weight'}</Label>
                          <Input
                            type="number"
                            step="0.1"
                            value={criteriaForm.weight}
                            onChange={(e) => setCriteriaForm({ ...criteriaForm, weight: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                        <Button type="button" variant="outline" onClick={() => setIsCriteriaDialogOpen(false)}>
                          {language === 'ar' ? 'إلغاء' : 'Cancel'}
                        </Button>
                        <Button type="submit">{language === 'ar' ? 'إضافة' : 'Add'}</Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            )}

            {criteria?.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="py-8 text-center text-muted-foreground">
                  {language === 'ar' ? 'لا توجد معايير تقييم' : 'No assessment criteria yet'}
                </CardContent>
              </Card>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{language === 'ar' ? 'المعيار' : 'Criterion'}</TableHead>
                    <TableHead>{language === 'ar' ? 'النطاق' : 'Scope'}</TableHead>
                    <TableHead>{language === 'ar' ? 'النوع' : 'Type'}</TableHead>
                    <TableHead>{language === 'ar' ? 'الدرجة القصوى' : 'Max Score'}</TableHead>
                    <TableHead>{language === 'ar' ? 'الوزن' : 'Weight'}</TableHead>
                    {canManageCriteria && <TableHead>{language === 'ar' ? 'الإجراءات' : 'Actions'}</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {criteria?.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium">
                        {language === 'ar' ? c.name : c.name_en || c.name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {c.criterion_scope === 'individual'
                            ? (language === 'ar' ? 'فردي' : 'Individual')
                            : (language === 'ar' ? 'جماعي' : 'Group')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={c.criterion_type === 'daily' ? 'secondary' : 'default'}>
                          {c.criterion_type === 'daily'
                            ? (language === 'ar' ? 'للقاء' : 'Per Session')
                            : (language === 'ar' ? 'نهائي' : 'Overall')}
                        </Badge>
                      </TableCell>
                      <TableCell>{c.max_score}</TableCell>
                      <TableCell>{c.weight}</TableCell>
                      {canManageCriteria && (
                        <TableCell>
                          <div className="flex gap-1 rtl:flex-row-reverse">
                            <Button size="sm" variant="ghost" onClick={() => handleEditCriterion(c)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost" className="text-destructive" onClick={() => deleteCriteriaMutation.mutate(c.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}

            {/* Edit Criterion Dialog */}
            <Dialog open={isEditCriteriaDialogOpen} onOpenChange={setIsEditCriteriaDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{language === 'ar' ? 'تعديل معيار التقييم' : 'Edit Assessment Criterion'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={(e) => { 
                  e.preventDefault(); 
                  if (editingCriterion) {
                    updateCriteriaMutation.mutate({ id: editingCriterion.id, data: editCriteriaForm }); 
                  }
                }} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                      <Input
                        value={editCriteriaForm.name}
                        onChange={(e) => setEditCriteriaForm({ ...editCriteriaForm, name: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                      <Input
                        value={editCriteriaForm.name_en}
                        onChange={(e) => setEditCriteriaForm({ ...editCriteriaForm, name_en: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'النطاق' : 'Scope'}</Label>
                      <Select value={editCriteriaForm.criterion_scope} onValueChange={(v: CriterionScope) => setEditCriteriaForm({ ...editCriteriaForm, criterion_scope: v })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="individual">{language === 'ar' ? 'فردي' : 'Individual'}</SelectItem>
                          <SelectItem value="group">{language === 'ar' ? 'جماعي' : 'Group'}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'النوع' : 'Type'}</Label>
                      <Select value={editCriteriaForm.criterion_type} onValueChange={(v: CriterionType) => setEditCriteriaForm({ ...editCriteriaForm, criterion_type: v })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">{language === 'ar' ? 'للقاء' : 'Per Session'}</SelectItem>
                          <SelectItem value="overall">{language === 'ar' ? 'نهائي' : 'Overall'}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'الدرجة القصوى' : 'Max Score'}</Label>
                      <Input
                        type="number"
                        value={editCriteriaForm.max_score}
                        onChange={(e) => setEditCriteriaForm({ ...editCriteriaForm, max_score: e.target.value })}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'الوزن' : 'Weight'}</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={editCriteriaForm.weight}
                        onChange={(e) => setEditCriteriaForm({ ...editCriteriaForm, weight: e.target.value })}
                        required
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 rtl:flex-row-reverse">
                    <Button type="button" variant="outline" onClick={() => setIsEditCriteriaDialogOpen(false)}>
                      {language === 'ar' ? 'إلغاء' : 'Cancel'}
                    </Button>
                    <Button type="submit">{language === 'ar' ? 'حفظ التعديلات' : 'Save Changes'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
