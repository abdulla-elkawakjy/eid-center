import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface UserPermissions {
  isAdmin: boolean;
  isAssigned: boolean;
  isProgramLeader: boolean;
  canEditSessionInfo: boolean;
  canManageCriteria: boolean;
  canSubmitStoreRequest: boolean;
  canSubmitSessionReport: boolean;
  canEnterIndividualEvaluation: boolean;
  canEnterGroupEvaluation: boolean;
  canCoordinateCatering: boolean;
  assignmentId: string | null;
  roleName: string | null;
  roleNameEn: string | null;
}

export function useUserPermissions(programId: string | undefined) {
  const { user, role } = useAuth();
  const isAdmin = role === 'admin';

  const { data: permissions, isLoading } = useQuery({
    queryKey: ['user-permissions', programId, user?.id],
    queryFn: async (): Promise<UserPermissions> => {
      // Admins have all permissions
      if (isAdmin) {
        return {
          isAdmin: true,
          isAssigned: true,
          isProgramLeader: true,
          canEditSessionInfo: true,
          canManageCriteria: true,
          canSubmitStoreRequest: true,
          canSubmitSessionReport: true,
          canEnterIndividualEvaluation: true,
          canEnterGroupEvaluation: true,
          canCoordinateCatering: true,
          assignmentId: null,
          roleName: null,
          roleNameEn: null,
        };
      }

      if (!user?.id || !programId) {
        return {
          isAdmin: false,
          isAssigned: false,
          isProgramLeader: false,
          canEditSessionInfo: false,
          canManageCriteria: false,
          canSubmitStoreRequest: false,
          canSubmitSessionReport: false,
          canEnterIndividualEvaluation: false,
          canEnterGroupEvaluation: false,
          canCoordinateCatering: false,
          assignmentId: null,
          roleName: null,
          roleNameEn: null,
        };
      }

      // Get staff assignment
      const { data: assignment, error: assignmentError } = await supabase
        .from('staff_assignments')
        .select('id, role_name, role_name_en, is_leader')
        .eq('program_id', programId)
        .eq('staff_id', user.id)
        .maybeSingle();

      if (assignmentError || !assignment) {
        return {
          isAdmin: false,
          isAssigned: false,
          isProgramLeader: false,
          canEditSessionInfo: false,
          canManageCriteria: false,
          canSubmitStoreRequest: false,
          canSubmitSessionReport: false,
          canEnterIndividualEvaluation: false,
          canEnterGroupEvaluation: false,
          canCoordinateCatering: false,
          assignmentId: null,
          roleName: null,
          roleNameEn: null,
        };
      }

      // Get supervisor permissions
      const { data: perms } = await supabase
        .from('supervisor_permissions')
        .select('*')
        .eq('assignment_id', assignment.id)
        .maybeSingle();

      return {
        isAdmin: false,
        isAssigned: true,
        isProgramLeader: assignment.is_leader ?? false,
        canEditSessionInfo: perms?.can_edit_session_info ?? false,
        canManageCriteria: perms?.can_manage_criteria ?? false,
        canSubmitStoreRequest: perms?.can_submit_store_request ?? false,
        canSubmitSessionReport: perms?.can_submit_session_report ?? false,
        canEnterIndividualEvaluation: perms?.can_enter_individual_evaluation ?? false,
        canEnterGroupEvaluation: perms?.can_enter_group_evaluation ?? false,
        canCoordinateCatering: perms?.can_coordinate_catering ?? false,
        assignmentId: assignment.id,
        roleName: assignment.role_name,
        roleNameEn: assignment.role_name_en,
      };
    },
    enabled: !!programId,
  });

  return {
    permissions: permissions ?? {
      isAdmin,
      isAssigned: false,
      isProgramLeader: isAdmin,
      canEditSessionInfo: isAdmin,
      canManageCriteria: isAdmin,
      canSubmitStoreRequest: isAdmin,
      canSubmitSessionReport: isAdmin,
      canEnterIndividualEvaluation: isAdmin,
      canEnterGroupEvaluation: isAdmin,
      canCoordinateCatering: isAdmin,
      assignmentId: null,
      roleName: null,
      roleNameEn: null,
    },
    isLoading,
  };
}
