import { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Save, FileText, Users, MapPin, Calendar, Hash, BookOpen, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { UserPermissions } from '@/hooks/useUserPermissions';

interface SessionReportTabProps {
  sessionId: string;
  programId: string;
  permissions: UserPermissions;
}

interface SessionInfo {
  session_number: number | null;
  session_date: string | null;
  location: string | null;
  planned_courses: string | null;
}

interface StaffAssignment {
  id: string;
  staff_id: string;
  role_name: string | null;
  staff?: {
    full_name: string;
  };
}

interface SupervisorAttendance {
  supervisor_id: string;
  present: boolean;
}

interface ProgramCourse {
  id: string;
  name: string;
  name_en: string | null;
}

interface CoursePortion {
  id?: string;
  course_id: string;
  portion_from: string;
  portion_to: string;
  is_completed: boolean;
  completion_notes: string;
}

export function SessionReportTab({ sessionId, programId, permissions }: SessionReportTabProps) {
  const { language } = useLanguage();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    supervisorAttendance: [] as SupervisorAttendance[],
    coursesDelivered: '',
    specialActivities: '',
    notes: '',
  });
  
  const [coursePortions, setCoursePortions] = useState<CoursePortion[]>([]);

  const canEdit = permissions.isAdmin || permissions.canSubmitSessionReport;

  // Fetch session info
  const { data: sessionInfo } = useQuery({
    queryKey: ['session-info', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sessions')
        .select('session_number, session_date, location, planned_courses')
        .eq('id', sessionId)
        .single();
      if (error) throw error;
      return data as SessionInfo;
    },
    enabled: !!sessionId,
  });

  // Fetch attendance count
  const { data: attendanceCount } = useQuery({
    queryKey: ['attendance-count', sessionId],
    queryFn: async () => {
      const { count, error } = await supabase
        .from('student_attendance')
        .select('*', { count: 'exact', head: true })
        .eq('session_id', sessionId)
        .eq('is_present', true);
      if (error) throw error;
      return count ?? 0;
    },
    enabled: !!sessionId,
  });

  // Fetch staff assignments
  const { data: staffAssignments } = useQuery({
    queryKey: ['staff-assignments-for-report', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('staff_assignments')
        .select('id, staff_id, role_name')
        .eq('program_id', programId);
      if (error) throw error;

      // Fetch staff profiles
      const staffIds = data.map((a) => a.staff_id);
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name')
        .in('user_id', staffIds);

      const profilesMap = new Map(profiles?.map((p) => [p.user_id, p]) || []);

      return data.map((a) => ({
        ...a,
        staff: profilesMap.get(a.staff_id),
      })) as StaffAssignment[];
    },
    enabled: !!programId,
  });

  // Fetch program courses
  const { data: programCourses } = useQuery({
    queryKey: ['program-courses', programId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('program_courses')
        .select('id, name, name_en')
        .eq('program_id', programId)
        .order('order_index', { ascending: true });
      if (error) throw error;
      return data as ProgramCourse[];
    },
    enabled: !!programId,
  });

  // Fetch existing course portions
  const { data: existingCoursePortions } = useQuery({
    queryKey: ['session-course-portions', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('session_course_portions')
        .select('*')
        .eq('session_id', sessionId);
      if (error) throw error;
      return data;
    },
    enabled: !!sessionId,
  });

  // Fetch existing report
  const { data: existingReport } = useQuery({
    queryKey: ['session-report', sessionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('session_reports')
        .select('*')
        .eq('session_id', sessionId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!sessionId,
  });

  // Initialize form from existing report
  useEffect(() => {
    if (existingReport) {
      setFormData({
        supervisorAttendance: (existingReport.supervisor_attendance as unknown as SupervisorAttendance[]) || [],
        coursesDelivered: existingReport.courses_delivered || '',
        specialActivities: existingReport.special_activities || '',
        notes: existingReport.notes || '',
      });
    } else if (staffAssignments) {
      // Initialize supervisor attendance with all supervisors as not present
      setFormData((prev) => ({
        ...prev,
        supervisorAttendance: staffAssignments.map((a) => ({
          supervisor_id: a.staff_id,
          present: false,
        })),
      }));
    }
  }, [existingReport, staffAssignments]);

  // Initialize course portions from existing data
  useEffect(() => {
    if (existingCoursePortions && programCourses) {
      setCoursePortions(existingCoursePortions.map(p => ({
        id: p.id,
        course_id: p.course_id,
        portion_from: p.portion_from || '',
        portion_to: p.portion_to || '',
        is_completed: p.is_completed || false,
        completion_notes: p.completion_notes || ''
      })));
    }
  }, [existingCoursePortions, programCourses]);

  const getPortionForCourse = useCallback((courseId: string): CoursePortion => {
    return coursePortions.find(p => p.course_id === courseId) || {
      course_id: courseId,
      portion_from: '',
      portion_to: '',
      is_completed: false,
      completion_notes: ''
    };
  }, [coursePortions]);

  const updateCoursePortion = (courseId: string, field: keyof CoursePortion, value: string | boolean) => {
    setCoursePortions(prev => {
      const existingIndex = prev.findIndex(p => p.course_id === courseId);
      if (existingIndex >= 0) {
        const updated = [...prev];
        updated[existingIndex] = { ...updated[existingIndex], [field]: value };
        return updated;
      } else {
        return [...prev, {
          course_id: courseId,
          portion_from: '',
          portion_to: '',
          is_completed: false,
          completion_notes: '',
          [field]: value
        }];
      }
    });
  };

  // Save report mutation
  const saveReportMutation = useMutation({
    mutationFn: async () => {
      const reportData = {
        session_id: sessionId,
        submitted_by: user?.id,
        supervisor_attendance: JSON.parse(JSON.stringify(formData.supervisorAttendance)),
        courses_delivered: formData.coursesDelivered || null,
        special_activities: formData.specialActivities || null,
        notes: formData.notes || null,
        submitted_at: new Date().toISOString(),
      };

      if (existingReport?.id) {
        const { error } = await supabase
          .from('session_reports')
          .update(reportData)
          .eq('id', existingReport.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('session_reports').insert([reportData]);
        if (error) throw error;
      }

      // Save course portions
      for (const portion of coursePortions) {
        const hasData = portion.portion_from || portion.portion_to || portion.is_completed || portion.completion_notes;
        if (!hasData) continue;

        if (portion.id) {
          await supabase.from('session_course_portions').update({
            portion_from: portion.portion_from || null,
            portion_to: portion.portion_to || null,
            is_completed: portion.is_completed,
            completion_notes: portion.completion_notes || null
          }).eq('id', portion.id);
        } else {
          const { data: existing } = await supabase
            .from('session_course_portions')
            .select('id')
            .eq('session_id', sessionId)
            .eq('course_id', portion.course_id)
            .maybeSingle();
          
          if (existing) {
            await supabase.from('session_course_portions').update({
              portion_from: portion.portion_from || null,
              portion_to: portion.portion_to || null,
              is_completed: portion.is_completed,
              completion_notes: portion.completion_notes || null
            }).eq('id', existing.id);
          } else {
            await supabase.from('session_course_portions').insert({
              session_id: sessionId,
              course_id: portion.course_id,
              portion_from: portion.portion_from || null,
              portion_to: portion.portion_to || null,
              is_completed: portion.is_completed,
              completion_notes: portion.completion_notes || null
            });
          }
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['session-report', sessionId] });
      queryClient.invalidateQueries({ queryKey: ['session-course-portions', sessionId] });
      toast.success(language === 'ar' ? 'تم حفظ التقرير' : 'Report saved');
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ' : 'Error saving report');
    },
  });

  const handleSupervisorAttendanceToggle = (supervisorId: string) => {
    setFormData((prev) => ({
      ...prev,
      supervisorAttendance: prev.supervisorAttendance.map((a) =>
        a.supervisor_id === supervisorId ? { ...a, present: !a.present } : a
      ),
    }));
  };

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  return (
    <div className="space-y-6">
      {/* Auto-populated Info Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2 rtl:flex-row-reverse">
              <Hash className="h-4 w-4" />
              {language === 'ar' ? 'رقم اللقاء' : 'Session Number'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{sessionInfo?.session_number ?? '-'}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2 rtl:flex-row-reverse">
              <Calendar className="h-4 w-4" />
              {language === 'ar' ? 'التاريخ' : 'Date'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-medium">{formatDate(sessionInfo?.session_date ?? null)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2 rtl:flex-row-reverse">
              <MapPin className="h-4 w-4" />
              {language === 'ar' ? 'الموقع' : 'Location'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-medium">{sessionInfo?.location || '-'}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2 rtl:flex-row-reverse">
              <Users className="h-4 w-4" />
              {language === 'ar' ? 'عدد الحضور' : 'Attendance Count'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{attendanceCount ?? 0}</p>
          </CardContent>
        </Card>
      </div>

      {/* Report Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
            <FileText className="h-5 w-5" />
            {language === 'ar' ? 'تقرير اللقاء' : 'Session Report'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Supervisor Attendance */}
          <div className="space-y-3">
            <Label className="text-base font-medium">
              {language === 'ar' ? 'حضور المشرفين' : 'Supervisor Attendance'}
            </Label>
            <div className="grid gap-3 md:grid-cols-2">
              {staffAssignments?.map((assignment) => {
                const attendance = formData.supervisorAttendance.find(
                  (a) => a.supervisor_id === assignment.staff_id
                );
                return (
                  <div
                    key={assignment.id}
                    className="flex items-center gap-3 p-3 rounded-lg border rtl:flex-row-reverse"
                  >
                    <Checkbox
                      checked={attendance?.present ?? false}
                      onCheckedChange={() => handleSupervisorAttendanceToggle(assignment.staff_id)}
                      disabled={!canEdit}
                    />
                    <div className="flex-1 text-start">
                      <p className="font-medium">{assignment.staff?.full_name}</p>
                      {assignment.role_name && (
                        <p className="text-sm text-muted-foreground">{assignment.role_name}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Course Portions Section */}
          {programCourses && programCourses.length > 0 && (
            <div className="space-y-4">
              <Label className="text-base font-medium flex items-center gap-2 rtl:flex-row-reverse">
                <BookOpen className="h-4 w-4" />
                {language === 'ar' ? 'حصص المقررات' : 'Course Portions'}
              </Label>
              <div className="space-y-3">
                {programCourses.map(course => {
                  const portion = getPortionForCourse(course.id);
                  return (
                    <Card 
                      key={course.id} 
                      className={portion.is_completed ? 'border-green-500/50 bg-green-50/30 dark:bg-green-950/10' : ''}
                    >
                      <CardContent className="pt-4 space-y-3">
                        <div className="flex items-center justify-between rtl:flex-row-reverse">
                          <h5 className="font-medium flex items-center gap-2 rtl:flex-row-reverse">
                            {portion.is_completed && <CheckCircle2 className="h-4 w-4 text-green-600" />}
                            {language === 'ar' ? course.name : course.name_en || course.name}
                          </h5>
                          <div className="flex items-center gap-2 rtl:flex-row-reverse">
                            <Checkbox
                              id={`course-completed-${course.id}`}
                              checked={portion.is_completed}
                              onCheckedChange={(checked) => updateCoursePortion(course.id, 'is_completed', !!checked)}
                              disabled={!canEdit}
                            />
                            <Label htmlFor={`course-completed-${course.id}`} className="text-sm">
                              {language === 'ar' ? 'تم التنفيذ' : 'Completed'}
                            </Label>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <Label className="text-xs text-muted-foreground">
                              {language === 'ar' ? 'من' : 'From'}
                            </Label>
                            <Input
                              value={portion.portion_from}
                              onChange={(e) => updateCoursePortion(course.id, 'portion_from', e.target.value)}
                              placeholder={language === 'ar' ? 'مثال: صفحة 1' : 'e.g., Page 1'}
                              disabled={!canEdit}
                              className="h-8 text-sm"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs text-muted-foreground">
                              {language === 'ar' ? 'إلى' : 'To'}
                            </Label>
                            <Input
                              value={portion.portion_to}
                              onChange={(e) => updateCoursePortion(course.id, 'portion_to', e.target.value)}
                              placeholder={language === 'ar' ? 'مثال: صفحة 10' : 'e.g., Page 10'}
                              disabled={!canEdit}
                              className="h-8 text-sm"
                            />
                          </div>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">
                            {language === 'ar' ? 'ملاحظات' : 'Notes'}
                          </Label>
                          <Textarea
                            value={portion.completion_notes}
                            onChange={(e) => updateCoursePortion(course.id, 'completion_notes', e.target.value)}
                            placeholder={language === 'ar' ? 'ملاحظات...' : 'Notes...'}
                            disabled={!canEdit}
                            rows={2}
                            className="text-sm"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}

          {/* Legacy: Planned Courses (from session - now replaced by structured course portions) */}
          {sessionInfo?.planned_courses && !programCourses?.length && (
            <div className="space-y-2">
              <Label className="text-base font-medium">
                {language === 'ar' ? 'المقررات المخطط لها' : 'Planned Courses'}
              </Label>
              <p className="text-sm text-muted-foreground bg-muted p-3 rounded-lg">
                {sessionInfo.planned_courses}
              </p>
            </div>
          )}

          {/* Courses Delivered (legacy text field - keep for additional comments) */}
          <div className="space-y-2">
            <Label htmlFor="coursesDelivered" className="text-base font-medium">
              {language === 'ar' ? 'تعليقات إضافية على المقررات' : 'Additional Comments on Courses'}
            </Label>
            <Textarea
              id="coursesDelivered"
              value={formData.coursesDelivered}
              onChange={(e) => setFormData({ ...formData, coursesDelivered: e.target.value })}
              placeholder={language === 'ar' ? 'أي تعليقات إضافية...' : 'Any additional comments...'}
              disabled={!canEdit}
              rows={2}
            />
          </div>

          {/* Special Activities */}
          <div className="space-y-2">
            <Label htmlFor="specialActivities" className="text-base font-medium">
              {language === 'ar' ? 'الأنشطة الخاصة المنفذة' : 'Special Activities Done'}
            </Label>
            <Textarea
              id="specialActivities"
              value={formData.specialActivities}
              onChange={(e) => setFormData({ ...formData, specialActivities: e.target.value })}
              placeholder={language === 'ar' ? 'أنشطة خاصة تمت خلال اللقاء...' : 'Special activities conducted during the session...'}
              disabled={!canEdit}
              rows={3}
            />
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-base font-medium">
              {language === 'ar' ? 'ملاحظات إضافية' : 'Additional Notes'}
            </Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder={language === 'ar' ? 'ملاحظات إضافية...' : 'Additional notes...'}
              disabled={!canEdit}
              rows={3}
            />
          </div>

          {/* Save Button */}
          {canEdit && (
            <div className="flex justify-end">
              <Button onClick={() => saveReportMutation.mutate()} disabled={saveReportMutation.isPending}>
                <Save className="h-4 w-4 me-2" />
                {language === 'ar' ? 'حفظ التقرير' : 'Save Report'}
              </Button>
            </div>
          )}

          {/* Submission Info */}
          {existingReport?.submitted_at && (
            <p className="text-sm text-muted-foreground text-center">
              {language === 'ar' 
                ? `تم الإرسال: ${format(new Date(existingReport.submitted_at), 'PPp', { locale: ar })}`
                : `Submitted: ${format(new Date(existingReport.submitted_at), 'PPp')}`}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
