import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Logo } from '@/components/Logo';
import { LanguageToggle } from '@/components/LanguageToggle';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { ArrowRight, Loader2, Shield } from 'lucide-react';
import { z } from 'zod';

const loginSchema = z.object({
  email: z.string().email('البريد الإلكتروني غير صالح'),
  password: z.string().min(6, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'),
});

export default function StaffLogin() {
  const { t } = useLanguage();
  const { signIn, role } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    // Validate
    const result = loginSchema.safeParse({ email, password });
    if (!result.success) {
      const fieldErrors: { email?: string; password?: string } = {};
      result.error.errors.forEach((err) => {
        if (err.path[0] === 'email') fieldErrors.email = err.message;
        if (err.path[0] === 'password') fieldErrors.password = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setLoading(true);
    try {
      const { error } = await signIn(email, password);
      
      if (error) {
        toast({
          title: t('خطأ في تسجيل الدخول', 'Login Error'),
          description: t(
            'البريد الإلكتروني أو كلمة المرور غير صحيحة',
            'Invalid email or password'
          ),
          variant: 'destructive',
        });
        return;
      }

      toast({
        title: t('تم تسجيل الدخول بنجاح', 'Login Successful'),
        description: t('جاري تحويلك...', 'Redirecting...'),
      });

      // Redirect based on role - will be handled by the dashboard
      navigate('/dashboard');
    } catch (err) {
      toast({
        title: t('خطأ', 'Error'),
        description: t('حدث خطأ أثناء تسجيل الدخول', 'An error occurred during login'),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="hero-gradient">
        <div className="container py-6">
          <nav className="flex items-center justify-between">
            <button onClick={() => navigate('/')} className="flex items-center gap-2 group">
              <ArrowRight className="h-5 w-5 text-primary-foreground/70 group-hover:text-primary-foreground transition-colors rotate-180 rtl:rotate-0" />
              <Logo size="sm" />
            </button>
            <LanguageToggle />
          </nav>
        </div>
      </header>

      {/* Login Form */}
      <main className="container py-16 flex items-center justify-center">
        <Card className="w-full max-w-md animate-scale-in">
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Shield className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">
              {t('دخول المشرفين', 'Supervisor Login')}
            </CardTitle>
            <CardDescription>
              {t(
                'أدخل بياناتك للوصول إلى لوحة التحكم',
                'Enter your credentials to access the dashboard'
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">{t('البريد الإلكتروني', 'Email')}</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder={t('أدخل بريدك الإلكتروني', 'Enter your email')}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={errors.email ? 'border-destructive' : ''}
                />
                {errors.email && (
                  <p className="text-sm text-destructive">{errors.email}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">{t('كلمة المرور', 'Password')}</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder={t('أدخل كلمة المرور', 'Enter your password')}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={errors.password ? 'border-destructive' : ''}
                />
                {errors.password && (
                  <p className="text-sm text-destructive">{errors.password}</p>
                )}
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 me-2 animate-spin" />
                    {t('جاري تسجيل الدخول...', 'Logging in...')}
                  </>
                ) : (
                  t('تسجيل الدخول', 'Login')
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
