import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { NationalitySelect } from '@/components/shared/NationalitySelect';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, GraduationCap, Key, Loader2, CheckCircle, Mail, Lock, User, Phone, IdCard, Calendar, School, HeartPulse, Globe } from 'lucide-react';

interface Student {
  id: string;
  full_name: string;
  date_of_birth: string | null;
  gender: string | null;
  notes: string | null;
  parent_id: string;
  created_at: string;
  user_id: string | null;
  qid_number: string | null;
  school_grade: number | null;
  mobile_number: string | null;
  nationality: string | null;
  has_health_conditions: boolean | null;
  health_conditions_details: string | null;
}

interface Parent {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
}

export default function StudentsManagement() {
  const { t, language } = useLanguage();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isAccountDialogOpen, setIsAccountDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [selectedStudentForAccount, setSelectedStudentForAccount] = useState<Student | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [creatingAccount, setCreatingAccount] = useState(false);
  
  // Combined form data for new registration
  const [formData, setFormData] = useState({
    full_name: '',
    date_of_birth: '',
    gender: '',
    notes: '',
    parent_id: '',
    email: '',
    password: '',
    confirmPassword: '',
    qid_number: '',
    school_grade: '',
    mobile_number: '',
    nationality: '',
    has_health_conditions: 'no' as 'yes' | 'no',
    health_conditions_details: '',
  });

  // Separate form for legacy account creation
  const [accountFormData, setAccountFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
  });

  const { data: students, isLoading } = useQuery({
    queryKey: ['students'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as Student[];
    }
  });

  const { data: parents } = useQuery({
    queryKey: ['parents-list'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, user_id, full_name, email');
      if (error) throw error;
      return data as Parent[];
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const { error } = await supabase.from('students').update({
        full_name: data.full_name,
        date_of_birth: data.date_of_birth || null,
        gender: data.gender || null,
        notes: data.notes || null,
        parent_id: data.parent_id,
        qid_number: data.qid_number || null,
        school_grade: data.school_grade ? parseInt(data.school_grade) : null,
        mobile_number: data.mobile_number || null,
        nationality: data.nationality || null,
        has_health_conditions: data.has_health_conditions === 'yes',
        health_conditions_details: data.has_health_conditions === 'yes' 
          ? data.health_conditions_details 
          : null,
      }).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast.success(language === 'ar' ? 'تم تحديث الطالب بنجاح' : 'Student updated successfully');
      resetForm();
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء التحديث' : 'Error updating student');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('students').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      toast.success(language === 'ar' ? 'تم حذف الطالب بنجاح' : 'Student deleted successfully');
    },
    onError: () => {
      toast.error(language === 'ar' ? 'حدث خطأ أثناء الحذف' : 'Error deleting student');
    }
  });

  const resetForm = () => {
    setFormData({ 
      full_name: '', 
      date_of_birth: '', 
      gender: '', 
      notes: '', 
      parent_id: '',
      email: '',
      password: '',
      confirmPassword: '',
      qid_number: '',
      school_grade: '',
      mobile_number: '',
      nationality: '',
      has_health_conditions: 'no',
      health_conditions_details: '',
    });
    setEditingStudent(null);
    setIsDialogOpen(false);
  };

  const resetAccountForm = () => {
    setAccountFormData({
      email: '',
      password: '',
      confirmPassword: '',
    });
    setSelectedStudentForAccount(null);
    setIsAccountDialogOpen(false);
  };

  const handleEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({
      full_name: student.full_name,
      date_of_birth: student.date_of_birth || '',
      gender: student.gender || '',
      notes: student.notes || '',
      parent_id: student.parent_id,
      email: '',
      password: '',
      confirmPassword: '',
      qid_number: student.qid_number || '',
      school_grade: student.school_grade?.toString() || '',
      mobile_number: student.mobile_number || '',
      nationality: student.nationality || '',
      has_health_conditions: student.has_health_conditions ? 'yes' : 'no',
      health_conditions_details: student.health_conditions_details || '',
    });
    setIsDialogOpen(true);
  };

  const handleOpenAccountDialog = (student: Student) => {
    setSelectedStudentForAccount(student);
    setAccountFormData({
      email: '',
      password: '',
      confirmPassword: '',
    });
    setIsAccountDialogOpen(true);
  };

  // Create account for existing (legacy) student
  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedStudentForAccount) return;
    
    if (accountFormData.password !== accountFormData.confirmPassword) {
      toast.error(language === 'ar' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
      return;
    }

    if (accountFormData.password.length < 6) {
      toast.error(language === 'ar' ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' : 'Password must be at least 6 characters');
      return;
    }

    setCreatingAccount(true);

    try {
      const response = await supabase.functions.invoke('admin-create-user', {
        body: {
          email: accountFormData.email,
          password: accountFormData.password,
          fullName: selectedStudentForAccount.full_name,
          role: 'student',
          studentId: selectedStudentForAccount.id,
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to create account');
      }

      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      toast.success(language === 'ar' ? 'تم إنشاء حساب الطالب بنجاح' : 'Student account created successfully');
      queryClient.invalidateQueries({ queryKey: ['students'] });
      resetAccountForm();
    } catch (error: any) {
      console.error('Error creating student account:', error);
      toast.error(error.message || (language === 'ar' ? 'حدث خطأ أثناء إنشاء الحساب' : 'Error creating account'));
    } finally {
      setCreatingAccount(false);
    }
  };

  // Combined submit for new registration
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingStudent) {
      // Just update the profile
      updateMutation.mutate({ id: editingStudent.id, data: formData });
      return;
    }

    // Validate for new registration
    if (!formData.parent_id) {
      toast.error(language === 'ar' ? 'يرجى اختيار ولي الأمر' : 'Please select a parent');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error(language === 'ar' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      toast.error(language === 'ar' ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' : 'Password must be at least 6 characters');
      return;
    }

    // Validate QID (11 digits)
    if (!/^\d{11}$/.test(formData.qid_number)) {
      toast.error(language === 'ar' ? 'رقم الهوية يجب أن يكون 11 رقماً' : 'QID must be exactly 11 digits');
      return;
    }

    if (!formData.school_grade) {
      toast.error(language === 'ar' ? 'يرجى اختيار الصف الدراسي' : 'Please select school grade');
      return;
    }

    if (!formData.nationality) {
      toast.error(language === 'ar' ? 'يرجى اختيار الجنسية' : 'Please select nationality');
      return;
    }

    if (formData.has_health_conditions === 'yes' && !formData.health_conditions_details.trim()) {
      toast.error(language === 'ar' ? 'يرجى تحديد الحالة الصحية' : 'Please specify health conditions');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await supabase.functions.invoke('admin-create-user', {
        body: {
          email: formData.email,
          password: formData.password,
          fullName: formData.full_name,
          role: 'student',
          parentId: formData.parent_id,
          studentData: {
            full_name: formData.full_name,
            date_of_birth: formData.date_of_birth || undefined,
            gender: formData.gender || undefined,
            notes: formData.notes || undefined,
            qid_number: formData.qid_number,
            school_grade: parseInt(formData.school_grade),
            mobile_number: formData.mobile_number || undefined,
            nationality: formData.nationality,
            has_health_conditions: formData.has_health_conditions === 'yes',
            health_conditions_details: formData.has_health_conditions === 'yes' 
              ? formData.health_conditions_details 
              : undefined,
          },
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to register student');
      }

      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      toast.success(language === 'ar' ? 'تم تسجيل الطالب بنجاح' : 'Student registered successfully');
      queryClient.invalidateQueries({ queryKey: ['students'] });
      resetForm();
    } catch (error: any) {
      console.error('Error registering student:', error);
      toast.error(error.message || (language === 'ar' ? 'حدث خطأ أثناء التسجيل' : 'Error registering student'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const getParentName = (parentId: string) => {
    const parent = parents?.find(p => p.user_id === parentId);
    return parent?.full_name || '-';
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GraduationCap className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-foreground">
              {language === 'ar' ? 'إدارة الطلاب' : 'Students Management'}
            </h1>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => resetForm()}>
                <Plus className="h-4 w-4 me-2" />
                {language === 'ar' ? 'تسجيل طالب' : 'Register Student'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingStudent
                    ? (language === 'ar' ? 'تعديل الطالب' : 'Edit Student')
                    : (language === 'ar' ? 'تسجيل طالب جديد' : 'Register New Student')}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Account Section - Only for new registration */}
                {!editingStudent && (
                  <>
                    <div className="flex items-center gap-2 text-primary">
                      <Key className="h-4 w-4" />
                      <span className="font-medium">{t('معلومات الحساب', 'Account Information')}</span>
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        {t('البريد الإلكتروني', 'Email')} *
                      </Label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                        placeholder={t('أدخل البريد الإلكتروني', 'Enter email')}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <Lock className="h-4 w-4" />
                          {t('كلمة المرور', 'Password')} *
                        </Label>
                        <Input
                          type="password"
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          required
                          minLength={6}
                          placeholder={t('6 أحرف على الأقل', 'At least 6 characters')}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>{t('تأكيد كلمة المرور', 'Confirm Password')} *</Label>
                        <Input
                          type="password"
                          value={formData.confirmPassword}
                          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                          required
                          minLength={6}
                          placeholder={t('أعد إدخال كلمة المرور', 'Re-enter password')}
                        />
                      </div>
                    </div>

                    <Separator className="my-4" />
                    
                    <div className="flex items-center gap-2 text-primary">
                      <User className="h-4 w-4" />
                      <span className="font-medium">{t('معلومات الطالب', 'Student Information')}</span>
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    {language === 'ar' ? 'الاسم الكامل' : 'Full Name'} *
                  </Label>
                  <Input
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    required
                    placeholder={t('أدخل اسم الطالب', 'Enter student name')}
                  />
                </div>

                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'ولي الأمر' : 'Parent'} *</Label>
                  <Select
                    value={formData.parent_id}
                    onValueChange={(value) => setFormData({ ...formData, parent_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={language === 'ar' ? 'اختر ولي الأمر' : 'Select Parent'} />
                    </SelectTrigger>
                    <SelectContent>
                      {parents?.map((parent) => (
                        <SelectItem key={parent.user_id} value={parent.user_id}>
                          {parent.full_name} ({parent.email})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <IdCard className="h-4 w-4" />
                    {t('رقم الهوية القطرية', 'QID Number')} *
                  </Label>
                  <Input
                    value={formData.qid_number}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '').slice(0, 11);
                      setFormData({ ...formData, qid_number: value });
                    }}
                    required={!editingStudent}
                    placeholder={t('11 رقماً', '11 digits')}
                    maxLength={11}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {language === 'ar' ? 'تاريخ الميلاد' : 'Date of Birth'} *
                  </Label>
                  <Input
                    type="date"
                    value={formData.date_of_birth}
                    onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })}
                    required={!editingStudent}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <School className="h-4 w-4" />
                    {t('الصف الدراسي الحالي', 'Current School Grade')} *
                  </Label>
                  <Select
                    value={formData.school_grade}
                    onValueChange={(value) => setFormData({ ...formData, school_grade: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('اختر الصف', 'Select Grade')} />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: 12 }, (_, i) => i + 1).map((grade) => (
                        <SelectItem key={grade} value={grade.toString()}>
                          {language === 'ar' ? `الصف ${grade}` : `Grade ${grade}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    {t('رقم الجوال', 'Mobile Number')}
                  </Label>
                  <Input
                    type="tel"
                    value={formData.mobile_number}
                    onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                    placeholder={t('اختياري', 'Optional')}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    {t('الجنسية', 'Nationality')} *
                  </Label>
                  <NationalitySelect
                    value={formData.nationality}
                    onValueChange={(value) => setFormData({ ...formData, nationality: value })}
                    required={!editingStudent}
                  />
                </div>

                <div className="space-y-3">
                  <Label className="flex items-center gap-2">
                    <HeartPulse className="h-4 w-4" />
                    {t('هل يعاني من حساسية أو أمراض مزمنة؟', 'Allergies or Chronic Diseases?')} *
                  </Label>
                  <RadioGroup
                    value={formData.has_health_conditions}
                    onValueChange={(value: 'yes' | 'no') => setFormData({ ...formData, has_health_conditions: value })}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="yes" id="health-yes" />
                      <Label htmlFor="health-yes" className="cursor-pointer">
                        {t('نعم، يرجى التحديد', 'Yes, please specify')}
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <RadioGroupItem value="no" id="health-no" />
                      <Label htmlFor="health-no" className="cursor-pointer">
                        {t('لا', 'No')}
                      </Label>
                    </div>
                  </RadioGroup>
                  
                  {formData.has_health_conditions === 'yes' && (
                    <Textarea
                      value={formData.health_conditions_details}
                      onChange={(e) => setFormData({ ...formData, health_conditions_details: e.target.value })}
                      placeholder={t('يرجى ذكر التفاصيل...', 'Please specify details...')}
                      rows={2}
                      required
                    />
                  )}
                </div>

                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'ملاحظات' : 'Notes'}</Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    rows={2}
                    placeholder={t('اختياري', 'Optional')}
                  />
                </div>

                <div className="flex gap-2 justify-end">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    {language === 'ar' ? 'إلغاء' : 'Cancel'}
                  </Button>
                  <Button type="submit" disabled={isSubmitting || updateMutation.isPending}>
                    {(isSubmitting || updateMutation.isPending) && (
                      <Loader2 className="h-4 w-4 animate-spin me-2" />
                    )}
                    {editingStudent
                      ? (language === 'ar' ? 'حفظ التغييرات' : 'Save Changes')
                      : (language === 'ar' ? 'تسجيل' : 'Register')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Create Account Dialog for Legacy Students */}
        <Dialog open={isAccountDialogOpen} onOpenChange={setIsAccountDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Key className="h-5 w-5 text-primary" />
                {t('إنشاء حساب طالب', 'Create Student Account')}
              </DialogTitle>
            </DialogHeader>
            {selectedStudentForAccount && (
              <form onSubmit={handleCreateAccount} className="space-y-4">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    {t('إنشاء حساب لـ', 'Creating account for')}:
                  </p>
                  <p className="font-medium">{selectedStudentForAccount.full_name}</p>
                </div>

                <div className="space-y-2">
                  <Label>{t('البريد الإلكتروني', 'Email')} *</Label>
                  <Input
                    type="email"
                    value={accountFormData.email}
                    onChange={(e) => setAccountFormData({ ...accountFormData, email: e.target.value })}
                    required
                    placeholder={t('أدخل البريد الإلكتروني', 'Enter email')}
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('كلمة المرور', 'Password')} *</Label>
                  <Input
                    type="password"
                    value={accountFormData.password}
                    onChange={(e) => setAccountFormData({ ...accountFormData, password: e.target.value })}
                    required
                    minLength={6}
                    placeholder={t('6 أحرف على الأقل', 'At least 6 characters')}
                  />
                </div>

                <div className="space-y-2">
                  <Label>{t('تأكيد كلمة المرور', 'Confirm Password')} *</Label>
                  <Input
                    type="password"
                    value={accountFormData.confirmPassword}
                    onChange={(e) => setAccountFormData({ ...accountFormData, confirmPassword: e.target.value })}
                    required
                    minLength={6}
                    placeholder={t('أعد إدخال كلمة المرور', 'Re-enter password')}
                  />
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <Button type="button" variant="outline" onClick={resetAccountForm}>
                    {t('إلغاء', 'Cancel')}
                  </Button>
                  <Button type="submit" disabled={creatingAccount}>
                    {creatingAccount ? (
                      <Loader2 className="h-4 w-4 animate-spin me-2" />
                    ) : (
                      <Key className="h-4 w-4 me-2" />
                    )}
                    {t('إنشاء الحساب', 'Create Account')}
                  </Button>
                </div>
              </form>
            )}
          </DialogContent>
        </Dialog>

        <Card>
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'قائمة الطلاب' : 'Students List'}</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : students?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {language === 'ar' ? 'لا يوجد طلاب' : 'No students found'}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{language === 'ar' ? 'الاسم' : 'Name'}</TableHead>
                      <TableHead>{language === 'ar' ? 'ولي الأمر' : 'Parent'}</TableHead>
                      <TableHead>{language === 'ar' ? 'تاريخ الميلاد' : 'Date of Birth'}</TableHead>
                      <TableHead>{language === 'ar' ? 'الجنس' : 'Gender'}</TableHead>
                      <TableHead>{language === 'ar' ? 'الحساب' : 'Account'}</TableHead>
                      <TableHead>{language === 'ar' ? 'الإجراءات' : 'Actions'}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {students?.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">{student.full_name}</TableCell>
                        <TableCell>{getParentName(student.parent_id)}</TableCell>
                        <TableCell>{student.date_of_birth || '-'}</TableCell>
                        <TableCell>
                          {student.gender === 'male' 
                            ? (language === 'ar' ? 'ذكر' : 'Male')
                            : student.gender === 'female'
                            ? (language === 'ar' ? 'أنثى' : 'Female')
                            : '-'}
                        </TableCell>
                        <TableCell>
                          {student.user_id ? (
                            <Badge variant="secondary" className="flex items-center gap-1 w-fit">
                              <CheckCircle className="h-3 w-3" />
                              {t('لديه حساب', 'Has Account')}
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-muted-foreground w-fit">
                              {t('بدون حساب', 'No Account')}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="ghost" onClick={() => handleEdit(student)}>
                              <Pencil className="h-4 w-4" />
                            </Button>
                            {!student.user_id && (
                              <Button size="sm" variant="ghost" onClick={() => handleOpenAccountDialog(student)}>
                                <Key className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-destructive hover:text-destructive"
                              onClick={() => {
                                if (confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا الطالب؟' : 'Are you sure you want to delete this student?')) {
                                  deleteMutation.mutate(student.id);
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
