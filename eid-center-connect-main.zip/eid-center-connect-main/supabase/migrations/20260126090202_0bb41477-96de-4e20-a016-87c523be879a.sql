-- Create security definer function to check staff assignment without triggering RLS
CREATE OR REPLACE FUNCTION public.is_staff_assigned_to_program(_user_id uuid, _program_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.staff_assignments
    WHERE staff_id = _user_id
      AND program_id = _program_id
  )
$$;

-- Drop the problematic policy
DROP POLICY IF EXISTS "Staff can view registration requests for assigned programs" ON public.registration_requests;

-- Recreate policy using the security definer function
CREATE POLICY "Staff can view registration requests for assigned programs"
  ON public.registration_requests
  FOR SELECT
  USING (
    has_role(auth.uid(), 'staff'::app_role) 
    AND is_staff_assigned_to_program(auth.uid(), program_id)
  );