import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, Loader2, UserCog } from 'lucide-react';
import { NationalitySelect } from '@/components/shared/NationalitySelect';
import { Badge } from '@/components/ui/badge';

interface StaffMember {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  phone: string | null;
  qid_number: string | null;
  nationality: string | null;
  created_at: string;
  role: 'admin' | 'staff' | 'store_keeper';
}

export default function StaffManagement() {
  const { t } = useLanguage();
  const { user, role, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    password: '',
    qidNumber: '',
    nationality: '',
    userRole: 'staff' as 'admin' | 'staff' | 'store_keeper',
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/staff-login');
      return;
    }

    if (!authLoading && role !== 'admin') {
      navigate('/dashboard');
      return;
    }

    if (user && role === 'admin') {
      fetchStaff();
    }
  }, [user, role, authLoading, navigate]);

  const fetchStaff = async () => {
    try {
      // Get all users with staff, admin, or store_keeper role
      const { data: staffRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .in('role', ['staff', 'admin', 'store_keeper']);

      if (rolesError) throw rolesError;

      if (staffRoles && staffRoles.length > 0) {
        const userIds = staffRoles.map((r) => r.user_id);
        
        const { data: profiles, error: profilesError } = await supabase
          .from('profiles')
          .select('*')
          .in('user_id', userIds);

        if (profilesError) throw profilesError;

        // Combine profile data with role
        const staffWithRoles = (profiles || []).map(profile => {
          const roleEntry = staffRoles.find(r => r.user_id === profile.user_id);
          return {
            ...profile,
            role: roleEntry?.role as 'admin' | 'staff'
          };
        });

        setStaff(staffWithRoles);
      } else {
        setStaff([]);
      }
    } catch (error) {
      console.error('Error fetching staff:', error);
      toast({
        title: t('خطأ', 'Error'),
        description: t('فشل في تحميل بيانات المشرفين', 'Failed to load supervisor data'),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      if (editingStaff) {
        // Update existing staff profile
        const { error } = await supabase
          .from('profiles')
          .update({
            full_name: formData.fullName,
            phone: formData.phone,
            qid_number: formData.qidNumber,
            nationality: formData.nationality,
          })
          .eq('id', editingStaff.id);

        if (error) throw error;

        // Update role if changed
        if (formData.userRole !== editingStaff.role) {
          const { error: roleError } = await supabase
            .from('user_roles')
            .update({ role: formData.userRole })
            .eq('user_id', editingStaff.user_id);

          if (roleError) throw roleError;
        }

        toast({
          title: t('تم التحديث', 'Updated'),
          description: t('تم تحديث بيانات المشرف بنجاح', 'Supervisor updated successfully'),
        });
      } else {
        // Create new staff user via edge function (preserves admin session)
        const { data: funcData, error: funcError } = await supabase.functions.invoke('admin-create-user', {
          body: {
            email: formData.email,
            password: formData.password,
            fullName: formData.fullName,
            phone: formData.phone || undefined,
            qidNumber: formData.qidNumber,
            nationality: formData.nationality,
            role: formData.userRole
          }
        });

        if (funcError) throw funcError;
        if (funcData?.error) throw new Error(funcData.error);

        toast({
          title: t('تم الإنشاء', 'Created'),
          description: t('تم إنشاء حساب المشرف بنجاح', 'Supervisor account created successfully'),
        });
      }

      setIsDialogOpen(false);
      resetForm();
      fetchStaff();
    } catch (error: any) {
      console.error('Error saving staff:', error);
      toast({
        title: t('خطأ', 'Error'),
        description: error.message || t('فشل في حفظ البيانات', 'Failed to save data'),
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (staffMember: StaffMember) => {
    if (!confirm(t('هل أنت متأكد من حذف هذا المشرف؟', 'Are you sure you want to delete this supervisor?'))) {
      return;
    }

    try {
      // Delete the user role first
      const { error: roleError } = await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', staffMember.user_id);

      if (roleError) throw roleError;

      toast({
        title: t('تم الحذف', 'Deleted'),
        description: t('تم حذف المشرف بنجاح', 'Supervisor deleted successfully'),
      });

      fetchStaff();
    } catch (error: any) {
      console.error('Error deleting staff:', error);
      toast({
        title: t('خطأ', 'Error'),
        description: t('فشل في حذف المشرف', 'Failed to delete supervisor'),
        variant: 'destructive',
      });
    }
  };

  const openEditDialog = (staffMember: StaffMember) => {
    setEditingStaff(staffMember);
    setFormData({
      fullName: staffMember.full_name,
      email: staffMember.email,
      phone: staffMember.phone || '',
      password: '',
      qidNumber: staffMember.qid_number || '',
      nationality: staffMember.nationality || '',
      userRole: staffMember.role,
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({ fullName: '', email: '', phone: '', password: '', qidNumber: '', nationality: '', userRole: 'staff' as 'admin' | 'staff' | 'store_keeper' });
    setEditingStaff(null);
  };

  if (authLoading || loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              <UserCog className="h-8 w-8 text-primary" />
              {t('إدارة المشرفين', 'Supervisor Management')}
            </h1>
            <p className="text-muted-foreground mt-1">
              {t('إضافة وتعديل وحذف حسابات المشرفين', 'Add, edit, and delete supervisor accounts')}
            </p>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                {t('إضافة مشرف', 'Add Supervisor')}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingStaff
                    ? t('تعديل بيانات المشرف', 'Edit Supervisor')
                    : t('إضافة مشرف جديد', 'Add New Supervisor')}
                </DialogTitle>
                <DialogDescription>
                  {editingStaff
                    ? t('قم بتحديث بيانات المشرف', 'Update supervisor details')
                    : t('أدخل بيانات المشرف الجديد', 'Enter new supervisor details')}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>{t('الدور', 'Role')} *</Label>
                  <Select
                    value={formData.userRole}
                    onValueChange={(value: 'admin' | 'staff' | 'store_keeper') => setFormData({ ...formData, userRole: value })}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={t('اختر الدور', 'Select Role')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">{t('مدير', 'Admin')}</SelectItem>
                      <SelectItem value="staff">{t('مشرف', 'Supervisor')}</SelectItem>
                      <SelectItem value="store_keeper">{t('أمين المخزن', 'Store Keeper')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>{t('الاسم الكامل', 'Full Name')} *</Label>
                  <Input
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('رقم البطاقة الشخصية', 'QID Number')} *</Label>
                  <Input
                    value={formData.qidNumber}
                    onChange={(e) => setFormData({ ...formData, qidNumber: e.target.value })}
                    required
                    placeholder="XXXXXXXXXXX"
                    maxLength={11}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('رقم الجوال', 'Mobile Number')} *</Label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                    placeholder="+974 XXXXXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('الجنسية', 'Nationality')} *</Label>
                  <NationalitySelect
                    value={formData.nationality}
                    onValueChange={(value) => setFormData({ ...formData, nationality: value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t('البريد الإلكتروني', 'Email')} *</Label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    disabled={!!editingStaff}
                  />
                </div>
                {!editingStaff && (
                  <div className="space-y-2">
                    <Label>{t('كلمة المرور', 'Password')} *</Label>
                    <Input
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      required
                      minLength={6}
                    />
                  </div>
                )}
                <div className="flex gap-3 pt-4">
                  <Button type="submit" className="flex-1" disabled={submitting}>
                    {submitting && <Loader2 className="h-4 w-4 me-2 animate-spin" />}
                    {editingStaff ? t('تحديث', 'Update') : t('إضافة', 'Add')}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    {t('إلغاء', 'Cancel')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Staff Table */}
        <Card>
          <CardHeader>
            <CardTitle>{t('قائمة المشرفين', 'Supervisor List')}</CardTitle>
          </CardHeader>
          <CardContent>
            {staff.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                {t('لا يوجد مشرفين مسجلين', 'No supervisors registered')}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t('الاسم', 'Name')}</TableHead>
                      <TableHead>{t('الدور', 'Role')}</TableHead>
                      <TableHead>{t('رقم البطاقة', 'QID')}</TableHead>
                      <TableHead>{t('الجوال', 'Mobile')}</TableHead>
                      <TableHead>{t('الجنسية', 'Nationality')}</TableHead>
                      <TableHead>{t('البريد', 'Email')}</TableHead>
                      <TableHead className="w-[100px]">{t('إجراءات', 'Actions')}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {staff.map((member) => (
                      <TableRow key={member.id}>
                        <TableCell className="font-medium">{member.full_name}</TableCell>
                        <TableCell>
                          <Badge variant={member.role === 'admin' ? 'default' : member.role === 'store_keeper' ? 'secondary' : 'outline'}>
                            {member.role === 'admin' 
                              ? t('مدير', 'Admin') 
                              : member.role === 'store_keeper' 
                              ? t('أمين المخزن', 'Store Keeper')
                              : t('مشرف', 'Supervisor')}
                          </Badge>
                        </TableCell>
                        <TableCell>{member.qid_number || '-'}</TableCell>
                        <TableCell>{member.phone || '-'}</TableCell>
                        <TableCell>{member.nationality || '-'}</TableCell>
                        <TableCell>{member.email}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditDialog(member)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-destructive"
                              onClick={() => handleDelete(member)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
