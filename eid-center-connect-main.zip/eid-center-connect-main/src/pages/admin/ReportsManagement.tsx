import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Loader2, FileText, AlertTriangle, CheckCircle } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { ar } from 'date-fns/locale';

interface SessionWithReport {
  id: string;
  session_number: number | null;
  session_date: string | null;
  program: {
    id: string;
    name: string;
    name_en: string | null;
  } | null;
  report: {
    id: string;
    submitted_at: string | null;
  }[] | null;
}

export default function ReportsManagement() {
  const { t, language } = useLanguage();
  const { role, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  // Auth check
  if (!authLoading && role !== 'admin') {
    navigate('/dashboard');
    return null;
  }

  // Fetch all sessions with their reports
  const { data: sessions, isLoading } = useQuery({
    queryKey: ['admin-session-reports'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sessions')
        .select(`
          id,
          session_number,
          session_date,
          program:programs(id, name, name_en),
          report:session_reports(id, submitted_at)
        `)
        .not('session_date', 'is', null)
        .order('session_date', { ascending: false });

      if (error) throw error;
      return data as unknown as SessionWithReport[];
    },
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Split sessions into submitted and pending
  const submittedReports = sessions?.filter(s => 
    s.report && s.report.length > 0 && s.report[0].submitted_at
  ) || [];

  const pendingReports = sessions?.filter(s => {
    if (!s.session_date) return false;
    const sessionDate = new Date(s.session_date);
    sessionDate.setHours(0, 0, 0, 0);
    const isPast = sessionDate < today;
    const hasNoReport = !s.report || s.report.length === 0 || !s.report[0].submitted_at;
    return isPast && hasNoReport;
  }) || [];

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return format(new Date(date), 'PPP', { locale: language === 'ar' ? ar : undefined });
  };

  const getDaysOverdue = (date: string | null) => {
    if (!date) return 0;
    return differenceInDays(today, new Date(date));
  };

  const handleRowClick = (programId: string, sessionId: string) => {
    navigate(`/dashboard/program/${programId}?session=${sessionId}&tab=report`);
  };

  if (authLoading || isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3 rtl:flex-row-reverse">
            <FileText className="h-8 w-8 text-primary" />
            {t('التقارير', 'Reports')}
          </h1>
          <p className="text-muted-foreground mt-1 text-start">
            {t('متابعة تقارير اللقاءات', 'Track session reports')}
          </p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                {t('التقارير المقدمة', 'Submitted Reports')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-start text-green-600">
                {submittedReports.length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                {t('التقارير المعلقة', 'Pending Reports')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-start text-yellow-600">
                {pendingReports.length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground text-start">
                {t('نسبة الإنجاز', 'Completion Rate')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-start">
                {sessions && sessions.length > 0 
                  ? Math.round((submittedReports.length / (submittedReports.length + pendingReports.length)) * 100)
                  : 0}%
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="session-reports" className="w-full">
          <TabsList className="flex-wrap h-auto gap-2 p-2">
            <TabsTrigger value="session-reports" className="flex items-center gap-2 rtl:flex-row-reverse">
              <FileText className="h-4 w-4" />
              {t('تقارير اللقاءات', 'Session Reports')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="session-reports" className="space-y-6">
            {/* Submitted Reports */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse text-green-600">
                  <CheckCircle className="h-5 w-5" />
                  {t('التقارير المقدمة', 'Submitted Reports')} ({submittedReports.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {submittedReports.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    {t('لا توجد تقارير مقدمة', 'No submitted reports')}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{t('البرنامج', 'Program')}</TableHead>
                          <TableHead>{t('اللقاء', 'Session')}</TableHead>
                          <TableHead>{t('تاريخ اللقاء', 'Session Date')}</TableHead>
                          <TableHead>{t('تاريخ التقديم', 'Submitted On')}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {submittedReports.slice(0, 10).map((session) => (
                          <TableRow 
                            key={session.id} 
                            className="cursor-pointer hover:bg-muted/50"
                            onClick={() => handleRowClick(session.program?.id || '', session.id)}
                          >
                            <TableCell className="font-medium">
                              {language === 'ar' 
                                ? session.program?.name 
                                : session.program?.name_en || session.program?.name}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">#{session.session_number}</Badge>
                            </TableCell>
                            <TableCell>{formatDate(session.session_date)}</TableCell>
                            <TableCell>
                              <Badge variant="default" className="bg-green-600">
                                {formatDate(session.report?.[0]?.submitted_at || null)}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Pending Reports */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse text-yellow-600">
                  <AlertTriangle className="h-5 w-5" />
                  {t('التقارير المعلقة', 'Pending Reports')} ({pendingReports.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pendingReports.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    {t('لا توجد تقارير معلقة', 'No pending reports')}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>{t('البرنامج', 'Program')}</TableHead>
                          <TableHead>{t('اللقاء', 'Session')}</TableHead>
                          <TableHead>{t('تاريخ اللقاء', 'Session Date')}</TableHead>
                          <TableHead>{t('التأخير', 'Overdue By')}</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendingReports.map((session) => {
                          const daysOverdue = getDaysOverdue(session.session_date);
                          return (
                            <TableRow 
                              key={session.id}
                              className="cursor-pointer hover:bg-muted/50"
                              onClick={() => handleRowClick(session.program?.id || '', session.id)}
                            >
                              <TableCell className="font-medium">
                                {language === 'ar' 
                                  ? session.program?.name 
                                  : session.program?.name_en || session.program?.name}
                              </TableCell>
                              <TableCell>
                                <Badge variant="outline">#{session.session_number}</Badge>
                              </TableCell>
                              <TableCell>{formatDate(session.session_date)}</TableCell>
                              <TableCell>
                                <Badge 
                                  variant={daysOverdue > 7 ? "destructive" : "secondary"}
                                >
                                  {daysOverdue} {t('يوم', 'days')}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
