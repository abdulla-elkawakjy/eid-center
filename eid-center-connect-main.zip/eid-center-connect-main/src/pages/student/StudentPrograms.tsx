import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { BookOpen, Calendar, Users, FileText, TrendingUp, Download, Eye, Loader2, Phone, Image as ImageIcon, File as FileIcon, X } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';
import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';

interface Program {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
  description_en: string | null;
}

interface Session {
  id: string;
  session_date: string | null;
  location: string | null;
  notes: string | null;
}

interface StaffMember {
  id: string;
  staff_id: string;
  role: {
    name: string;
    name_en: string | null;
  } | null;
  profile: {
    full_name: string;
    phone: string | null;
  } | null;
}

interface ProgramFile {
  id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  created_at: string;
}

export default function StudentPrograms() {
  const { language, t } = useLanguage();
  const { user } = useAuth();
  const [selectedProgram, setSelectedProgram] = useState<string | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<ProgramFile | null>(null);
  const [selectedFileUrl, setSelectedFileUrl] = useState<string | null>(null);

  // Fetch student record
  const { data: student, isLoading: loadingStudent } = useQuery({
    queryKey: ['student-record', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('students')
        .select('id, full_name')
        .eq('user_id', user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user
  });

  // Fetch enrolled programs
  const { data: enrolledPrograms, isLoading: loadingPrograms } = useQuery({
    queryKey: ['student-programs', student?.id],
    queryFn: async () => {
      if (!student) return [];
      const { data, error } = await supabase
        .from('registration_requests')
        .select('program:programs(id, name, name_en, description, description_en)')
        .eq('student_id', student.id)
        .eq('status', 'approved');
      if (error) throw error;
      return data?.map(d => d.program).filter(Boolean) as Program[];
    },
    enabled: !!student
  });

  // Set default selected program
  useEffect(() => {
    if (enrolledPrograms && enrolledPrograms.length > 0 && !selectedProgram) {
      setSelectedProgram(enrolledPrograms[0].id);
    }
  }, [enrolledPrograms, selectedProgram]);

  // Fetch sessions for selected program
  const { data: sessions } = useQuery({
    queryKey: ['program-sessions-student', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('sessions')
        .select('id, session_date, location, notes')
        .eq('program_id', selectedProgram)
        .order('session_date', { ascending: true });
      if (error) throw error;
      return data as Session[];
    },
    enabled: !!selectedProgram
  });

  // Fetch staff assignments for selected program
  const { data: staffMembers } = useQuery({
    queryKey: ['program-staff-student', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('staff_assignments')
        .select(`
          id,
          staff_id,
          role:program_roles(name, name_en)
        `)
        .eq('program_id', selectedProgram);
      if (error) throw error;
      
      // Fetch profiles for each staff member
      const staffIds = data?.map((s: any) => s.staff_id) || [];
      if (staffIds.length === 0) return [];
      
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('user_id, full_name, phone')
        .in('user_id', staffIds);
      
      if (profilesError) throw profilesError;
      
      return data?.map((staff: any) => ({
        ...staff,
        profile: profiles?.find((p: any) => p.user_id === staff.staff_id) || null
      })) as StaffMember[];
    },
    enabled: !!selectedProgram
  });

  // Fetch program files
  const { data: programFiles } = useQuery({
    queryKey: ['program-files-student', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('program_files')
        .select('id, file_name, file_path, file_type, file_size, created_at')
        .eq('program_id', selectedProgram)
        .eq('visibility', 'staff_and_parents')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as ProgramFile[];
    },
    enabled: !!selectedProgram
  });

  // Fetch scores for the student
  const { data: studentScores } = useQuery({
    queryKey: ['student-scores', student?.id, selectedProgram],
    queryFn: async () => {
      if (!student || !selectedProgram) return [];
      
      const { data, error } = await supabase
        .from('student_scores')
        .select(`
          score,
          session_id,
          criterion:assessment_criteria(
            id, name, name_en, max_score, criterion_type
          )
        `)
        .eq('student_id', student.id);
      
      if (error) throw error;
      return data;
    },
    enabled: !!student && !!selectedProgram
  });

  // Fetch criteria for selected program
  const { data: criteria } = useQuery({
    queryKey: ['program-criteria-student', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('assessment_criteria')
        .select('id, name, name_en, max_score, criterion_type')
        .eq('program_id', selectedProgram)
        .order('name');
      if (error) throw error;
      return data;
    },
    enabled: !!selectedProgram
  });

  const handleDownload = async (file: ProgramFile) => {
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 60);
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في تحميل الملف' : 'Error downloading file');
      return;
    }
    
    const link = document.createElement('a');
    link.href = data.signedUrl;
    link.download = file.file_name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleViewFile = async (file: ProgramFile) => {
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 3600);
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في عرض الملف' : 'Error viewing file');
      return;
    }
    
    setSelectedFileUrl(data.signedUrl);
    setSelectedFile(file);
    setIsViewerOpen(true);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const isImageFile = (fileType: string) => fileType.startsWith('image/');
  const isPdfFile = (fileType: string) => fileType === 'application/pdf';

  const getFileIcon = (fileType: string) => {
    if (isImageFile(fileType)) return <ImageIcon className="h-5 w-5 text-blue-500" />;
    if (isPdfFile(fileType)) return <FileText className="h-5 w-5 text-red-500" />;
    return <FileIcon className="h-5 w-5 text-muted-foreground" />;
  };

  // Build assessment report data
  const buildAssessmentReport = useCallback(() => {
    if (!sessions || !criteria || !studentScores) return null;
    
    // Build score matrix: session -> criterion -> score
    const scoreMatrix: Record<string, Record<string, number>> = {};
    const criterionTotals: Record<string, { sum: number; count: number }> = {};
    
    sessions.forEach(session => {
      scoreMatrix[session.id] = {};
      criteria.forEach(criterion => {
        const score = studentScores.find(
          (s: any) => s.session_id === session.id && s.criterion?.id === criterion.id
        );
        if (score) {
          scoreMatrix[session.id][criterion.id] = score.score;
          if (!criterionTotals[criterion.id]) {
            criterionTotals[criterion.id] = { sum: 0, count: 0 };
          }
          criterionTotals[criterion.id].sum += score.score;
          criterionTotals[criterion.id].count += 1;
        }
      });
    });
    
    return { scoreMatrix, criterionTotals };
  }, [sessions, criteria, studentScores]);

  const assessmentReport = buildAssessmentReport();

  if (loadingStudent || loadingPrograms) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3 rtl:flex-row-reverse">
          <BookOpen className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              {t('برامجي', 'My Programs')}
            </h1>
            <p className="text-muted-foreground">
              {t('عرض تفاصيل البرامج المسجلة', 'View details of enrolled programs')}
            </p>
          </div>
        </div>

        {!enrolledPrograms || enrolledPrograms.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <BookOpen className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {t('لا توجد برامج مسجلة', 'No enrolled programs')}
              </h3>
              <p className="text-muted-foreground text-center">
                {t('لم يتم تسجيلك في أي برنامج حالياً', 
                   'You are not enrolled in any program currently')}
              </p>
            </CardContent>
          </Card>
        ) : (
          <Tabs value={selectedProgram || ''} onValueChange={setSelectedProgram} className="w-full">
            <TabsList className="flex-wrap h-auto gap-2 p-2">
              {enrolledPrograms.map((program) => (
                <TabsTrigger key={program.id} value={program.id} className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  {language === 'ar' ? program.name : program.name_en || program.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {enrolledPrograms.map((program) => (
              <TabsContent key={program.id} value={program.id} className="space-y-6 mt-6">
                {/* Program Description */}
                {(program.description || program.description_en) && (
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-muted-foreground">
                        {language === 'ar' 
                          ? program.description 
                          : program.description_en || program.description}
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Days Table */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
                      <Calendar className="h-5 w-5 text-primary" />
                      {t('جدول اللقاءات', 'Sessions Schedule')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!sessions || sessions.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا توجد لقاءات مجدولة', 'No sessions scheduled')}
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>{t('التاريخ', 'Date')}</TableHead>
                              <TableHead>{t('الموقع', 'Location')}</TableHead>
                              <TableHead>{t('ملاحظات', 'Notes')}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sessions.map((session) => (
                              <TableRow key={session.id}>
                                <TableCell>
                                  {session.session_date
                                    ? format(parseISO(session.session_date), 'dd MMM yyyy', {
                                        locale: language === 'ar' ? ar : enUS
                                      })
                                    : '-'}
                                </TableCell>
                                <TableCell>{session.location || '-'}</TableCell>
                                <TableCell>{session.notes || '-'}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Staff Table */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
                      <Users className="h-5 w-5 text-primary" />
                      {t('فريق العمل', 'Staff Team')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!staffMembers || staffMembers.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا يوجد فريق عمل معين', 'No staff assigned')}
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>{t('الاسم', 'Name')}</TableHead>
                              <TableHead>{t('الدور', 'Role')}</TableHead>
                              <TableHead>{t('رقم الجوال', 'Mobile')}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {staffMembers.map((staff) => (
                              <TableRow key={staff.id}>
                                <TableCell className="font-medium">
                                  {staff.profile?.full_name || '-'}
                                </TableCell>
                                <TableCell>
                                  {staff.role
                                    ? (language === 'ar' ? staff.role.name : staff.role.name_en || staff.role.name)
                                    : '-'}
                                </TableCell>
                                <TableCell>
                                  {staff.profile?.phone ? (
                                    <a 
                                      href={`tel:${staff.profile.phone}`}
                                      className="flex items-center gap-1 text-primary hover:underline rtl:flex-row-reverse"
                                    >
                                      <Phone className="h-4 w-4" />
                                      {staff.profile.phone}
                                    </a>
                                  ) : '-'}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Program Files */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
                      <FileText className="h-5 w-5 text-primary" />
                      {t('ملفات البرنامج', 'Program Files')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!programFiles || programFiles.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا توجد ملفات', 'No files available')}
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>{t('الملف', 'File')}</TableHead>
                              <TableHead>{t('الحجم', 'Size')}</TableHead>
                              <TableHead>{t('التاريخ', 'Date')}</TableHead>
                              <TableHead>{t('الإجراءات', 'Actions')}</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {programFiles.map((file) => (
                              <TableRow key={file.id}>
                                <TableCell>
                                  <div className="flex items-center gap-2 rtl:flex-row-reverse">
                                    {getFileIcon(file.file_type)}
                                    <span className="truncate max-w-[200px]">{file.file_name}</span>
                                  </div>
                                </TableCell>
                                <TableCell>{formatFileSize(file.file_size)}</TableCell>
                                <TableCell>
                                  {format(parseISO(file.created_at), 'dd MMM yyyy', {
                                    locale: language === 'ar' ? ar : enUS
                                  })}
                                </TableCell>
                                <TableCell>
                                  <div className="flex gap-2">
                                    {(isImageFile(file.file_type) || isPdfFile(file.file_type)) && (
                                      <Button size="sm" variant="ghost" onClick={() => handleViewFile(file)}>
                                        <Eye className="h-4 w-4" />
                                      </Button>
                                    )}
                                    <Button size="sm" variant="ghost" onClick={() => handleDownload(file)}>
                                      <Download className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Assessment Report */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse">
                      <TrendingUp className="h-5 w-5 text-primary" />
                      {t('تقرير الأداء', 'Performance Report')}
                    </CardTitle>
                    <CardDescription>
                      {t('تقييم الأداء في جميع الجلسات', 'Performance assessment across all sessions')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!criteria || criteria.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا توجد معايير تقييم', 'No assessment criteria')}
                      </p>
                    ) : !sessions || sessions.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا توجد جلسات', 'No sessions')}
                      </p>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="sticky start-0 bg-background z-10">
                                {t('الجلسة', 'Session')}
                              </TableHead>
                              {criteria.map((c) => (
                                <TableHead key={c.id} className="text-center min-w-[100px]">
                                  <div className="flex flex-col items-center">
                                    <span>{language === 'ar' ? c.name : c.name_en || c.name}</span>
                                    <span className="text-xs text-muted-foreground">
                                      ({t('من', 'of')} {c.max_score})
                                    </span>
                                  </div>
                                </TableHead>
                              ))}
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sessions.map((session) => (
                              <TableRow key={session.id}>
                                <TableCell className="sticky start-0 bg-background z-10 font-medium">
                                  {session.session_date
                                    ? format(parseISO(session.session_date), 'dd MMM', {
                                        locale: language === 'ar' ? ar : enUS
                                      })
                                    : '-'}
                                </TableCell>
                                {criteria.map((c) => {
                                  const score = assessmentReport?.scoreMatrix[session.id]?.[c.id];
                                  return (
                                    <TableCell key={c.id} className="text-center">
                                      {score !== undefined ? (
                                        <Badge 
                                          variant={score >= c.max_score * 0.7 ? 'default' : score >= c.max_score * 0.5 ? 'secondary' : 'outline'}
                                        >
                                          {score}
                                        </Badge>
                                      ) : '-'}
                                    </TableCell>
                                  );
                                })}
                              </TableRow>
                            ))}
                            {/* Average Row */}
                            <TableRow className="bg-muted/50 font-medium">
                              <TableCell className="sticky start-0 bg-muted/50 z-10">
                                {t('المعدل', 'Average')}
                              </TableCell>
                              {criteria.map((c) => {
                                const totals = assessmentReport?.criterionTotals[c.id];
                                const avg = totals ? (totals.sum / totals.count).toFixed(1) : null;
                                return (
                                  <TableCell key={c.id} className="text-center">
                                    {avg !== null ? (
                                      <Badge variant="default">{avg}</Badge>
                                    ) : '-'}
                                  </TableCell>
                                );
                              })}
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        )}

        {/* File Viewer Dialog */}
        <Dialog open={isViewerOpen} onOpenChange={setIsViewerOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                <span>{selectedFile?.file_name}</span>
                <Button variant="ghost" size="icon" onClick={() => setIsViewerOpen(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </DialogTitle>
            </DialogHeader>
            <div className="overflow-auto max-h-[70vh]">
              {selectedFile && selectedFileUrl && (
                isImageFile(selectedFile.file_type) ? (
                  <img 
                    src={selectedFileUrl} 
                    alt={selectedFile.file_name}
                    className="max-w-full h-auto mx-auto"
                  />
                ) : isPdfFile(selectedFile.file_type) ? (
                  <iframe
                    src={selectedFileUrl}
                    className="w-full h-[70vh]"
                    title={selectedFile.file_name}
                  />
                ) : null
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
