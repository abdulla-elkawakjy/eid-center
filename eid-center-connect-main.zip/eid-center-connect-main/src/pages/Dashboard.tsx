import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Users, GraduationCap, BookOpen, ClipboardList, Loader2 } from 'lucide-react';

interface DashboardStats {
  totalStudents: number;
  totalStaff: number;
  totalParents: number;
  totalPrograms: number;
  pendingRequests: number;
  activeSemesters: number;
}

export default function Dashboard() {
  const { t } = useLanguage();
  const { user, role, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats>({
    totalStudents: 0,
    totalStaff: 0,
    totalParents: 0,
    totalPrograms: 0,
    pendingRequests: 0,
    activeSemesters: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/staff-login');
      return;
    }

    if (!authLoading && role === 'parent') {
      navigate('/parent/dashboard');
      return;
    }

    if (!authLoading && role === 'student') {
      navigate('/student/dashboard');
      return;
    }

    if (user && (role === 'admin' || role === 'staff')) {
      fetchStats();
    }
  }, [user, role, authLoading, navigate]);

  const fetchStats = async () => {
    try {
      // Fetch students count
      const { count: studentsCount } = await supabase
        .from('students')
        .select('*', { count: 'exact', head: true });

      // Fetch programs count
      const { count: programsCount } = await supabase
        .from('programs')
        .select('*', { count: 'exact', head: true });

      // Fetch pending registration requests
      const { count: pendingCount } = await supabase
        .from('registration_requests')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      // Fetch active semesters
      const { count: semestersCount } = await supabase
        .from('semesters')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true);

      // Fetch staff count (users with staff role)
      const { count: staffCount } = await supabase
        .from('user_roles')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'staff');

      // Fetch parents count
      const { count: parentsCount } = await supabase
        .from('user_roles')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'parent');

      setStats({
        totalStudents: studentsCount || 0,
        totalStaff: staffCount || 0,
        totalParents: parentsCount || 0,
        totalPrograms: programsCount || 0,
        pendingRequests: pendingCount || 0,
        activeSemesters: semestersCount || 0,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (authLoading || loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  const statCards = [
    {
      title: t('إجمالي الطلاب', 'Total Students'),
      value: stats.totalStudents,
      icon: GraduationCap,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      title: t('البرامج النشطة', 'Active Programs'),
      value: stats.totalPrograms,
      icon: BookOpen,
      color: 'text-secondary',
      bgColor: 'bg-secondary/10',
    },
    {
      title: t('طلبات التسجيل المعلقة', 'Pending Registrations'),
      value: stats.pendingRequests,
      icon: ClipboardList,
      color: 'text-warning',
      bgColor: 'bg-warning/10',
    },
    {
      title: t('أولياء الأمور', 'Parents'),
      value: stats.totalParents,
      icon: Users,
      color: 'text-info',
      bgColor: 'bg-info/10',
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="animate-fade-in">
          <h1 className="text-3xl font-bold text-foreground">
            {t('لوحة التحكم', 'Dashboard')}
          </h1>
          <p className="text-muted-foreground mt-2">
            {role === 'admin'
              ? t('مرحباً بك في لوحة تحكم المدير', 'Welcome to the Admin Dashboard')
              : t('مرحباً بك في لوحة تحكم المشرف', 'Welcome to the Supervisor Dashboard')}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {statCards.map((stat, index) => (
            <Card
              key={stat.title}
              className="stat-card animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Info for Admin */}
        {role === 'admin' && (
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="animate-slide-up" style={{ animationDelay: '0.4s' }}>
              <CardHeader>
                <CardTitle>{t('الفصول الدراسية النشطة', 'Active Semesters')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary">{stats.activeSemesters}</div>
                <p className="text-muted-foreground mt-2">
                  {t('فصول دراسية قيد التشغيل', 'semesters currently running')}
                </p>
              </CardContent>
            </Card>

            <Card className="animate-slide-up" style={{ animationDelay: '0.5s' }}>
              <CardHeader>
                <CardTitle>{t('المشرفون', 'Supervisors')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary">{stats.totalStaff}</div>
                <p className="text-muted-foreground mt-2">
                  {t('موظف مسجل في النظام', 'staff members registered')}
                </p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
