import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BookOpen, Calendar, Users, FileText, TrendingUp, Download, Eye, Loader2, Phone, MapPin, Image as ImageIcon, File as FileIcon, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { format, parseISO } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';
import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';

interface Program {
  id: string;
  name: string;
  name_en: string | null;
  description: string | null;
  description_en: string | null;
  semester: {
    name: string;
    name_en: string | null;
  };
}

interface Session {
  id: string;
  session_date: string | null;
  location: string | null;
  notes: string | null;
}

interface StaffMember {
  id: string;
  staff_id: string;
  is_leader: boolean;
  role: {
    name: string;
    name_en: string | null;
  } | null;
  profile: {
    full_name: string;
    phone: string | null;
  } | null;
}

interface ProgramFile {
  id: string;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  created_at: string;
}

interface StudentScore {
  score: number;
  session_id: string | null;
  criterion: {
    id: string;
    name: string;
    name_en: string | null;
    max_score: number;
    criterion_type: string;
  };
}

interface EnrolledProgram {
  programId: string;
  studentId: string;
  studentName: string;
}

export default function MyPrograms() {
  const { language, t } = useLanguage();
  const { user } = useAuth();
  const [selectedProgram, setSelectedProgram] = useState<string | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<ProgramFile | null>(null);
  const [selectedFileUrl, setSelectedFileUrl] = useState<string | null>(null);
  const [signedUrls, setSignedUrls] = useState<Record<string, string>>({});

  // Fetch active semester
  const { data: activeSemester } = useQuery({
    queryKey: ['active-semester'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('semesters')
        .select('id, name, name_en')
        .eq('is_active', true)
        .maybeSingle();
      if (error) throw error;
      return data;
    }
  });

  // Fetch children with approved registrations in active semester
  const { data: enrolledPrograms, isLoading: loadingEnrollments } = useQuery({
    queryKey: ['parent-enrolled-programs', user?.id, activeSemester?.id],
    queryFn: async () => {
      if (!user || !activeSemester) return [];
      
      const { data: children, error: childrenError } = await supabase
        .from('students')
        .select(`
          id,
          full_name,
          registrations:registration_requests(
            status,
            program:programs(
              id, name, name_en, description, description_en,
              semester_id,
              semester:semesters(name, name_en)
            )
          )
        `)
        .eq('parent_id', user.id);
      
      if (childrenError) throw childrenError;
      
      const enrolled: EnrolledProgram[] = [];
      children?.forEach((child: any) => {
        child.registrations
          ?.filter((r: any) => r.status === 'approved' && r.program?.semester_id === activeSemester.id)
          .forEach((r: any) => {
            enrolled.push({
              programId: r.program.id,
              studentId: child.id,
              studentName: child.full_name
            });
          });
      });
      
      return enrolled;
    },
    enabled: !!user && !!activeSemester
  });

  // Get unique program IDs
  const uniqueProgramIds = [...new Set(enrolledPrograms?.map(e => e.programId) || [])];

  // Fetch program details
  const { data: programs } = useQuery({
    queryKey: ['parent-program-details', uniqueProgramIds],
    queryFn: async () => {
      if (uniqueProgramIds.length === 0) return [];
      const { data, error } = await supabase
        .from('programs')
        .select('id, name, name_en, description, description_en, semester:semesters(name, name_en)')
        .in('id', uniqueProgramIds);
      if (error) throw error;
      return data as unknown as Program[];
    },
    enabled: uniqueProgramIds.length > 0
  });

  // Set default selected program
  useEffect(() => {
    if (programs && programs.length > 0 && !selectedProgram) {
      setSelectedProgram(programs[0].id);
    }
  }, [programs, selectedProgram]);

  // Fetch sessions for selected program
  const { data: sessions } = useQuery({
    queryKey: ['program-sessions', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('sessions')
        .select('id, session_date, location, notes')
        .eq('program_id', selectedProgram)
        .order('session_date', { ascending: true });
      if (error) throw error;
      return data as Session[];
    },
    enabled: !!selectedProgram
  });

  // Fetch staff assignments for selected program
  const { data: staffMembers } = useQuery({
    queryKey: ['program-staff', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('staff_assignments')
        .select(`
          id,
          staff_id,
          is_leader,
          role:program_roles(name, name_en)
        `)
        .eq('program_id', selectedProgram);
      if (error) throw error;
      
      // Fetch profiles for each staff member
      const staffIds = data?.map((s: any) => s.staff_id) || [];
      if (staffIds.length === 0) return [];
      
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('user_id, full_name, phone')
        .in('user_id', staffIds);
      
      if (profilesError) throw profilesError;
      
      // Sort: leaders first
      const sortedData = data?.sort((a: any, b: any) => (b.is_leader ? 1 : 0) - (a.is_leader ? 1 : 0));
      
      return sortedData?.map((staff: any) => ({
        ...staff,
        profile: profiles?.find((p: any) => p.user_id === staff.staff_id) || null
      })) as StaffMember[];
    },
    enabled: !!selectedProgram
  });

  // Fetch program files
  const { data: programFiles } = useQuery({
    queryKey: ['program-files-parent', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('program_files')
        .select('id, file_name, file_path, file_type, file_size, created_at')
        .eq('program_id', selectedProgram)
        .eq('visibility', 'staff_and_parents')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as ProgramFile[];
    },
    enabled: !!selectedProgram
  });

  // Fetch scores for selected program's students
  const { data: studentScores } = useQuery({
    queryKey: ['program-student-scores', selectedProgram, enrolledPrograms],
    queryFn: async () => {
      if (!selectedProgram || !enrolledPrograms) return [];
      
      const studentIds = enrolledPrograms
        .filter(e => e.programId === selectedProgram)
        .map(e => e.studentId);
      
      if (studentIds.length === 0) return [];
      
      const { data, error } = await supabase
        .from('student_scores')
        .select(`
          score,
          session_id,
          student_id,
          criterion:assessment_criteria(
            id, name, name_en, max_score, criterion_type
          )
        `)
        .in('student_id', studentIds);
      
      if (error) throw error;
      return data as any[];
    },
    enabled: !!selectedProgram && !!enrolledPrograms
  });

  // Fetch criteria for selected program
  const { data: criteria } = useQuery({
    queryKey: ['program-criteria', selectedProgram],
    queryFn: async () => {
      if (!selectedProgram) return [];
      const { data, error } = await supabase
        .from('assessment_criteria')
        .select('id, name, name_en, max_score, criterion_type')
        .eq('program_id', selectedProgram)
        .order('name');
      if (error) throw error;
      return data;
    },
    enabled: !!selectedProgram
  });

  // Generate signed URLs for files
  const generateSignedUrls = useCallback(async (files: ProgramFile[]) => {
    const urls: Record<string, string> = {};
    for (const file of files) {
      const { data, error } = await supabase.storage
        .from('program-files')
        .createSignedUrl(file.file_path, 3600);
      if (!error && data) {
        urls[file.file_path] = data.signedUrl;
      }
    }
    setSignedUrls(urls);
  }, []);

  useEffect(() => {
    if (programFiles && programFiles.length > 0) {
      generateSignedUrls(programFiles);
    }
  }, [programFiles, generateSignedUrls]);

  const handleDownload = async (file: ProgramFile) => {
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 60);
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في تحميل الملف' : 'Error downloading file');
      return;
    }
    
    const link = document.createElement('a');
    link.href = data.signedUrl;
    link.download = file.file_name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleViewFile = async (file: ProgramFile) => {
    const { data, error } = await supabase.storage
      .from('program-files')
      .createSignedUrl(file.file_path, 3600);
    
    if (error || !data) {
      toast.error(language === 'ar' ? 'خطأ في عرض الملف' : 'Error viewing file');
      return;
    }
    
    setSelectedFileUrl(data.signedUrl);
    setSelectedFile(file);
    setIsViewerOpen(true);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const isImageFile = (fileType: string) => fileType.startsWith('image/');
  const isPdfFile = (fileType: string) => fileType === 'application/pdf';

  const getFileIcon = (fileType: string) => {
    if (isImageFile(fileType)) return <ImageIcon className="h-5 w-5 text-blue-500" />;
    if (isPdfFile(fileType)) return <FileText className="h-5 w-5 text-red-500" />;
    return <FileIcon className="h-5 w-5 text-muted-foreground" />;
  };

  // Build assessment report data
  const buildAssessmentReport = () => {
    if (!sessions || !criteria || !studentScores) return null;
    
    const studentsInProgram = enrolledPrograms?.filter(e => e.programId === selectedProgram) || [];
    if (studentsInProgram.length === 0) return null;
    
    // For each student, build a report
    return studentsInProgram.map(student => {
      const studentScoresData = studentScores.filter((s: any) => s.student_id === student.studentId);
      
      // Build score matrix: session -> criterion -> score
      const scoreMatrix: Record<string, Record<string, number>> = {};
      const criterionTotals: Record<string, { sum: number; count: number }> = {};
      
      sessions.forEach(session => {
        scoreMatrix[session.id] = {};
        criteria.forEach(criterion => {
          const score = studentScoresData.find(
            (s: any) => s.session_id === session.id && s.criterion?.id === criterion.id
          );
          if (score) {
            scoreMatrix[session.id][criterion.id] = score.score;
            if (!criterionTotals[criterion.id]) {
              criterionTotals[criterion.id] = { sum: 0, count: 0 };
            }
            criterionTotals[criterion.id].sum += score.score;
            criterionTotals[criterion.id].count += 1;
          }
        });
      });
      
      return {
        studentId: student.studentId,
        studentName: student.studentName,
        scoreMatrix,
        criterionTotals
      };
    });
  };

  const assessmentReports = buildAssessmentReport();

  if (loadingEnrollments) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3 rtl:flex-row-reverse">
          <BookOpen className="h-7 w-7 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <div className="min-w-0">
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
              {t('برامجي', 'My Programs')}
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground">
              {activeSemester
                ? (language === 'ar' ? activeSemester.name : activeSemester.name_en || activeSemester.name)
                : t('لا يوجد فصل دراسي نشط', 'No active semester')}
            </p>
          </div>
        </div>

        {!programs || programs.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <BookOpen className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">
                {t('لا توجد برامج مسجلة', 'No enrolled programs')}
              </h3>
              <p className="text-muted-foreground text-center">
                {t('لم يتم تسجيل أبنائك في أي برنامج في الفصل الحالي', 
                   'Your children are not enrolled in any program in the current semester')}
              </p>
            </CardContent>
          </Card>
        ) : (
          <Tabs value={selectedProgram || ''} onValueChange={setSelectedProgram} className="w-full">
            <TabsList className="flex-wrap h-auto gap-2 p-2 w-full">
              {programs.map((program) => (
                <TabsTrigger key={program.id} value={program.id} className="flex items-center gap-2 min-h-[44px] text-sm sm:text-base">
                  <BookOpen className="h-4 w-4 flex-shrink-0" />
                  <span className="truncate">{language === 'ar' ? program.name : program.name_en || program.name}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {programs.map((program) => (
              <TabsContent key={program.id} value={program.id} className="space-y-6 mt-6">
                {/* Program Description */}
                {(program.description || program.description_en) && (
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-muted-foreground">
                        {language === 'ar' 
                          ? program.description 
                          : program.description_en || program.description}
                      </p>
                    </CardContent>
                  </Card>
                )}

                {/* Days Table - Mobile Card Layout / Desktop Table */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse text-base sm:text-lg">
                      <Calendar className="h-5 w-5 text-primary flex-shrink-0" />
                      {t('جدول اللقاءات', 'Sessions Schedule')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!sessions || sessions.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا توجد لقاءات مجدولة', 'No sessions scheduled')}
                      </p>
                    ) : (
                      <>
                        {/* Mobile Card Layout */}
                        <div className="space-y-3 sm:hidden">
                          {sessions.map((session) => (
                            <div key={session.id} className="p-3 rounded-lg border bg-card">
                              <div className="flex items-center justify-between gap-2 mb-2">
                                <Badge variant="outline" className="text-xs">
                                  {session.session_date
                                    ? format(parseISO(session.session_date), 'dd MMM yyyy', {
                                        locale: language === 'ar' ? ar : enUS
                                      })
                                    : '-'}
                                </Badge>
                              </div>
                              {session.location && (
                                <div className="flex items-center gap-2 text-sm text-muted-foreground rtl:flex-row-reverse mb-1">
                                  <MapPin className="h-4 w-4 flex-shrink-0" />
                                  <span>{session.location}</span>
                                </div>
                              )}
                              {session.notes && (
                                <p className="text-sm text-muted-foreground mt-2">{session.notes}</p>
                              )}
                            </div>
                          ))}
                        </div>
                        {/* Desktop Table Layout */}
                        <div className="hidden sm:block">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>{t('التاريخ', 'Date')}</TableHead>
                                <TableHead>{t('الموقع', 'Location')}</TableHead>
                                <TableHead>{t('ملاحظات', 'Notes')}</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {sessions.map((session) => (
                                <TableRow key={session.id}>
                                  <TableCell>
                                    {session.session_date
                                      ? format(parseISO(session.session_date), 'dd MMM yyyy', {
                                          locale: language === 'ar' ? ar : enUS
                                        })
                                      : '-'}
                                  </TableCell>
                                  <TableCell>
                                    {session.location || '-'}
                                  </TableCell>
                                  <TableCell>
                                    {session.notes || '-'}
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>

                {/* Staff Cards - Mobile Friendly */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse text-base sm:text-lg">
                      <Users className="h-5 w-5 text-primary flex-shrink-0" />
                      {t('مشرفو البرنامج', 'Program Supervisors')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!staffMembers || staffMembers.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا يوجد مشرفين معينين', 'No supervisors assigned')}
                      </p>
                    ) : (
                      <>
                        {/* Mobile Card Layout */}
                        <div className="space-y-3 sm:hidden">
                          {staffMembers.map((staff) => (
                            <div key={staff.id} className="p-4 rounded-lg border bg-card">
                              <div className="flex items-start justify-between gap-2 rtl:flex-row-reverse">
                                <div className="min-w-0 flex-1">
                                  <p className="font-medium text-foreground truncate">
                                    {staff.profile?.full_name || '-'}
                                  </p>
                                  {staff.profile?.phone && (
                                    <a 
                                      href={`tel:${staff.profile.phone}`}
                                      className="flex items-center gap-2 text-primary hover:underline rtl:flex-row-reverse mt-2 min-h-[44px] py-2"
                                    >
                                      <Phone className="h-5 w-5 flex-shrink-0" />
                                      <span className="text-base">{staff.profile.phone}</span>
                                    </a>
                                  )}
                                </div>
                                <Badge variant={staff.is_leader ? 'default' : 'secondary'} className="flex-shrink-0">
                                  {staff.is_leader 
                                    ? t('قائد', 'Leader')
                                    : t('مشرف', 'Supervisor')}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                        {/* Desktop Table Layout */}
                        <div className="hidden sm:block">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>{t('الاسم', 'Name')}</TableHead>
                                <TableHead>{t('الدور', 'Role')}</TableHead>
                                <TableHead>{t('رقم الجوال', 'Mobile Phone')}</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {staffMembers.map((staff) => (
                                <TableRow key={staff.id}>
                                  <TableCell className="font-medium">
                                    {staff.profile?.full_name || '-'}
                                  </TableCell>
                                  <TableCell>
                                    <Badge variant={staff.is_leader ? 'default' : 'secondary'}>
                                      {staff.is_leader 
                                        ? t('قائد', 'Leader')
                                        : t('مشرف', 'Supervisor')}
                                    </Badge>
                                  </TableCell>
                                  <TableCell>
                                    {staff.profile?.phone ? (
                                      <a 
                                        href={`tel:${staff.profile.phone}`}
                                        className="flex items-center gap-2 text-primary hover:underline rtl:flex-row-reverse"
                                      >
                                        <Phone className="h-4 w-4" />
                                        {staff.profile.phone}
                                      </a>
                                    ) : '-'}
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>

                {/* Program Files */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse text-base sm:text-lg">
                      <FileText className="h-5 w-5 text-primary flex-shrink-0" />
                      {t('ملفات البرنامج', 'Program Files')}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {!programFiles || programFiles.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا توجد ملفات متاحة', 'No files available')}
                      </p>
                    ) : (
                      <div className="space-y-3">
                        {programFiles.map((file) => (
                          <div 
                            key={file.id} 
                            className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-lg bg-muted/50 gap-3"
                          >
                            <div className="flex items-center gap-3 min-w-0 flex-1 rtl:flex-row-reverse">
                              {getFileIcon(file.file_type)}
                              <div className="min-w-0 flex-1">
                                <p className="font-medium truncate text-sm sm:text-base">{file.file_name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {formatFileSize(file.file_size)} • {format(parseISO(file.created_at), 'dd MMM yyyy', {
                                    locale: language === 'ar' ? ar : enUS
                                  })}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2 rtl:flex-row-reverse self-end sm:self-center">
                              {(isImageFile(file.file_type) || isPdfFile(file.file_type)) && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="min-h-[44px] min-w-[44px]"
                                  onClick={() => handleViewFile(file)}
                                  title={language === 'ar' ? 'عرض' : 'View'}
                                >
                                  <Eye className="h-5 w-5" />
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="icon"
                                className="min-h-[44px] min-w-[44px]"
                                onClick={() => handleDownload(file)}
                                title={language === 'ar' ? 'تحميل' : 'Download'}
                              >
                                <Download className="h-5 w-5" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Assessment Report */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 rtl:flex-row-reverse text-base sm:text-lg">
                      <TrendingUp className="h-5 w-5 text-primary flex-shrink-0" />
                      {t('تقرير التقييم', 'Assessment Report')}
                    </CardTitle>
                    <CardDescription className="text-sm">
                      {t('درجات أبنائك في معايير التقييم لكل لقاء', 'Your children\'s scores in assessment criteria for each session')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!assessmentReports || assessmentReports.length === 0 || !criteria || criteria.length === 0 ? (
                      <p className="text-center text-muted-foreground py-4">
                        {t('لا توجد تقييمات متاحة', 'No assessments available')}
                      </p>
                    ) : (
                      <div className="space-y-6">
                        {assessmentReports.map((report) => (
                          <div key={report.studentId} className="space-y-3">
                            <h4 className="font-medium text-base sm:text-lg">{report.studentName}</h4>
                            
                            {/* Mobile Card Layout */}
                            <div className="space-y-4 sm:hidden">
                              {sessions?.map((session, index) => {
                                const sessionScores = criteria.map(criterion => ({
                                  criterion,
                                  score: report.scoreMatrix[session.id]?.[criterion.id]
                                })).filter(s => s.score !== undefined);
                                
                                if (sessionScores.length === 0) return null;
                                
                                return (
                                  <div key={session.id} className="p-3 rounded-lg border bg-card">
                                    <div className="font-medium text-sm mb-3">
                                      {session.session_date
                                        ? format(parseISO(session.session_date), 'dd MMM yyyy', {
                                            locale: language === 'ar' ? ar : enUS
                                          })
                                        : `${t('اللقاء', 'Session')} ${index + 1}`}
                                    </div>
                                    <div className="space-y-2">
                                      {sessionScores.map(({ criterion, score }) => (
                                        <div key={criterion.id} className="flex items-center justify-between gap-2">
                                          <span className="text-sm text-muted-foreground truncate flex-1">
                                            {language === 'ar' ? criterion.name : criterion.name_en || criterion.name}
                                          </span>
                                          <Badge variant={score !== undefined && score >= criterion.max_score * 0.7 ? 'default' : score !== undefined && score >= criterion.max_score * 0.5 ? 'secondary' : 'destructive'}>
                                            {score}/{criterion.max_score}
                                          </Badge>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                );
                              })}
                              {/* Mobile Averages */}
                              <div className="p-3 rounded-lg border bg-muted/50">
                                <div className="font-medium text-sm mb-3">{t('المعدل', 'Average')}</div>
                                <div className="space-y-2">
                                  {criteria.map((criterion) => {
                                    const total = report.criterionTotals[criterion.id];
                                    const average = total ? (total.sum / total.count).toFixed(1) : null;
                                    return (
                                      <div key={criterion.id} className="flex items-center justify-between gap-2">
                                        <span className="text-sm text-muted-foreground truncate flex-1">
                                          {language === 'ar' ? criterion.name : criterion.name_en || criterion.name}
                                        </span>
                                        <span className="font-bold text-primary">
                                          {average !== null ? average : '-'}
                                        </span>
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                            
                            {/* Desktop Table Layout */}
                            <div className="hidden sm:block overflow-x-auto">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead className="min-w-[100px]">{t('اللقاء', 'Session')}</TableHead>
                                    {criteria.map((criterion) => (
                                      <TableHead key={criterion.id} className="min-w-[100px] text-center">
                                        {language === 'ar' ? criterion.name : criterion.name_en || criterion.name}
                                        <br />
                                        <span className="text-xs text-muted-foreground">
                                          ({t('من', 'of')} {criterion.max_score})
                                        </span>
                                      </TableHead>
                                    ))}
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {sessions?.map((session, index) => (
                                    <TableRow key={session.id}>
                                      <TableCell className="font-medium">
                                        {session.session_date
                                          ? format(parseISO(session.session_date), 'dd MMM', {
                                              locale: language === 'ar' ? ar : enUS
                                            })
                                          : `${t('اللقاء', 'Session')} ${index + 1}`}
                                      </TableCell>
                                      {criteria.map((criterion) => {
                                        const score = report.scoreMatrix[session.id]?.[criterion.id];
                                        return (
                                          <TableCell key={criterion.id} className="text-center">
                                            {score !== undefined ? (
                                              <Badge variant={score >= criterion.max_score * 0.7 ? 'default' : score >= criterion.max_score * 0.5 ? 'secondary' : 'destructive'}>
                                                {score}
                                              </Badge>
                                            ) : (
                                              <span className="text-muted-foreground">-</span>
                                            )}
                                          </TableCell>
                                        );
                                      })}
                                    </TableRow>
                                  ))}
                                  {/* Average Row */}
                                  <TableRow className="bg-muted/50 font-medium">
                                    <TableCell>{t('المعدل', 'Average')}</TableCell>
                                    {criteria.map((criterion) => {
                                      const total = report.criterionTotals[criterion.id];
                                      const average = total ? (total.sum / total.count).toFixed(1) : null;
                                      return (
                                        <TableCell key={criterion.id} className="text-center">
                                          {average !== null ? (
                                            <span className="font-bold text-primary">{average}</span>
                                          ) : (
                                            <span className="text-muted-foreground">-</span>
                                          )}
                                        </TableCell>
                                      );
                                    })}
                                  </TableRow>
                                </TableBody>
                              </Table>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        )}
      </div>

      {/* File Viewer Dialog */}
      <Dialog open={isViewerOpen} onOpenChange={setIsViewerOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between rtl:flex-row-reverse">
              {selectedFile?.file_name}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsViewerOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </DialogTitle>
          </DialogHeader>
          <div className="overflow-auto max-h-[70vh]">
            {selectedFile && selectedFileUrl && (
              isImageFile(selectedFile.file_type) ? (
                <img
                  src={selectedFileUrl}
                  alt={selectedFile.file_name}
                  className="w-full h-auto"
                />
              ) : isPdfFile(selectedFile.file_type) ? (
                <iframe
                  src={selectedFileUrl}
                  className="w-full h-[70vh]"
                  title={selectedFile.file_name}
                />
              ) : null
            )}
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
