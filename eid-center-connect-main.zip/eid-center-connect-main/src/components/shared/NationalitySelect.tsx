import { useLanguage } from '@/contexts/LanguageContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface NationalitySelectProps {
  value: string;
  onValueChange: (value: string) => void;
  required?: boolean;
}

const nationalities = [
  { en: 'Qatari', ar: 'قطري' },
  { en: 'Egyptian', ar: 'مصري' },
  { en: 'Jordanian', ar: 'أردني' },
  { en: 'Syrian', ar: 'سوري' },
  { en: 'Palestinian', ar: 'فلسطيني' },
  { en: 'Lebanese', ar: 'لبناني' },
  { en: 'Saudi', ar: 'سعودي' },
  { en: 'Emirati', ar: 'إماراتي' },
  { en: 'Kuwaiti', ar: 'كويتي' },
  { en: 'Bahraini', ar: 'بحريني' },
  { en: 'Omani', ar: 'عماني' },
  { en: 'Yemeni', ar: 'يمني' },
  { en: 'Iraqi', ar: 'عراقي' },
  { en: 'Sudanese', ar: 'سوداني' },
  { en: 'Moroccan', ar: 'مغربي' },
  { en: 'Tunisian', ar: 'تونسي' },
  { en: 'Algerian', ar: 'جزائري' },
  { en: 'Indian', ar: 'هندي' },
  { en: 'Pakistani', ar: 'باكستاني' },
  { en: 'Bangladeshi', ar: 'بنغلاديشي' },
  { en: 'Filipino', ar: 'فلبيني' },
  { en: 'Indonesian', ar: 'إندونيسي' },
  { en: 'Other', ar: 'أخرى' },
];

export function NationalitySelect({ value, onValueChange, required }: NationalitySelectProps) {
  const { language, t } = useLanguage();

  return (
    <Select value={value} onValueChange={onValueChange} required={required}>
      <SelectTrigger>
        <SelectValue placeholder={t('اختر الجنسية', 'Select Nationality')} />
      </SelectTrigger>
      <SelectContent>
        {nationalities.map((nat) => (
          <SelectItem key={nat.en} value={nat.en}>
            {language === 'ar' ? nat.ar : nat.en}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export { nationalities };
