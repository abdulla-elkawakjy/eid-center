-- Phase 1.2: Add columns to staff_assignments table
ALTER TABLE public.staff_assignments 
ADD COLUMN IF NOT EXISTS role_name text,
ADD COLUMN IF NOT EXISTS role_name_en text;

-- Phase 1.3: Add columns to sessions table
ALTER TABLE public.sessions 
ADD COLUMN IF NOT EXISTS session_number integer,
ADD COLUMN IF NOT EXISTS assembly_time time,
ADD COLUMN IF NOT EXISTS dismissal_time time,
ADD COLUMN IF NOT EXISTS planned_courses text;

-- Phase 1.1: Create supervisor_permissions table
CREATE TABLE public.supervisor_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assignment_id uuid NOT NULL REFERENCES public.staff_assignments(id) ON DELETE CASCADE,
  can_edit_session_info boolean DEFAULT false,
  can_manage_criteria boolean DEFAULT false,
  can_submit_store_request boolean DEFAULT false,
  can_submit_session_report boolean DEFAULT false,
  can_enter_individual_evaluation boolean DEFAULT false,
  can_enter_group_evaluation boolean DEFAULT false,
  can_coordinate_catering boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(assignment_id)
);

-- Phase 1.4: Create session_activities table
CREATE TABLE public.session_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  name text NOT NULL,
  name_en text,
  start_time time,
  end_time time,
  order_index integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Phase 1.5: Create student_attendance table
CREATE TABLE public.student_attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  is_present boolean DEFAULT false,
  notes text,
  marked_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(session_id, student_id)
);

-- Phase 1.6: Create session_reports table
CREATE TABLE public.session_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE UNIQUE,
  submitted_by uuid,
  supervisor_attendance jsonb DEFAULT '[]'::jsonb,
  courses_delivered text,
  special_activities text,
  notes text,
  submitted_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Phase 1.7: Create session_files table
CREATE TABLE public.session_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.sessions(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_type text NOT NULL,
  file_size bigint NOT NULL,
  uploaded_by uuid NOT NULL,
  visibility public.file_visibility NOT NULL DEFAULT 'staff_only'::public.file_visibility,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on all new tables
ALTER TABLE public.supervisor_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_files ENABLE ROW LEVEL SECURITY;

-- RLS for supervisor_permissions
CREATE POLICY "Admins can manage supervisor permissions"
ON public.supervisor_permissions FOR ALL
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Staff can view own permissions"
ON public.supervisor_permissions FOR SELECT
USING (EXISTS (
  SELECT 1 FROM public.staff_assignments sa
  WHERE sa.id = supervisor_permissions.assignment_id
  AND sa.staff_id = auth.uid()
));

-- RLS for session_activities
CREATE POLICY "Admins can manage session activities"
ON public.session_activities FOR ALL
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Staff can manage session activities"
ON public.session_activities FOR ALL
USING (has_role(auth.uid(), 'staff'));

CREATE POLICY "Anyone can view session activities"
ON public.session_activities FOR SELECT
USING (true);

-- RLS for student_attendance
CREATE POLICY "Admins can manage student attendance"
ON public.student_attendance FOR ALL
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Staff can manage student attendance"
ON public.student_attendance FOR ALL
USING (has_role(auth.uid(), 'staff'));

CREATE POLICY "Parents can view children attendance"
ON public.student_attendance FOR SELECT
USING (EXISTS (
  SELECT 1 FROM public.students s
  WHERE s.id = student_attendance.student_id
  AND s.parent_id = auth.uid()
));

CREATE POLICY "Students can view own attendance"
ON public.student_attendance FOR SELECT
USING (EXISTS (
  SELECT 1 FROM public.students s
  WHERE s.id = student_attendance.student_id
  AND s.user_id = auth.uid()
));

-- RLS for session_reports
CREATE POLICY "Admins can manage session reports"
ON public.session_reports FOR ALL
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Staff can manage session reports"
ON public.session_reports FOR ALL
USING (has_role(auth.uid(), 'staff'));

CREATE POLICY "Anyone can view session reports"
ON public.session_reports FOR SELECT
USING (true);

-- RLS for session_files
CREATE POLICY "Admin and staff can manage session files"
ON public.session_files FOR ALL
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

CREATE POLICY "Parents can view visible session files"
ON public.session_files FOR SELECT
USING (
  has_role(auth.uid(), 'parent') 
  AND visibility = 'staff_and_parents'::public.file_visibility
  AND EXISTS (
    SELECT 1 FROM public.sessions sess
    JOIN public.registration_requests rr ON rr.program_id = sess.program_id
    JOIN public.students s ON s.id = rr.student_id
    WHERE sess.id = session_files.session_id
    AND s.parent_id = auth.uid()
    AND rr.status = 'approved'
  )
);

CREATE POLICY "Students can view visible session files"
ON public.session_files FOR SELECT
USING (
  has_role(auth.uid(), 'student')
  AND visibility = 'staff_and_parents'::public.file_visibility
  AND EXISTS (
    SELECT 1 FROM public.sessions sess
    JOIN public.registration_requests rr ON rr.program_id = sess.program_id
    JOIN public.students s ON s.id = rr.student_id
    WHERE sess.id = session_files.session_id
    AND s.user_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- Create triggers for updated_at
CREATE TRIGGER update_supervisor_permissions_updated_at
BEFORE UPDATE ON public.supervisor_permissions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_session_activities_updated_at
BEFORE UPDATE ON public.session_activities
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_student_attendance_updated_at
BEFORE UPDATE ON public.student_attendance
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_session_reports_updated_at
BEFORE UPDATE ON public.session_reports
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();