import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface StudentData {
  full_name: string;
  date_of_birth?: string;
  gender?: string;
  notes?: string;
  qid_number?: string;
  school_grade?: number;
  mobile_number?: string;
  nationality?: string;
  has_health_conditions?: boolean;
  health_conditions_details?: string;
}

interface CreateUserRequest {
  email: string;
  password: string;
  fullName: string;
  phone?: string;
  qidNumber?: string;
  nationality?: string;
  motherPhone?: string;
  role: 'staff' | 'parent' | 'admin' | 'student';
  studentId?: string; // Optional - links to existing student record (for legacy students)
  studentData?: StudentData; // New - creates student record along with account
  parentId?: string; // Required for admin/staff when creating student with studentData
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;

    // Create admin client with service role for user creation
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false }
    });

    // Create client with user's token to verify their role
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error('No authorization header provided');
      return new Response(
        JSON.stringify({ error: 'Unauthorized - No token provided' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify the requesting user
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error('Failed to get user:', userError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized - Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get the caller's role
    const { data: callerRoleData, error: callerRoleError } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .maybeSingle();

    if (callerRoleError || !callerRoleData) {
      console.error('Failed to get caller role:', callerRoleError);
      return new Response(
        JSON.stringify({ error: 'Forbidden - No role assigned' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const callerRole = callerRoleData.role;
    const body: CreateUserRequest = await req.json();
    console.log('Creating user with email:', body.email, 'role:', body.role, 'by:', callerRole);

    // Validate input
    if (!body.email || !body.password || !body.fullName || !body.role) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: email, password, fullName, role' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (body.password.length < 6) {
      return new Response(
        JSON.stringify({ error: 'Password must be at least 6 characters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Determine parent ID for student creation
    let effectiveParentId: string | null = null;

    // Permission checks based on caller role
    if (callerRole === 'admin') {
      // Admins can create any user type
      console.log('Admin creating user with role:', body.role);
      if (body.role === 'student' && body.studentData) {
        if (!body.parentId) {
          return new Response(
            JSON.stringify({ error: 'Parent ID is required when creating student account' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        effectiveParentId = body.parentId;
      }
    } else if (callerRole === 'staff') {
      // Staff can only create student accounts
      if (body.role !== 'student') {
        return new Response(
          JSON.stringify({ error: 'Staff can only create student accounts' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (body.studentData) {
        if (!body.parentId) {
          return new Response(
            JSON.stringify({ error: 'Parent ID is required when creating student account' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        effectiveParentId = body.parentId;
      }
    } else if (callerRole === 'parent') {
      // Parents can only create student accounts for their own children
      if (body.role !== 'student') {
        return new Response(
          JSON.stringify({ error: 'Parents can only create student accounts for their children' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      // For parents, always use their own ID as parent
      effectiveParentId = user.id;

      // If linking to existing student, verify parent owns this student
      if (body.studentId) {
        const { data: studentData, error: studentError } = await supabaseAdmin
          .from('students')
          .select('parent_id')
          .eq('id', body.studentId)
          .maybeSingle();

        if (studentError || !studentData) {
          return new Response(
            JSON.stringify({ error: 'Student not found' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        if (studentData.parent_id !== user.id) {
          return new Response(
            JSON.stringify({ error: 'You can only create accounts for your own children' }),
            { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
    } else {
      return new Response(
        JSON.stringify({ error: 'Forbidden - Insufficient permissions' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // For student role linking to existing record, validate studentId
    if (body.role === 'student' && body.studentId && !body.studentData) {
      // Check if student already has an account
      const { data: existingStudent, error: existingError } = await supabaseAdmin
        .from('students')
        .select('id, user_id, full_name')
        .eq('id', body.studentId)
        .maybeSingle();

      if (existingError || !existingStudent) {
        return new Response(
          JSON.stringify({ error: 'Student not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (existingStudent.user_id) {
        return new Response(
          JSON.stringify({ error: 'This student already has an account' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Create user using admin client (won't affect caller's session)
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email: body.email,
      password: body.password,
      email_confirm: true, // Auto-confirm the email
      user_metadata: { full_name: body.fullName }
    });

    if (createError) {
      console.error('Failed to create user:', createError);
      return new Response(
        JSON.stringify({ error: createError.message }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('User created with ID:', newUser.user.id);

    // Assign role
    const { error: roleInsertError } = await supabaseAdmin
      .from('user_roles')
      .insert({ user_id: newUser.user.id, role: body.role });

    if (roleInsertError) {
      console.error('Failed to assign role:', roleInsertError);
      // Try to clean up the created user
      await supabaseAdmin.auth.admin.deleteUser(newUser.user.id);
      return new Response(
        JSON.stringify({ error: 'Failed to assign role: ' + roleInsertError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Update profile with additional info
    const profileUpdate: Record<string, string | null> = {};
    if (body.phone) profileUpdate.phone = body.phone;
    if (body.qidNumber) profileUpdate.qid_number = body.qidNumber;
    if (body.nationality) profileUpdate.nationality = body.nationality;
    if (body.motherPhone) profileUpdate.mother_phone = body.motherPhone;

    if (Object.keys(profileUpdate).length > 0) {
      await supabaseAdmin
        .from('profiles')
        .update(profileUpdate)
        .eq('user_id', newUser.user.id);
    }

    let studentRecordId: string | null = null;

    // If creating a student with new student data, create the student record
    if (body.role === 'student' && body.studentData && effectiveParentId) {
      const studentInsert = {
        full_name: body.studentData.full_name,
        date_of_birth: body.studentData.date_of_birth || null,
        gender: body.studentData.gender || null,
        notes: body.studentData.notes || null,
        qid_number: body.studentData.qid_number || null,
        school_grade: body.studentData.school_grade || null,
        mobile_number: body.studentData.mobile_number || null,
        nationality: body.studentData.nationality || null,
        has_health_conditions: body.studentData.has_health_conditions || false,
        health_conditions_details: body.studentData.health_conditions_details || null,
        parent_id: effectiveParentId,
        user_id: newUser.user.id,
      };

      const { data: newStudent, error: studentInsertError } = await supabaseAdmin
        .from('students')
        .insert(studentInsert)
        .select('id')
        .single();

      if (studentInsertError) {
        console.error('Failed to create student record:', studentInsertError);
        // Clean up: delete user
        await supabaseAdmin.auth.admin.deleteUser(newUser.user.id);
        return new Response(
          JSON.stringify({ error: 'Failed to create student record: ' + studentInsertError.message }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      studentRecordId = newStudent.id;
      console.log('Created student record:', studentRecordId, 'linked to user:', newUser.user.id);
    }

    // If linking to existing student record, update it
    if (body.role === 'student' && body.studentId && !body.studentData) {
      const { error: linkError } = await supabaseAdmin
        .from('students')
        .update({ user_id: newUser.user.id })
        .eq('id', body.studentId);

      if (linkError) {
        console.error('Failed to link student record:', linkError);
        // Clean up: delete user and role
        await supabaseAdmin.auth.admin.deleteUser(newUser.user.id);
        return new Response(
          JSON.stringify({ error: 'Failed to link student account: ' + linkError.message }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      studentRecordId = body.studentId;
      console.log('Linked student record:', body.studentId, 'to user:', newUser.user.id);
    }

    console.log('User creation complete:', body.email);

    return new Response(
      JSON.stringify({ 
        success: true, 
        user: { 
          id: newUser.user.id, 
          email: newUser.user.email 
        },
        studentId: studentRecordId
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Unexpected error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
