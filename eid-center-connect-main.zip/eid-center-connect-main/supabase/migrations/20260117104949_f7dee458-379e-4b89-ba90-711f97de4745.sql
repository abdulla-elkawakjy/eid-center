-- Create visibility enum for program files
CREATE TYPE public.file_visibility AS ENUM ('staff_only', 'staff_and_parents');

-- Create program_files table to store file metadata
CREATE TABLE public.program_files (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  program_id UUID NOT NULL REFERENCES public.programs(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  visibility file_visibility NOT NULL DEFAULT 'staff_only',
  uploaded_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.program_files ENABLE ROW LEVEL SECURITY;

-- Policy: Admin and staff can view all program files
CREATE POLICY "Admin and staff can view all program files"
ON public.program_files
FOR SELECT
USING (
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'staff')
);

-- Policy: Parents can view files visible to them for programs their children are registered in
CREATE POLICY "Parents can view visible program files"
ON public.program_files
FOR SELECT
USING (
  public.has_role(auth.uid(), 'parent') AND
  visibility = 'staff_and_parents' AND
  EXISTS (
    SELECT 1 FROM public.registration_requests rr
    JOIN public.students s ON s.id = rr.student_id
    WHERE rr.program_id = program_files.program_id
    AND s.parent_id = auth.uid()
    AND rr.status = 'approved'
  )
);

-- Policy: Admin and staff can insert files
CREATE POLICY "Admin and staff can insert files"
ON public.program_files
FOR INSERT
WITH CHECK (
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'staff')
);

-- Policy: Admin and staff can update files
CREATE POLICY "Admin and staff can update files"
ON public.program_files
FOR UPDATE
USING (
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'staff')
);

-- Policy: Admin and staff can delete files
CREATE POLICY "Admin and staff can delete files"
ON public.program_files
FOR DELETE
USING (
  public.has_role(auth.uid(), 'admin') OR 
  public.has_role(auth.uid(), 'staff')
);

-- Create storage bucket for program files
INSERT INTO storage.buckets (id, name, public) VALUES ('program-files', 'program-files', true);

-- Storage policies: Admin and staff can upload files
CREATE POLICY "Admin and staff can upload program files"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'program-files' AND
  (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'staff'))
);

-- Storage policies: Anyone authenticated can view/download files (visibility controlled by program_files table)
CREATE POLICY "Authenticated users can view program files"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'program-files' AND
  auth.role() = 'authenticated'
);

-- Storage policies: Admin and staff can delete files
CREATE POLICY "Admin and staff can delete program files"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'program-files' AND
  (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'staff'))
);